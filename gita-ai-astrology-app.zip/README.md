# Gita AI – Your Favorite Astrologer

**Gita AI** is a modern, mobile-first Indian AI astrology application built with **Next.js (App Router)**, **TypeScript**, **Tailwind CSS**, and **PostgreSQL via Drizzle ORM**. It is designed for Android mobile browsers, PWA installation (`manifest.json`), and Android TWA / WebView wrappers.

---

## 1. Brand & Core Capabilities

- **App Name:** Gita AI
- **Tagline:** Your Favorite Astrologer
- **Languages Supported:** Hinglish (default), हिंदी (Devanagari Hindi), and English.
- **Home Dashboard:**
  - Original Gita AI Indian female astrologer illustration with animated Sacred Yantra halo.
  - Welcome greeting: *“Namaste! Main Gita hoon. Aaj aap kya jaana chahte hain?”*
  - Prominent **Chat with Gita AI** button and 8 quick-action cards (*Career, Love & Relationships, Marriage, Family, Money, Daily Horoscope, Kundli, Personal Guidance*).
  - Personalized Daily Horoscope, Lucky Colour swatch, Lucky Number, and Daily Reflection.
- **AI Astrologer Chat & 15-Second Free Trial:**
  - Natural, respectful, empathetic Hindi/Hinglish/English conversations that incorporate the user's birth details, Chandra Rashi, Surya Rashi, and Nakshatra.
  - Permanent ethical disclaimer clarifying that astrology is for entertainment and personal reflection, not guaranteed prediction or medical, legal, or financial advice.
  - **Server-Enforced 15-Second Free Trial:** Starts automatically when an eligible new user initiates their first chat. Tracked in PostgreSQL (`trial_started_at`, `trial_used`) so reinstalling or clearing local storage does not reset trial eligibility.
- **₹49/Month Subscription & Server-Side Verification:**
  - Transparent pricing (`₹49/month`), billing period, auto-renewal, and cancellation terms with mandatory explicit user consent checkbox.
  - Never unlocks premium access based on screenshots, QR scans, or unverified client-side messages.
  - Enforces server-side HMAC signature & webhook verification across `verified`, `pending`, `failed`, `refunded`, `cancelled`, and `expired` states, plus **Restore Purchases**.
- **Kundli & Personalized Astrology:**
  - Validated Birth Details form (`Birth Date` required; `Birth Time` and `Birthplace` optional with clear explanations).
  - Generates a 12-House North Indian Diamond Kundli SVG chart and transparently labels its calculation mode (*Sidereal Lahiri Mean Ephemeris Approximation* vs. *General AI-Generated Astrology-Style Guidance*).
- **Role-Based Admin Dashboard (`/admin`):**
  - Strictly protected by server-side Role-Based Access Control (`role === "admin"`). Ordinary users receive HTTP `403 Forbidden`.
  - Displays user counts, subscription metrics, verified revenue, payment verification records, daily horoscope CMS, app config, and an immutable security audit log without exposing user passwords or private secrets.

---

## 2. Setup & Configuration Instructions

### A. Database Setup (PostgreSQL + Drizzle ORM)
1. Copy `.env.example` to `.env` and configure `DATABASE_URL`:
   ```bash
   DATABASE_URL=postgresql://postgres:postgres@127.0.0.1:5432/app_db
   ```
2. Push the Drizzle schema to PostgreSQL:
   ```bash
   npx drizzle-kit push
   ```
3. The server automatically seeds the 12 Vedic Rashis, default remedies, app configuration, and demo accounts on first boot.

### B. Configuring AI Services (`src/lib/gita-ai.ts`)
- Set `OPENAI_API_KEY` (and optional `OPENAI_MODEL`) or `GEMINI_API_KEY` in `.env` on the server.
- AI keys are read strictly on the server inside `/api/chat` and are never exposed to the client bundle.
- If no external LLM key is configured, Gita AI uses its built-in context-aware Vedic Jyotish conversational engine so the application remains fully functional during local evaluation.

### C. Configuring Payment Credentials (`src/app/api/subscription/route.ts`)
- **Indian UPI / PhonePe / Razorpay Web Distribution:** Set `PHONEPE_MERCHANT_ID`, `PHONEPE_SALT_KEY`, `RAZORPAY_KEY_ID`, `RAZORPAY_KEY_SECRET`, and `PAYMENT_WEBHOOK_SECRET` in `.env`.
- **Google Play Store Distribution:** Digital subscriptions distributed via Google Play Store must use **Google Play Billing**. Set `GOOGLE_PLAY_PACKAGE_NAME`, `GOOGLE_PLAY_BILLING_KEY`, and `GOOGLE_PLAY_SERVICE_ACCOUNT_JSON` on the server to validate `purchaseToken` payloads via the Google Play Developer API.

---

## 3. Step-by-Step Testing Instructions

### Pre-Seeded Test Accounts (Available via 1-Tap Switcher in Login/Profile)
| Account Role | Email | Password | Initial State |
| :--- | :--- | :--- | :--- |
| **New Eligible User** | `aarav@gita-ai.in` | `Gita@123` | **15-second free trial ready** (starts on first chat) |
| **Active Subscriber** | `priya@gita-ai.in` | `Gita@123` | **₹49/month Active** (Server-verified order) |
| **Administrator** | `admin@gita-ai.in` | `Admin@123` | **RBAC Admin** (Full access to `/admin`) |

### 1. Testing the 15-Second Free Trial & Expiry
1. Open the app (logged in as `aarav@gita-ai.in` by default) and tap **Chat with Gita AI** or any topic card.
2. Send a message (e.g., *"Meri naukri mein tarakki kab hogi?"*).
3. Observe the **15-Second Free Trial Countdown Bar** (`00:15s` → `00:00s`) at the top of the chat screen.
4. When the timer hits `00:00s`, the backend marks the trial expired (`POST /api/trial`) and locks further premium chat with the **₹49/month Subscription Gate**.
5. *To re-test the 15-second trial at any time:* Tap **Reset 15s Trial** in the top utility bar or inside Subscription Management.

### 2. Testing the 5 Payment Options & “Pay using another person's phone” (QR & Link)
1. Navigate to the **₹49/mo Plan** screen (`Subscription` tab).
2. Observe the pre-payment **Merchant & Subscription Details** card showing the Merchant Name (`Gita AI – Vedic Digital Services`), Verified UPI ID (`gitaai.merchant@axis`), intended Beneficiary Gita AI Account, and payable amount (`₹49.00 / month`).
3. Choose from the **5 Payment Options**:
   - **PhonePe**
   - **Google Pay**
   - **Paytm**
   - **Other supported UPI apps**
   - **Pay using another person's phone**
4. Select **Pay using another person's phone**, check the **Explicit Billing Consent** box, and click **Generate ₹49 QR Code & Payment Link**.
5. In the **Payment Status & Verification Screen** that appears:
   - Status immediately displays **“Waiting for payment”** with a live **5-minute (`05:00`) countdown timer**.
   - A **scannable Dynamic UPI QR Code** (bound to the exact `orderId`, `userId`, and `₹49.00` subscription) and a **Secure Payment Link** (`/pay/[orderId]?sig=...`) are displayed.
   - Click **Open Payer Link (Friend's Phone)** to open `/pay/[orderId]` in a second tab or on another phone.
   - On `/pay/[orderId]`, click **Confirm ₹49 Payment** (or use **Webhook: Payment Successful** on the main screen).
   - Watch the user's Gita AI payment screen automatically poll the server, transition from **“Waiting for payment”** to **“Payment successful”**, and unlock unlimited chat for the intended Gita AI account!
   - If you click **Check Payment Status** before webhook confirmation, the server keeps the order in **“Waiting for payment”** (demonstrating that unverified user claims or screenshots never unlock access).
   - If the payment fails (**Webhook: Payment Failed**) or the **5-minute payment window expires**, click **Retry Payment** to generate a fresh dynamic order and QR code.
   - **Idempotent Protection**: Once an order reaches `verified` (**“Payment successful”**), the backend refuses to overwrite or reject it if a late timeout or failure event arrives.
6. Under **Subscription Management**:
   - Click **Cancel Subscription** to test cancellation (`cancelled`).
   - Click **Simulate Plan Expiry** to test expired billing period enforcement (`expired`).
   - Click **Restore Purchases** to verify server-side lookup of verified orders and entitlement restoration.

### 3. Testing the Role-Based Admin Dashboard
1. While logged in as an ordinary user (`aarav@gita-ai.in`), click **Admin Dashboard** in the top bar or visit `/admin`. Verify that the server returns **HTTP 403 Forbidden** and blocks access.
2. Click **Switch to Authorized Admin Account (`admin@gita-ai.in`)** to inspect user metrics, payment verification records, Daily Horoscope CMS updates, App Configuration, and Audit Logs.

---

## 4. Production Readiness & External Provider Checklist

Before releasing Gita AI to public production traffic, the following external credentials and approvals must be completed:
1. **Payment Gateway Merchant KYC & Live Keys:** Live merchant onboarding and webhook approval from PhonePe PG / Razorpay for UPI Autopay, and Google Play Console Subscription Product setup (`monthly_49`) for Play Store distribution.
2. **Production AI API Keys:** Configure a production-tier `OPENAI_API_KEY` or `GEMINI_API_KEY` with rate limits and billing alerts.
3. **High-Precision Ephemeris (Optional):** If sub-arcsecond planetary degrees are desired beyond the built-in Sidereal Lahiri Mean Ephemeris calculator, integrate a licensed Swiss Ephemeris service on the backend.
