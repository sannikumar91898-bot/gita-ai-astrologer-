import crypto from "crypto";
import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, payments, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  CONFIGURED_RECIPIENT_UPI_ID,
  SUBSCRIPTION_PRICE_INR,
} from "@/lib/upi-verification";

export async function POST(req: NextRequest) {
  try {
    const rawBody = await req.text();

    const phonePeSaltKey = process.env.PHONEPE_SALT_KEY?.trim();
    const phonePeSaltIndex = process.env.PHONEPE_SALT_INDEX?.trim() || "1";
    const razorpayWebhookSecret = process.env.RAZORPAY_WEBHOOK_SECRET?.trim();
    const bankWebhookSecret = process.env.UPI_PROVIDER_WEBHOOK_SECRET?.trim();

    if (!phonePeSaltKey && !razorpayWebhookSecret && !bankWebhookSecret) {
      return NextResponse.json(
        {
          verified: false,
          error:
            "Webhook verification unavailable: No live provider webhook secret (PHONEPE_SALT_KEY, RAZORPAY_WEBHOOK_SECRET, or UPI_PROVIDER_WEBHOOK_SECRET) is configured on the server.",
        },
        { status: 503 }
      );
    }

    const xVerifyHeader = req.headers.get("x-verify") || "";
    const razorpaySigHeader = req.headers.get("x-razorpay-signature") || "";
    const bankSigHeader = req.headers.get("x-upi-webhook-signature") || "";

    let signatureVerified = false;
    let providerName = "unknown";

    if (phonePeSaltKey && xVerifyHeader) {
      const parsed = JSON.parse(rawBody || "{}");
      const base64Response = String(parsed.response || "");
      const expectedHash =
        crypto
          .createHash("sha256")
          .update(base64Response + phonePeSaltKey)
          .digest("hex") +
        "###" +
        phonePeSaltIndex;
      if (expectedHash === xVerifyHeader) {
        signatureVerified = true;
        providerName = "phonepe_s2s_webhook";
      }
    } else if (razorpayWebhookSecret && razorpaySigHeader) {
      const expectedHmac = crypto
        .createHmac("sha256", razorpayWebhookSecret)
        .update(rawBody)
        .digest("hex");
      if (expectedHmac === razorpaySigHeader) {
        signatureVerified = true;
        providerName = "razorpay_webhook";
      }
    } else if (bankWebhookSecret && bankSigHeader) {
      const expectedHmac = crypto
        .createHmac("sha256", bankWebhookSecret)
        .update(rawBody)
        .digest("hex");
      if (expectedHmac === bankSigHeader) {
        signatureVerified = true;
        providerName = "bank_upi_webhook";
      }
    }

    if (!signatureVerified) {
      return NextResponse.json(
        {
          verified: false,
          error:
            "Invalid cryptographic webhook signature. Unverified requests cannot unlock Premium.",
        },
        { status: 401 }
      );
    }

    const payload = JSON.parse(rawBody || "{}");
    const orderId = String(
      payload.orderId ||
        payload.merchantTransactionId ||
        payload?.payload?.payment?.entity?.notes?.orderId ||
        ""
    ).trim();
    const utr = String(
      payload.utr ||
        payload.rrn ||
        payload?.payload?.payment?.entity?.acquirer_data?.rrn ||
        ""
    ).trim();
    const amountInr = Number(
      payload.amountInr ?? (payload.amount ? Number(payload.amount) / 100 : 0)
    );
    const recipientVpa = String(
      payload.recipientVpa ||
        payload.payeeVpa ||
        CONFIGURED_RECIPIENT_UPI_ID
    )
      .trim()
      .toLowerCase();
    const txStatus = String(payload.status || payload.state || "").toUpperCase();

    if (!orderId) {
      return NextResponse.json(
        { error: "Missing orderId in webhook payload" },
        { status: 400 }
      );
    }

    const [paymentRecord] = await db
      .select()
      .from(payments)
      .where(eq(payments.orderId, orderId));

    if (!paymentRecord) {
      return NextResponse.json(
        { error: `Order ${orderId} not found` },
        { status: 404 }
      );
    }

    if (
      recipientVpa !== CONFIGURED_RECIPIENT_UPI_ID.toLowerCase() ||
      amountInr !== SUBSCRIPTION_PRICE_INR ||
      !(
        txStatus === "SUCCESS" ||
        txStatus === "COMPLETED" ||
        txStatus === "CAPTURED"
      )
    ) {
      return NextResponse.json(
        {
          verified: false,
          error: `Webhook validation failed: expected ₹${SUBSCRIPTION_PRICE_INR} to ${CONFIGURED_RECIPIENT_UPI_ID} with status SUCCESS.`,
        },
        { status: 422 }
      );
    }

    // Check UTR uniqueness so no UTR can be replayed across orders
    if (utr) {
      const [existingWithUtr] = await db
        .select()
        .from(payments)
        .where(eq(payments.providerTransactionId, utr));
      if (existingWithUtr && existingWithUtr.orderId !== orderId) {
        return NextResponse.json(
          {
            verified: false,
            error: `UTR ${utr} is already associated with another order.`,
          },
          { status: 409 }
        );
      }
    }

    const now = new Date();
    const expiresAt = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

    await db
      .update(payments)
      .set({
        status: "verified",
        providerTransactionId: utr || orderId,
        verificationMethod: providerName,
        failureReason: null,
        verifiedAt: now,
      })
      .where(eq(payments.id, paymentRecord.id));

    await db
      .update(users)
      .set({
        subscriptionStatus: "active",
        subscriptionPlan: "monthly_49",
        subscriptionExpiresAt: expiresAt,
        trialUsed: true,
        updatedAt: now,
      })
      .where(eq(users.id, paymentRecord.userId));

    await db.insert(auditLogs).values({
      actorUserId: paymentRecord.userId,
      targetUserId: paymentRecord.userId,
      eventType: "WEBHOOK_PAYMENT_VERIFIED",
      details: JSON.stringify({
        orderId,
        utr,
        recipientVpa: CONFIGURED_RECIPIENT_UPI_ID,
        amountInr: SUBSCRIPTION_PRICE_INR,
        providerName,
      }),
    });

    return NextResponse.json({
      verified: true,
      orderId,
      utr,
      recipientVpa: CONFIGURED_RECIPIENT_UPI_ID,
      amountInr: SUBSCRIPTION_PRICE_INR,
    });
  } catch (err) {
    console.error("[Webhook /api/webhooks/upi] Error:", err);
    return NextResponse.json(
      { error: "Webhook processing failed" },
      { status: 500 }
    );
  }
}
