import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { users, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import {
  ensureSeeded,
  getUserFromRequestHeaders,
  computeEntitlement,
} from "@/lib/server-utils";

export async function GET(req: NextRequest) {
  try {
    await ensureSeeded();
    const user = await getUserFromRequestHeaders(req.headers);
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const entitlement = computeEntitlement(user);
    return NextResponse.json({
      userId: user.id,
      entitlement,
    });
  } catch (error) {
    console.error("[API /trial GET] Error:", error);
    return NextResponse.json(
      { error: "Failed to check trial status" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    await ensureSeeded();
    let user = await getUserFromRequestHeaders(req.headers);
    const body = await req.json();

    if (!user && body.userId) {
      const [found] = await db
        .select()
        .from(users)
        .where(eq(users.id, Number(body.userId)));
      user = found || null;
    }

    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { action } = body;

    if (action === "start_trial") {
      const currentEntitlement = computeEntitlement(user);
      if (currentEntitlement.isSubscribed) {
        return NextResponse.json({
          entitlement: currentEntitlement,
          message: "Active ₹49/mo subscription already active.",
        });
      }

      if (user.trialUsed || user.trialStartedAt) {
        return NextResponse.json({
          entitlement: currentEntitlement,
          message:
            "Free 15-second trial was already initiated for this account.",
        });
      }

      const now = new Date();
      const [updated] = await db
        .update(users)
        .set({
          trialStartedAt: now,
          trialUsed: true,
          subscriptionStatus: "trial",
          updatedAt: now,
        })
        .where(eq(users.id, user.id))
        .returning();

      await db.insert(auditLogs).values({
        actorUserId: user.id,
        targetUserId: user.id,
        eventType: "TRIAL_STARTED",
        details: JSON.stringify({
          startedAt: now.toISOString(),
          durationSeconds: 15,
        }),
      });

      return NextResponse.json({
        entitlement: computeEntitlement(updated),
        message: "15-second free chat trial started!",
      });
    }

    if (action === "expire_trial") {
      const currentEntitlement = computeEntitlement(user);
      if (!currentEntitlement.isSubscribed) {
        const pastDate = new Date(Date.now() - 20 * 1000);
        const [updated] = await db
          .update(users)
          .set({
            trialStartedAt: user.trialStartedAt || pastDate,
            trialUsed: true,
            subscriptionStatus:
              user.subscriptionStatus === "trial" ||
              user.subscriptionStatus === "none"
                ? "expired"
                : user.subscriptionStatus,
            updatedAt: new Date(),
          })
          .where(eq(users.id, user.id))
          .returning();

        await db.insert(auditLogs).values({
          actorUserId: user.id,
          targetUserId: user.id,
          eventType: "TRIAL_EXPIRED",
          details: JSON.stringify({
            expiredAt: new Date().toISOString(),
            requiredPlan: "monthly_49",
          }),
        });

        return NextResponse.json({
          entitlement: computeEntitlement(updated),
          message:
            "Your 15-second free trial has ended. Subscribe for ₹49/month to continue chatting with Gita AI.",
        });
      }
      return NextResponse.json({ entitlement: currentEntitlement });
    }

    if (action === "qa_reset_trial") {
      // Explicit QA/Sandbox testing action to re-test the 15s free trial flow from fresh
      const [updated] = await db
        .update(users)
        .set({
          trialStartedAt: null,
          trialUsed: false,
          subscriptionStatus: "none",
          subscriptionExpiresAt: null,
          updatedAt: new Date(),
        })
        .where(eq(users.id, user.id))
        .returning();

      await db.insert(auditLogs).values({
        actorUserId: user.id,
        targetUserId: user.id,
        eventType: "QA_TRIAL_RESET",
        details: JSON.stringify({
          note: "QA tester reset 15s trial eligibility to test countdown & paywall transition.",
        }),
      });

      return NextResponse.json({
        entitlement: computeEntitlement(updated),
        message:
          "QA Mode: 15-second free trial reset! Send a chat message to trigger the 15s countdown.",
      });
    }

    return NextResponse.json({ error: "Unsupported action" }, { status: 400 });
  } catch (error) {
    console.error("[API /trial POST] Error:", error);
    return NextResponse.json(
      { error: "Failed to update trial status" },
      { status: 500 }
    );
  }
}
