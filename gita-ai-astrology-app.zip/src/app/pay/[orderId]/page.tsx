"use client";

import React, { useState, useEffect, useCallback } from "react";
import { useParams } from "next/navigation";
import QRCode from "qrcode";
import { GitaAvatar } from "@/components/VedicGraphics";
import {
  CheckCircle2,
  Clock,
  ShieldCheck,
  XCircle,
  AlertTriangle,
  ExternalLink,
  RefreshCw,
  Copy,
  Lock,
} from "lucide-react";

interface UpiPaymentLinks {
  standardUpiUri: string;
  phonePeUri: string;
  googlePayUri: string;
  paytmUri: string;
  bhimUri: string;
}

interface OrderDetail {
  orderId: string;
  recipientUpiId: string;
  provider: string;
  amountInr: number;
  status: string;
  failureReason?: string | null;
  remainingWindowSeconds: number;
  isWindowExpired: boolean;
  upiQrIntentUri: string;
  upiLinks?: UpiPaymentLinks;
  merchantDetails: {
    merchantName: string;
    merchantLegalName: string;
    merchantVpa: string;
    recipientUpiId: string;
    planName: string;
    amountInr: number;
    orderId: string;
  };
  customerAccount?: {
    customerUserId: number;
    customerName: string;
    customerEmail: string;
  };
}

export default function PayerCheckoutPage() {
  const params = useParams<{ orderId: string }>();
  const orderId = params?.orderId || "";

  const [order, setOrder] = useState<OrderDetail | null>(null);
  const [gatewayConfig, setGatewayConfig] = useState<{
    anyLiveVerificationConfigured: boolean;
    missingCredentialsExplanation?: string;
    requiredSetupSteps?: string[];
  } | null>(null);
  const [countdown, setCountdown] = useState<number>(300);
  const [qrDataUrl, setQrDataUrl] = useState<string>("");
  const [utrInput, setUtrInput] = useState("");
  const [copiedUpi, setCopiedUpi] = useState(false);
  const [loading, setLoading] = useState(true);
  const [processing, setProcessing] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const loadOrder = useCallback(async () => {
    if (!orderId) return;
    try {
      const res = await fetch(
        `/api/subscription?orderId=${encodeURIComponent(orderId)}`
      );
      const data = await res.json();
      if (res.ok && data.order) {
        setOrder(data.order);
        setGatewayConfig(data.gatewayConfig || null);
        setCountdown(data.order.remainingWindowSeconds);
        QRCode.toDataURL(data.order.upiQrIntentUri, {
          width: 220,
          margin: 2,
          color: { dark: "#2A162D", light: "#FFFFFF" },
        })
          .then((url) => setQrDataUrl(url))
          .catch(() => {});
      } else {
        setError(data.error || "Order not found");
      }
    } catch {
      setError("Failed to load payment order details.");
    } finally {
      setLoading(false);
    }
  }, [orderId]);

  useEffect(() => {
    loadOrder();
  }, [loadOrder]);

  useEffect(() => {
    if (
      !order ||
      order.status === "verified" ||
      order.status === "failed" ||
      order.status === "expired"
    ) {
      return;
    }

    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          loadOrder();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [order, loadOrder]);

  const handleVerifyWithServer = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!order) return;
    setProcessing(true);
    setError(null);
    setMessage(null);
    try {
      const res = await fetch("/api/subscription", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "verify_payment",
          orderId: order.orderId,
          utr: utrInput.trim() || undefined,
        }),
      });
      const data = await res.json();
      if (data.payment) {
        setOrder(data.payment);
      }
      if (res.ok && data.verified) {
        setMessage(data.message);
      } else {
        setError(
          data.error ||
            data.message ||
            "Payment verification unavailable without authorized merchant API credentials."
        );
      }
    } catch {
      setError("Network error while verifying payment.");
    } finally {
      setProcessing(false);
    }
  };

  const formatTimer = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen bg-[#FFF9F5] text-[#2A162D] flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-3xl border-2 border-[#D4AF37]/60 p-6 shadow-xl space-y-5">
        <div className="flex items-center gap-3 border-b border-[#EFE1E6] pb-4">
          <GitaAvatar size="sm" showOnline={true} />
          <div>
            <span className="text-[10px] font-mono-vedic uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#7C2D86]/10 text-[#7C2D86] font-bold">
              Direct UPI Payment Request
            </span>
            <h1 className="text-lg font-serif-vedic text-[#2A162D] mt-0.5">
              Gita AI – ₹49/Month Subscription
            </h1>
          </div>
        </div>

        {loading ? (
          <div className="py-10 text-center text-xs text-[#6E5273]">
            Loading order details...
          </div>
        ) : error && !order ? (
          <div className="p-4 rounded-2xl bg-[#C93B2B]/10 border border-[#C93B2B]/30 text-[#C93B2B] text-xs">
            {error}
          </div>
        ) : order ? (
          <>
            {/* Recipient & Order Details */}
            <div className="bg-[#FDF3EE] rounded-2xl p-4 border border-[#EFE1E6] space-y-2 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-[#6E5273]">
                  Merchant Recipient (Payee UPI ID):
                </span>
                <div className="flex items-center gap-1.5">
                  <span className="font-mono-vedic font-bold text-[#7C2D86]">
                    {order.recipientUpiId || "7250595155@ibl"}
                  </span>
                  <button
                    type="button"
                    onClick={() => {
                      if (
                        typeof navigator !== "undefined" &&
                        navigator.clipboard
                      ) {
                        navigator.clipboard.writeText(
                          order.recipientUpiId || "7250595155@ibl"
                        );
                        setCopiedUpi(true);
                        setTimeout(() => setCopiedUpi(false), 2000);
                      }
                    }}
                    className="px-2 py-0.5 rounded bg-[#7C2D86] text-white text-[10px] font-semibold cursor-pointer"
                  >
                    <Copy className="w-2.5 h-2.5 inline mr-0.5" />
                    {copiedUpi ? "Copied" : "Copy"}
                  </button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#6E5273]">
                  Customer Gita AI Account (Subscriber):
                </span>
                <span className="font-bold text-[#2A162D]">
                  {order.customerAccount?.customerName || "Gita AI User"} (
                  {order.customerAccount?.customerEmail || ""})
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[#6E5273]">Unique Order Reference:</span>
                <span className="font-mono-vedic font-semibold text-[#2A162D]">
                  {order.orderId}
                </span>
              </div>
              <div className="flex items-center justify-between pt-2 border-t border-[#E5D4E8]">
                <span className="font-bold text-[#2A162D]">
                  Subscription Amount:
                </span>
                <span className="text-xl font-bold font-mono-vedic text-[#1E7E5A]">
                  ₹{order.amountInr}.00
                </span>
              </div>
            </div>

            {order.status === "verified" ? (
              <div className="p-4 rounded-2xl bg-[#1E7E5A]/15 border border-[#1E7E5A]/40 text-center space-y-2">
                <CheckCircle2 className="w-10 h-10 text-[#1E7E5A] mx-auto" />
                <div className="text-base font-bold text-[#1E7E5A]">
                  Payment successful
                </div>
                <p className="text-xs text-[#2A162D]">
                  ₹49.00 payment to{" "}
                  <strong>{order.recipientUpiId || "7250595155@ibl"}</strong> is
                  verified! Premium chat is unlocked on{" "}
                  <strong>
                    {order.customerAccount?.customerName || "the customer"}
                  </strong>
                  &apos;s Gita AI account.
                </p>
              </div>
            ) : order.status === "expired" || countdown <= 0 ? (
              <div className="p-4 rounded-2xl bg-[#C93B2B]/10 border border-[#C93B2B]/30 text-center space-y-2">
                <AlertTriangle className="w-8 h-8 text-[#C93B2B] mx-auto" />
                <div className="text-sm font-bold text-[#C93B2B]">
                  5-Minute Payment Window Expired
                </div>
                <p className="text-xs text-[#6E5273]">
                  Please ask{" "}
                  {order.customerAccount?.customerName || "the subscriber"} to
                  tap <strong>Retry Payment</strong> on their Gita AI screen to
                  generate a fresh order reference.
                </p>
              </div>
            ) : order.status === "failed" ? (
              <div className="p-4 rounded-2xl bg-[#C93B2B]/10 border border-[#C93B2B]/30 text-center space-y-2">
                <XCircle className="w-8 h-8 text-[#C93B2B] mx-auto" />
                <div className="text-sm font-bold text-[#C93B2B]">
                  Payment Failed
                </div>
                <p className="text-xs text-[#6E5273]">
                  {order.failureReason ||
                    `This transaction was declined or could not be verified. Ask ${
                      order.customerAccount?.customerName || "the subscriber"
                    } to tap Retry Payment.`}
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3 rounded-2xl bg-[#D97706]/10 border border-[#D97706]/30 flex items-center justify-between text-xs">
                  <span className="font-bold text-[#D97706] flex items-center gap-1.5">
                    <Lock className="w-4 h-4" />
                    Waiting for verified payment
                  </span>
                  <span className="font-mono-vedic font-bold text-[#2A162D]">
                    {formatTimer(countdown)}
                  </span>
                </div>

                {qrDataUrl && (
                  <div className="text-center bg-[#FFF9F5] p-3 rounded-2xl border border-[#EFE1E6]">
                    <img
                      src={qrDataUrl}
                      alt={`UPI QR for ${order.recipientUpiId}`}
                      className="w-44 h-44 mx-auto rounded-xl"
                    />
                    <div className="text-[11px] font-mono-vedic font-bold text-[#2A162D] mt-1">
                      Scan & Pay ₹49.00 to {order.recipientUpiId}
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <div className="text-xs font-bold text-[#2A162D]">
                    Pay with UPI App on This Phone:
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    <a
                      href={
                        order.upiLinks?.phonePeUri || order.upiQrIntentUri
                      }
                      className="py-2.5 px-3 rounded-xl bg-[#5F259F] text-white text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      PhonePe
                    </a>
                    <a
                      href={
                        order.upiLinks?.googlePayUri || order.upiQrIntentUri
                      }
                      className="py-2.5 px-3 rounded-xl bg-[#1A73E8] text-white text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Google Pay
                    </a>
                    <a
                      href={
                        order.upiLinks?.paytmUri || order.upiQrIntentUri
                      }
                      className="py-2.5 px-3 rounded-xl bg-[#00B9F1] text-white text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      Paytm
                    </a>
                    <a
                      href={
                        order.upiLinks?.bhimUri || order.upiQrIntentUri
                      }
                      className="py-2.5 px-3 rounded-xl bg-[#E85D04] text-white text-xs font-bold flex items-center justify-center gap-1.5"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      BHIM / Other UPI
                    </a>
                  </div>
                </div>

                {/* Server-Side UTR & Status Verification Form */}
                <form
                  onSubmit={handleVerifyWithServer}
                  className="pt-3 border-t border-[#EFE1E6] space-y-2"
                >
                  <label className="block text-xs font-bold text-[#2A162D]">
                    Verify Payment via Server API (Optional 12-Digit UTR):
                  </label>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="12-digit UTR / RRN"
                      value={utrInput}
                      onChange={(e) => setUtrInput(e.target.value)}
                      className="flex-1 h-10 px-3 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs font-mono-vedic"
                    />
                    <button
                      type="submit"
                      disabled={processing}
                      className="px-4 h-10 rounded-xl bg-[#7C2D86] text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shrink-0"
                    >
                      <RefreshCw
                        className={`w-3.5 h-3.5 ${
                          processing ? "animate-spin" : ""
                        }`}
                      />
                      Verify
                    </button>
                  </div>
                </form>

                {gatewayConfig &&
                  !gatewayConfig.anyLiveVerificationConfigured && (
                    <div className="p-3 rounded-xl bg-[#D97706]/10 border border-[#D97706]/30 text-[11px] text-[#2A162D]">
                      <strong className="text-[#B8860B]">
                        Verification Notice:
                      </strong>{" "}
                      {gatewayConfig.missingCredentialsExplanation}
                    </div>
                  )}
              </div>
            )}

            {message && (
              <div className="p-3 rounded-xl bg-[#1E7E5A]/15 text-[#1E7E5A] text-xs font-medium">
                {message}
              </div>
            )}
            {error && (
              <div className="p-3 rounded-xl bg-[#C93B2B]/15 border border-[#C93B2B]/30 text-[#C93B2B] text-xs font-medium">
                {error}
              </div>
            )}
          </>
        ) : null}

        <div className="text-[11px] text-[#6E5273] flex items-center justify-center gap-1.5 pt-2 border-t border-[#EFE1E6]">
          <ShieldCheck className="w-4 h-4 text-[#1E7E5A]" />
          <span>Recipient UPI ID: 7250595155@ibl • Strict Server Verification</span>
        </div>
      </div>
    </div>
  );
}
