"use client";

import React, { useState, useEffect, useRef, useCallback } from "react";
import { GitaAvatar, NorthIndianKundliChart } from "@/components/VedicGraphics";
import {
  SplashScreenOverlay,
  OnboardingView,
  AuthScreenView,
  LegalAndSupportView,
} from "@/components/AppModalsAndScreens";
import { SubscriptionScreens } from "@/components/SubscriptionScreens";
import { AdminDashboardView } from "@/components/AdminDashboardView";
import type { KundliHouseData } from "@/lib/astrology";
import {
  Home,
  MessageCircleHeart,
  Compass,
  Sparkles,
  User,
  Send,
  Bookmark,
  Clock,
  ShieldCheck,
  Briefcase,
  Heart,
  Users,
  IndianRupee,
  Sun,
  Calendar,
  MapPin,
  CheckCircle2,
  Plus,
  Trash2,
  Bell,
  Lock,
  RefreshCw,
  ChevronRight,
  Info,
  LogIn,
  HelpCircle,
  FileText,
  Smartphone,
} from "lucide-react";

type ScreenTab =
  | "home"
  | "chat"
  | "kundli"
  | "horoscope"
  | "remedies"
  | "saved"
  | "subscription"
  | "profile"
  | "auth"
  | "onboarding"
  | "legal"
  | "admin";

interface UserProfile {
  id: number;
  email: string;
  phone: string | null;
  name: string;
  role: string;
  preferredLanguage: "hinglish" | "hindi" | "english";
  birthDate: string | null;
  birthTime: string | null;
  birthPlace: string | null;
  rashi: string;
  nakshatra: string;
  consentGiven: boolean;
  notificationsEnabled: boolean;
  reminderTime: string | null;
  trialStartedAt: string | null;
  trialUsed: boolean;
  subscriptionStatus: string;
  subscriptionPlan: string;
  subscriptionExpiresAt: string | null;
  entitlement: {
    isSubscribed: boolean;
    trialEligible: boolean;
    trialActive: boolean;
    trialExpired: boolean;
    remainingTrialSeconds: number;
    canChat: boolean;
    subscriptionStatus: string;
  };
}

interface ChatMessageItem {
  id: number;
  sessionId: string;
  topic: string;
  role: "user" | "assistant";
  content: string;
  isSavedReading: boolean;
  createdAt: string;
}

interface HoroscopeItem {
  id: number;
  rashi: string;
  rashiHindi: string;
  symbol: string;
  element: string;
  rulingPlanet: string;
  dailyForecastHinglish: string;
  dailyForecastHindi: string;
  dailyForecastEnglish: string;
  luckyColor: string;
  luckyColorHex: string;
  luckyNumber: string;
  dailyReflection: string;
  positiveHabit: string;
}

interface KundliReadingItem {
  id: number;
  name: string;
  birthDate: string;
  birthTime: string | null;
  birthPlace: string | null;
  calculationMode: string;
  lagnaSign: string;
  chandraRashi: string;
  suryaRashi: string;
  nakshatra: string;
  houses: KundliHouseData[];
  aiInterpretation: string;
  disclaimerLabel?: string;
  createdAt: string;
}

interface RemedyItem {
  id: number;
  title: string;
  category: string;
  description: string;
  mantraOrAction: string | null;
  isCompleted: boolean;
  completedAt: string | null;
  streakCount: number;
}

export default function GitaAiApp() {
  const [showSplash, setShowSplash] = useState(false);
  const [activeScreen, setActiveScreen] = useState<ScreenTab>("home");
  const [legalSection, setLegalSection] = useState<
    "privacy" | "terms" | "help" | "delete_account"
  >("privacy");
  const [mobileFrameMode, setMobileFrameMode] = useState(true);

  const [token, setToken] = useState<string | null>(null);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [appConfig, setAppConfig] = useState<Record<string, string>>({});
  const [loadingInitial, setLoadingInitial] = useState(true);

  // Chat & 15s Free Trial state
  const [messages, setMessages] = useState<ChatMessageItem[]>([]);
  const [chatInput, setChatInput] = useState("");
  const [selectedTopic, setSelectedTopic] = useState("Personal Guidance");
  const [chatSending, setChatSending] = useState(false);
  const [trialCountdown, setTrialCountdown] = useState<number>(15);
  const [trialRunning, setTrialRunning] = useState(false);
  const [showInlineBirthBar, setShowInlineBirthBar] = useState(false);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  // Horoscopes, Kundli, Remedies
  const [horoscopes, setHoroscopes] = useState<HoroscopeItem[]>([]);
  const [selectedRashiFilter, setSelectedRashiFilter] =
    useState<string>("Kumbha (Aquarius)");
  const [kundliReadings, setKundliReadings] = useState<KundliReadingItem[]>([]);
  const [remediesList, setRemediesList] = useState<RemedyItem[]>([]);

  // Kundli Birth Details Form state
  const [kundliName, setKundliName] = useState("");
  const [kundliDate, setKundliDate] = useState("");
  const [kundliTime, setKundliTime] = useState("");
  const [kundliPlace, setKundliPlace] = useState("");
  const [kundliGenerating, setKundliGenerating] = useState(false);
  const [kundliError, setKundliError] = useState<string | null>(null);

  // New Remedy Form
  const [newRemedyTitle, setNewRemedyTitle] = useState("");
  const [newRemedyDesc, setNewRemedyDesc] = useState("");
  const [newRemedyMantra, setNewRemedyMantra] = useState("");

  // Profile Edit State
  const [profileSavedToast, setProfileSavedToast] = useState<string | null>(
    null
  );

  const loadAllData = useCallback(async (overrideToken?: string | null) => {
    const activeToken =
      overrideToken !== undefined
        ? overrideToken
        : typeof window !== "undefined"
        ? localStorage.getItem("gita_ai_token")
        : null;

    const headers: Record<string, string> = activeToken
      ? { Authorization: `Bearer ${activeToken}` }
      : {};

    try {
      const [authRes, chatRes, kundliRes, remRes] = await Promise.all([
        fetch("/api/auth", { headers }),
        fetch("/api/chat", { headers }),
        fetch("/api/kundli", { headers }),
        fetch("/api/remedies", { headers }),
      ]);

      if (authRes.ok) {
        const authData = await authRes.json();
        if (authData.token) {
          setToken(authData.token);
          if (typeof window !== "undefined") {
            localStorage.setItem("gita_ai_token", authData.token);
          }
        }
        if (authData.user) {
          setUser(authData.user);
          setSelectedRashiFilter(authData.user.rashi || "Mesh (Aries)");
          setKundliName(authData.user.name || "");
          setKundliDate(authData.user.birthDate || "1997-08-19");
          setKundliTime(authData.user.birthTime || "09:30");
          setKundliPlace(authData.user.birthPlace || "Jaipur, Rajasthan");

          const ent = authData.user.entitlement;
          if (ent) {
            setTrialCountdown(ent.remainingTrialSeconds);
            setTrialRunning(ent.trialActive);
          }
        }
        if (authData.config) {
          setAppConfig(authData.config);
        }
      }

      if (chatRes.ok) {
        const chatData = await chatRes.json();
        setMessages(chatData.messages || []);
      }

      if (kundliRes.ok) {
        const kData = await kundliRes.json();
        setHoroscopes(kData.horoscopes || []);
        setKundliReadings(kData.readings || []);
      }

      if (remRes.ok) {
        const rData = await remRes.json();
        setRemediesList(rData.remedies || []);
      }
    } catch (e) {
      console.error("Failed loading app data:", e);
    } finally {
      setLoadingInitial(false);
    }
  }, []);

  useEffect(() => {
    loadAllData();
  }, [loadAllData]);

  // 15-Second Free Trial Real-Time Countdown Effect
  useEffect(() => {
    if (!trialRunning || user?.entitlement?.isSubscribed) return;

    const interval = setInterval(() => {
      setTrialCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(interval);
          setTrialRunning(false);
          // Notify server that the 15-second trial has expired
          fetch("/api/trial", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...(token ? { Authorization: `Bearer ${token}` } : {}),
            },
            body: JSON.stringify({
              action: "expire_trial",
              userId: user?.id,
            }),
          })
            .then(() => loadAllData(token))
            .catch(() => {});
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [trialRunning, user?.entitlement?.isSubscribed, user?.id, token, loadAllData]);

  useEffect(() => {
    if (activeScreen === "chat") {
      chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, activeScreen, chatSending]);

  const handleLanguageChange = async (
    lang: "hinglish" | "hindi" | "english"
  ) => {
    if (!user) return;
    setUser({ ...user, preferredLanguage: lang });
    await fetch("/api/auth", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({
        action: "update_profile",
        userId: user.id,
        preferredLanguage: lang,
      }),
    });
  };

  const handleQuickTopicSelect = (
    topicLabel: string,
    defaultPrompt: string
  ) => {
    setSelectedTopic(topicLabel);
    if (topicLabel === "Daily Horoscope") {
      setActiveScreen("horoscope");
      return;
    }
    if (topicLabel === "Kundli") {
      setActiveScreen("kundli");
      return;
    }
    setChatInput(defaultPrompt);
    setActiveScreen("chat");
  };

  const handleSendMessage = async (e?: React.FormEvent, customMsg?: string) => {
    if (e) e.preventDefault();
    const textToSend = (customMsg ?? chatInput).trim();
    if (!textToSend || chatSending) return;

    // Check if trial already expired and not subscribed
    if (
      user &&
      !user.entitlement.isSubscribed &&
      user.entitlement.trialExpired
    ) {
      setActiveScreen("subscription");
      return;
    }

    setChatSending(true);
    setChatInput("");

    try {
      const res = await fetch("/api/chat", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          action: "send_message",
          userId: user?.id,
          message: textToSend,
          topic: selectedTopic,
          preferredLanguage: user?.preferredLanguage || "hinglish",
          birthDate: kundliDate || user?.birthDate,
          birthTime: kundliTime || user?.birthTime,
          birthPlace: kundliPlace || user?.birthPlace,
        }),
      });

      const data = await res.json();

      if (res.status === 402) {
        // Trial expired on server! Redirect to Premium Subscription screen
        await loadAllData(token);
        setActiveScreen("subscription");
        return;
      }

      if (res.ok) {
        setMessages((prev) => [
          ...prev,
          data.userMessage,
          data.assistantMessage,
        ]);
        if (data.entitlement) {
          setTrialCountdown(data.entitlement.remainingTrialSeconds);
          setTrialRunning(data.entitlement.trialActive);
          setUser((prev) =>
            prev
              ? {
                  ...prev,
                  trialUsed: true,
                  subscriptionStatus: data.entitlement.subscriptionStatus,
                  entitlement: data.entitlement,
                }
              : prev
          );
        }
      }
    } finally {
      setChatSending(false);
    }
  };

  const handleToggleSaveReading = async (messageId: number) => {
    const res = await fetch("/api/chat", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({
        action: "toggle_save_reading",
        userId: user?.id,
        messageId,
      }),
    });
    if (res.ok) {
      const data = await res.json();
      setMessages((prev) =>
        prev.map((m) => (m.id === messageId ? data.message : m))
      );
    }
  };

  const handleGenerateKundli = async (e: React.FormEvent) => {
    e.preventDefault();
    setKundliGenerating(true);
    setKundliError(null);
    try {
      const res = await fetch("/api/kundli", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          userId: user?.id,
          name: kundliName,
          birthDate: kundliDate,
          birthTime: kundliTime || null,
          birthPlace: kundliPlace || null,
          saveToProfile: true,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setKundliError(data.error || "Failed to generate Kundli");
      } else {
        setKundliReadings((prev) => [data.reading, ...prev]);
        await loadAllData(token);
      }
    } catch {
      setKundliError("Network error while calculating Kundli.");
    } finally {
      setKundliGenerating(false);
    }
  };

  const handleResetTrialForQA = async () => {
    await fetch("/api/trial", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: JSON.stringify({
        action: "qa_reset_trial",
        userId: user?.id,
      }),
    });
    setTrialCountdown(15);
    setTrialRunning(false);
    await loadAllData(token);
  };

  // Current user's Rashi horoscope
  const activeHoroscope =
    horoscopes.find((h) => h.rashi === selectedRashiFilter) ||
    horoscopes.find((h) => h.rashi === user?.rashi) ||
    horoscopes[0];

  const homeHoroscope =
    horoscopes.find((h) => h.rashi === user?.rashi) || horoscopes[0];

  const latestKundli = kundliReadings[0] || null;
  const savedReadingsList = messages.filter((m) => m.isSavedReading);

  if (activeScreen === "admin") {
    return (
      <AdminDashboardView
        token={token}
        currentUserRole={user?.role}
        onSwitchToAdminAccount={async () => {
          const res = await fetch("/api/auth", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
              action: "switch_account",
              email: "admin@gita-ai.in",
            }),
          });
          const data = await res.json();
          if (data.token) {
            localStorage.setItem("gita_ai_token", data.token);
            setToken(data.token);
            await loadAllData(data.token);
          }
        }}
        onBackToApp={() => setActiveScreen("home")}
      />
    );
  }

  const quickActionCards = [
    {
      label: "Career",
      hindiLabel: "करियर और नौकरी",
      icon: Briefcase,
      color: "from-[#7C2D86]/15 to-[#E14B7B]/10",
      prompt:
        "Namaste Gita ji! Mere career aur naukri mein aage badhne aur promotion ke yog kab ban rahe hain?",
    },
    {
      label: "Love & Relationships",
      hindiLabel: "प्रेम और रिश्ते",
      icon: Heart,
      color: "from-[#E14B7B]/15 to-[#D4AF37]/10",
      prompt:
        "Namaste Gita ji! Mere love relationship mein aapsi vishwas aur samajh badhane ke liye grah kya sanket de rahe hain?",
    },
    {
      label: "Marriage",
      hindiLabel: "विवाह और जीवनसाथी",
      icon: Sparkles,
      color: "from-[#D4AF37]/20 to-[#E14B7B]/10",
      prompt:
        "Namaste Gita ji! Meri kundli ke anusaar meri shaadi (vivah) ka shubh samay aur jeevan-saathi kaisa hoga?",
    },
    {
      label: "Family",
      hindiLabel: "परिवार और सुख-शांति",
      icon: Users,
      color: "from-[#1E7E5A]/15 to-[#D4AF37]/10",
      prompt:
        "Namaste Gita ji! Ghar-parivar mein sukh-shanti aur aapsi prem banaye rakhne ke liye kya upay karein?",
    },
    {
      label: "Money",
      hindiLabel: "धन और आर्थिक स्थिति",
      icon: IndianRupee,
      color: "from-[#B8860B]/20 to-[#7C2D86]/10",
      prompt:
        "Namaste Gita ji! Meri arthik stithi (money & savings) mein sthirta aur barkat ke liye kya sanket hain?",
    },
    {
      label: "Daily Horoscope",
      hindiLabel: "आज का राशिफल",
      icon: Sun,
      color: "from-[#D97706]/15 to-[#D4AF37]/15",
      prompt: "",
    },
    {
      label: "Kundli",
      hindiLabel: "जन्म कुंडली और ग्रह",
      icon: Compass,
      color: "from-[#7C2D86]/15 to-[#D4AF37]/15",
      prompt: "",
    },
    {
      label: "Personal Guidance",
      hindiLabel: "व्यक्तिगत मार्गदर्शन",
      icon: MessageCircleHeart,
      color: "from-[#E14B7B]/15 to-[#7C2D86]/15",
      prompt:
        "Namaste Gita ji! Aaj mere man ki shanti aur sakaratmak urja ke liye aapka vishesh margdarshan kya hai?",
    },
  ];

  return (
    <div className="min-h-screen bg-[#F5EBE6] flex flex-col items-center justify-start">
      {showSplash && (
        <SplashScreenOverlay onContinue={() => setShowSplash(false)} />
      )}

      {/* Top Desktop/Evaluator Utility Ribbon */}
      <div className="w-full bg-[#2A162D] text-[#FFF9F5] px-4 py-2 text-[11px] flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-[#1E7E5A]" />
          <span className="font-semibold">
            Gita AI – Android App Experience
          </span>
          <span className="hidden sm:inline text-[#D8C2DC]">
            • 15s Free Trial • ₹49/mo Server-Verified • Hindi/Hinglish/English
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowSplash(true)}
            className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            Splash Screen
          </button>
          <button
            onClick={() => setActiveScreen("onboarding")}
            className="px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            Onboarding
          </button>
          <button
            onClick={handleResetTrialForQA}
            className="px-2.5 py-1 rounded-full bg-[#D4AF37]/25 text-[#FFD966] hover:bg-[#D4AF37]/40 transition font-semibold cursor-pointer"
            title="Reset 15-second free trial on backend to test countdown again"
          >
            Reset 15s Trial
          </button>
          <button
            onClick={() => setActiveScreen("admin")}
            className="px-2.5 py-1 rounded-full bg-[#E14B7B] text-white font-semibold hover:opacity-90 transition cursor-pointer"
          >
            Admin Dashboard
          </button>
          <button
            onClick={() => setMobileFrameMode(!mobileFrameMode)}
            className="hidden md:inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-white/10 hover:bg-white/20 transition cursor-pointer"
          >
            <Smartphone className="w-3 h-3" />
            {mobileFrameMode ? "Full Width" : "Android Frame"}
          </button>
        </div>
      </div>

      {/* Main Mobile-First Android Container */}
      <div
        className={`w-full ${
          mobileFrameMode
            ? "max-w-[480px] md:my-4 md:rounded-[36px] md:border-[6px] md:border-[#2A162D] md:shadow-2xl"
            : "max-w-3xl"
        } bg-[#FFF9F5] min-h-[calc(100vh-36px)] flex flex-col relative overflow-hidden`}
      >
        {/* TOP STICKY APP HEADER */}
        <header className="sticky top-0 z-30 bg-[#FFF9F5]/95 backdrop-blur-md border-b border-[#EFE1E6] px-4 py-3 flex items-center justify-between gap-2">
          <button
            onClick={() => setActiveScreen("home")}
            className="flex items-center gap-2.5 text-left cursor-pointer"
          >
            <div className="w-9 h-9 rounded-full p-0.5 bg-gradient-to-tr from-[#D4AF37] to-[#7C2D86]">
              <img
                src="/images/gita-avatar.png"
                alt="Gita AI"
                className="w-full h-full rounded-full object-cover object-top"
              />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-serif-vedic text-base text-[#2A162D] leading-none">
                  Gita AI
                </span>
                <span className="w-2 h-2 rounded-full bg-[#1E7E5A]" />
              </div>
              <span className="text-[10px] text-[#7C2D86] font-semibold block">
                Your Favorite Astrologer
              </span>
            </div>
          </button>

          <div className="flex items-center gap-1.5">
            {/* Language Toggle Pill */}
            <div className="flex items-center bg-[#FDF3EE] border border-[#E5D4E8] rounded-full p-0.5 text-[10px] font-bold">
              {(
                [
                  { id: "hinglish", label: "Hinglish" },
                  { id: "hindi", label: "हिंदी" },
                  { id: "english", label: "EN" },
                ] as const
              ).map((l) => (
                <button
                  key={l.id}
                  onClick={() => handleLanguageChange(l.id)}
                  className={`px-2 py-1 rounded-full transition cursor-pointer ${
                    user?.preferredLanguage === l.id
                      ? "bg-[#7C2D86] text-white"
                      : "text-[#6E5273]"
                  }`}
                >
                  {l.label}
                </button>
              ))}
            </div>

            {/* Subscription / Trial Status Pill */}
            <button
              onClick={() => setActiveScreen("subscription")}
              className={`px-2.5 py-1 rounded-full text-[10px] font-mono-vedic font-bold flex items-center gap-1 cursor-pointer transition ${
                user?.entitlement?.isSubscribed
                  ? "bg-[#1E7E5A]/15 text-[#1E7E5A] border border-[#1E7E5A]/30"
                  : trialRunning
                  ? "bg-[#D97706] text-white animate-pulse"
                  : user?.entitlement?.trialEligible
                  ? "bg-[#D4AF37]/25 text-[#B8860B] border border-[#D4AF37]"
                  : "bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white"
              }`}
            >
              {user?.entitlement?.isSubscribed ? (
                <>★ PRO ₹49</>
              ) : trialRunning ? (
                <>⏱ {trialCountdown}s</>
              ) : user?.entitlement?.trialEligible ? (
                <>15s FREE</>
              ) : (
                <>₹49/mo</>
              )}
            </button>
          </div>
        </header>

        {/* MAIN VIEWPORT CONTENT */}
        <main className="flex-1 overflow-y-auto">
          {loadingInitial ? (
            <div className="p-10 text-center space-y-3">
              <GitaAvatar size="lg" />
              <div className="text-xs font-semibold text-[#7C2D86]">
                Gita AI aapki kundli aur rashi taiyar kar rahi hain...
              </div>
            </div>
          ) : (
            <>
              {/* 1. HOME SCREEN */}
              {activeScreen === "home" && (
                <div className="p-4 space-y-5 pb-24">
                  {/* Hero Character & Welcome Card */}
                  <div className="bg-gradient-to-br from-[#FFF9F5] via-[#FDF3EE] to-[#F7E5EC] border border-[#EFE1E6] rounded-3xl p-5 shadow-sm relative overflow-hidden">
                    <div className="flex items-center gap-4">
                      <GitaAvatar size="lg" showOnline={true} />
                      <div className="flex-1">
                        <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-[#7C2D86]/10 text-[#7C2D86] text-[10px] font-bold uppercase tracking-wider">
                          <Sparkles className="w-3 h-3" /> Vedic AI Astrologer
                        </span>
                        <h1 className="text-lg font-serif-vedic text-[#2A162D] mt-1 leading-snug">
                          {appConfig.welcome_message ||
                            "Namaste! Main Gita hoon. Aaj aap kya jaana chahte hain?"}
                        </h1>
                        <p className="text-xs text-[#6E5273] mt-1">
                          {user?.name ? `Swagat hai, ${user.name} ji` : "Swagat hai"} •{" "}
                          <span className="font-semibold text-[#7C2D86]">
                            {user?.rashi || "Mesh (Aries)"}
                          </span>
                        </p>
                      </div>
                    </div>

                    {/* Prominent Chat with Gita AI CTA */}
                    <div className="mt-4">
                      <button
                        onClick={() => setActiveScreen("chat")}
                        className="w-full py-3.5 px-6 rounded-full bg-gradient-to-r from-[#7C2D86] via-[#C93B76] to-[#E14B7B] text-white font-bold text-sm shadow-md hover:opacity-95 transition flex items-center justify-center gap-2 cursor-pointer"
                      >
                        <MessageCircleHeart className="w-4 h-4" />
                        <span>Chat with Gita AI</span>
                        {user?.entitlement?.trialEligible &&
                          !user?.entitlement?.isSubscribed && (
                            <span className="ml-1 px-2 py-0.5 rounded-full bg-white/20 text-[10px] font-mono-vedic">
                              15s Free Trial
                            </span>
                          )}
                      </button>
                    </div>
                  </div>

                  {/* 8 QUICK-ACTION CARDS */}
                  <div>
                    <div className="flex items-center justify-between mb-2.5">
                      <h2 className="text-sm font-bold text-[#2A162D]">
                        Aaj Aap Kis Vishay Par Margdarshan Chahte Hain?
                      </h2>
                      <span className="text-[11px] text-[#7C2D86] font-semibold">
                        8 Topics
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-2.5">
                      {quickActionCards.map((card) => {
                        const Icon = card.icon;
                        return (
                          <button
                            key={card.label}
                            onClick={() =>
                              handleQuickTopicSelect(card.label, card.prompt)
                            }
                            className={`p-3.5 rounded-2xl bg-gradient-to-br ${card.color} border border-[#EFE1E6] hover:border-[#7C2D86]/50 text-left transition flex items-start gap-3 cursor-pointer shadow-2xs`}
                          >
                            <div className="w-9 h-9 rounded-xl bg-white/90 text-[#7C2D86] flex items-center justify-center shrink-0 shadow-2xs">
                              <Icon className="w-4 h-4" />
                            </div>
                            <div className="min-w-0">
                              <div className="text-xs font-bold text-[#2A162D] truncate">
                                {card.label}
                              </div>
                              <div className="text-[11px] text-[#6E5273] truncate">
                                {card.hindiLabel}
                              </div>
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {/* DAILY HOROSCOPE, LUCKY COLOUR, LUCKY NUMBER & DAILY GUIDANCE */}
                  {homeHoroscope && (
                    <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 shadow-xs space-y-3.5">
                      <div className="flex items-center justify-between">
                        <div>
                          <span className="text-[10px] font-mono-vedic uppercase tracking-wider text-[#B8860B] font-bold">
                            Aaj Ka Rashifal & Panchang Sanket
                          </span>
                          <h3 className="text-base font-serif-vedic text-[#2A162D]">
                            {homeHoroscope.symbol} {homeHoroscope.rashi} —{" "}
                            {homeHoroscope.rashiHindi}
                          </h3>
                        </div>
                        <button
                          onClick={() => setActiveScreen("horoscope")}
                          className="text-xs font-semibold text-[#7C2D86] flex items-center gap-0.5 cursor-pointer"
                        >
                          All 12 Rashis <ChevronRight className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <p className="text-xs text-[#2A162D] leading-relaxed bg-[#FDF3EE] p-3.5 rounded-2xl border border-[#EFE1E6]">
                        {user?.preferredLanguage === "hindi"
                          ? homeHoroscope.dailyForecastHindi
                          : user?.preferredLanguage === "english"
                          ? homeHoroscope.dailyForecastEnglish
                          : homeHoroscope.dailyForecastHinglish}
                      </p>

                      {/* Lucky Colour & Lucky Number Row */}
                      <div className="grid grid-cols-2 gap-2.5">
                        <div className="p-3 rounded-2xl bg-[#FFF9F5] border border-[#EFE1E6] flex items-center gap-2.5">
                          <span
                            className="w-6 h-6 rounded-full border border-black/10 shrink-0"
                            style={{
                              backgroundColor: homeHoroscope.luckyColorHex,
                            }}
                          />
                          <div className="min-w-0">
                            <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                              Lucky Colour
                            </div>
                            <div className="text-xs font-bold text-[#2A162D] truncate">
                              {homeHoroscope.luckyColor}
                            </div>
                          </div>
                        </div>

                        <div className="p-3 rounded-2xl bg-[#FFF9F5] border border-[#EFE1E6] flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-full bg-[#D4AF37]/20 text-[#B8860B] font-mono-vedic font-bold text-xs flex items-center justify-center shrink-0">
                            {homeHoroscope.luckyNumber}
                          </div>
                          <div>
                            <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                              Lucky Number
                            </div>
                            <div className="text-xs font-bold font-mono-vedic text-[#2A162D]">
                              Shubh Ank {homeHoroscope.luckyNumber}
                            </div>
                          </div>
                        </div>
                      </div>

                      {/* Daily Guidance & Positive Habit */}
                      <div className="p-3.5 rounded-2xl bg-gradient-to-r from-[#7C2D86]/5 to-[#D4AF37]/10 border border-[#D4AF37]/30 text-xs space-y-1">
                        <div className="font-bold text-[#7C2D86]">
                          ✨ Aaj Ka Vichar & Sakaratmak Aadat (Daily Guidance):
                        </div>
                        <p className="text-[#2A162D]">
                          {homeHoroscope.dailyReflection}
                        </p>
                        <p className="text-[11px] text-[#6E5273] pt-1">
                          <strong>Suggested Habit:</strong>{" "}
                          {homeHoroscope.positiveHabit}
                        </p>
                      </div>
                    </div>
                  )}

                  {/* SUBSCRIPTION CTA BANNER & ACCOUNT PROFILE SHORTCUT */}
                  <div className="grid grid-cols-1 gap-3">
                    <div className="bg-gradient-to-r from-[#2A162D] via-[#4A1D52] to-[#7C2D86] text-white rounded-3xl p-4 flex items-center justify-between gap-3 shadow-sm">
                      <div>
                        <span className="text-[10px] font-mono-vedic uppercase tracking-wider px-2 py-0.5 rounded-full bg-[#D4AF37]/25 text-[#FFD966] font-semibold">
                          Gita AI Ashirwad Plan
                        </span>
                        <h3 className="text-sm font-bold mt-1">
                          Unlimited AI Astrologer @ ₹49/month
                        </h3>
                        <p className="text-[11px] text-[#E5D4E8] mt-0.5">
                          {user?.entitlement?.isSubscribed
                            ? "Your ₹49/month subscription is Active & Verified."
                            : "15-second free trial for eligible new users • Server-verified UPI & Play Billing"}
                        </p>
                      </div>
                      <button
                        onClick={() => setActiveScreen("subscription")}
                        className="px-4 py-2.5 rounded-full bg-[#D4AF37] text-[#2A162D] font-bold text-xs shrink-0 hover:opacity-95 cursor-pointer"
                      >
                        {user?.entitlement?.isSubscribed
                          ? "Manage"
                          : "₹49/mo Plan"}
                      </button>
                    </div>

                    {/* Account / Profile & Saved Readings Quick Bar */}
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => setActiveScreen("profile")}
                        className="p-3 rounded-2xl bg-white border border-[#EFE1E6] text-xs font-semibold text-[#2A162D] flex flex-col items-center gap-1 hover:border-[#7C2D86] cursor-pointer"
                      >
                        <User className="w-4 h-4 text-[#7C2D86]" />
                        <span>My Profile</span>
                      </button>
                      <button
                        onClick={() => setActiveScreen("saved")}
                        className="p-3 rounded-2xl bg-white border border-[#EFE1E6] text-xs font-semibold text-[#2A162D] flex flex-col items-center gap-1 hover:border-[#7C2D86] cursor-pointer"
                      >
                        <Bookmark className="w-4 h-4 text-[#E14B7B]" />
                        <span>Saved ({savedReadingsList.length})</span>
                      </button>
                      <button
                        onClick={() => setActiveScreen("auth")}
                        className="p-3 rounded-2xl bg-white border border-[#EFE1E6] text-xs font-semibold text-[#2A162D] flex flex-col items-center gap-1 hover:border-[#7C2D86] cursor-pointer"
                      >
                        <LogIn className="w-4 h-4 text-[#B8860B]" />
                        <span>Switch / Login</span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 2. AI ASTROLOGER CHAT & 15-SECOND FREE TRIAL SCREEN */}
              {activeScreen === "chat" && (
                <div className="flex flex-col h-[calc(100vh-158px)]">
                  {/* 15-SECOND TRIAL / SUBSCRIPTION STATUS BANNER */}
                  <div className="px-4 py-2.5 bg-[#FDF3EE] border-b border-[#EFE1E6]">
                    {user?.entitlement?.isSubscribed ? (
                      <div className="flex items-center justify-between text-xs">
                        <span className="inline-flex items-center gap-1.5 font-semibold text-[#1E7E5A]">
                          <CheckCircle2 className="w-4 h-4" />
                          ₹49/Month Premium Active — Unlimited Chat
                        </span>
                        <span className="text-[11px] font-mono-vedic text-[#6E5273]">
                          {user.rashi}
                        </span>
                      </div>
                    ) : trialRunning ? (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-[#D97706] flex items-center gap-1.5">
                            <Clock className="w-4 h-4 animate-spin" />
                            15-Second Free Trial Active!
                          </span>
                          <span className="font-mono-vedic font-bold text-sm text-[#C93B2B]">
                            00:{String(trialCountdown).padStart(2, "0")}s left
                          </span>
                        </div>
                        <div className="w-full h-1.5 rounded-full bg-[#EFE1E6] overflow-hidden">
                          <div
                            className="h-full bg-gradient-to-r from-[#7C2D86] via-[#E14B7B] to-[#D97706] transition-all duration-700"
                            style={{
                              width: `${(trialCountdown / 15) * 100}%`,
                            }}
                          />
                        </div>
                      </div>
                    ) : user?.entitlement?.trialEligible ? (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[#7C2D86] font-semibold">
                          ✨ 15-Second Free Trial Ready — Starts on your first
                          chat!
                        </span>
                        <span className="font-mono-vedic font-bold text-[#B8860B]">
                          00:15s
                        </span>
                      </div>
                    ) : (
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-[#C93B2B] font-bold">
                          🔒 15s Free Trial Ended — Subscribe ₹49/mo to Chat
                        </span>
                        <button
                          onClick={() => setActiveScreen("subscription")}
                          className="px-3 py-1 rounded-full bg-[#7C2D86] text-white font-semibold text-[11px] cursor-pointer"
                        >
                          Unlock ₹49/mo
                        </button>
                      </div>
                    )}
                  </div>

                  {/* Topic & Inline Birth Details Bar */}
                  <div className="px-4 py-2 bg-white border-b border-[#EFE1E6] flex items-center justify-between gap-2 text-xs">
                    <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
                      {[
                        "Personal Guidance",
                        "Career",
                        "Love & Relationships",
                        "Marriage",
                        "Money",
                        "Kundli",
                      ].map((t) => (
                        <button
                          key={t}
                          onClick={() => setSelectedTopic(t)}
                          className={`px-2.5 py-1 rounded-full text-[11px] font-semibold whitespace-nowrap cursor-pointer ${
                            selectedTopic === t
                              ? "bg-[#7C2D86] text-white"
                              : "bg-[#FDF3EE] text-[#6E5273]"
                          }`}
                        >
                          {t}
                        </button>
                      ))}
                    </div>

                    <button
                      onClick={() =>
                        setShowInlineBirthBar(!showInlineBirthBar)
                      }
                      className="px-2.5 py-1 rounded-full border border-[#D4AF37] text-[#B8860B] text-[11px] font-semibold shrink-0 cursor-pointer"
                    >
                      Janm Detail
                    </button>
                  </div>

                  {showInlineBirthBar && (
                    <div className="px-4 py-3 bg-[#FFF9F5] border-b border-[#EFE1E6] grid grid-cols-3 gap-2 text-xs">
                      <div>
                        <label className="block text-[10px] font-semibold text-[#6E5273]">
                          Birth Date
                        </label>
                        <input
                          type="date"
                          value={kundliDate}
                          onChange={(e) => setKundliDate(e.target.value)}
                          className="w-full h-8 px-2 rounded-lg bg-white border border-[#E5D4E8] text-[11px] font-mono-vedic"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-semibold text-[#6E5273]">
                          Time (Opt)
                        </label>
                        <input
                          type="time"
                          value={kundliTime}
                          onChange={(e) => setKundliTime(e.target.value)}
                          className="w-full h-8 px-2 rounded-lg bg-white border border-[#E5D4E8] text-[11px] font-mono-vedic"
                        />
                      </div>
                      <div>
                        <label className="block text-[10px] font-semibold text-[#6E5273]">
                          Place (Opt)
                        </label>
                        <input
                          type="text"
                          placeholder="City"
                          value={kundliPlace}
                          onChange={(e) => setKundliPlace(e.target.value)}
                          className="w-full h-8 px-2 rounded-lg bg-white border border-[#E5D4E8] text-[11px]"
                        />
                      </div>
                    </div>
                  )}

                  {/* Chat Messages List */}
                  <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
                    {/* Ethical Astrology Disclaimer Pill */}
                    <div className="p-2.5 rounded-2xl bg-[#FDF3EE] border border-[#EFE1E6] text-[11px] text-[#6E5273] text-center leading-relaxed">
                      <Info className="w-3.5 h-3.5 inline mr-1 text-[#7C2D86]" />
                      Astrology is for entertainment and personal reflection, not
                      guaranteed prediction or professional medical, legal, or
                      financial advice.
                    </div>

                    {messages.map((msg) => {
                      const isAssistant = msg.role === "assistant";
                      return (
                        <div
                          key={msg.id}
                          className={`flex flex-col ${
                            isAssistant ? "items-start" : "items-end"
                          }`}
                        >
                          <div
                            className={`max-w-[86%] rounded-2xl p-3.5 text-xs leading-relaxed shadow-2xs ${
                              isAssistant
                                ? "bg-white border-l-4 border-l-[#D4AF37] border border-[#EFE1E6] text-[#2A162D] rounded-tl-xs"
                                : "bg-[#7C2D86] text-white rounded-tr-xs"
                            }`}
                          >
                            {isAssistant && (
                              <div className="flex items-center justify-between gap-2 mb-1.5 pb-1 border-b border-[#EFE1E6]">
                                <span className="font-bold text-[11px] text-[#7C2D86]">
                                  Gita AI • {msg.topic}
                                </span>
                                <button
                                  onClick={() =>
                                    handleToggleSaveReading(msg.id)
                                  }
                                  title="Save Reading"
                                  className={`p-1 rounded-full cursor-pointer ${
                                    msg.isSavedReading
                                      ? "text-[#E14B7B]"
                                      : "text-[#6E5273] hover:text-[#2A162D]"
                                  }`}
                                >
                                  <Bookmark
                                    className="w-3.5 h-3.5"
                                    fill={
                                      msg.isSavedReading
                                        ? "currentColor"
                                        : "none"
                                    }
                                  />
                                </button>
                              </div>
                            )}
                            <div className="whitespace-pre-line">
                              {msg.content}
                            </div>
                            <div
                              className={`text-[10px] mt-1.5 font-mono-vedic ${
                                isAssistant
                                  ? "text-[#6E5273]"
                                  : "text-white/75 text-right"
                              }`}
                            >
                              {new Date(msg.createdAt).toLocaleTimeString([], {
                                hour: "2-digit",
                                minute: "2-digit",
                              })}
                            </div>
                          </div>
                        </div>
                      );
                    })}

                    {chatSending && (
                      <div className="flex items-start gap-2">
                        <div className="bg-white border border-[#EFE1E6] rounded-2xl p-3 text-xs text-[#7C2D86] flex items-center gap-2">
                          <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                          <span>
                            Gita ji aapki rashi aur prashn ka vishleshan kar
                            rahi hain...
                          </span>
                        </div>
                      </div>
                    )}

                    {/* Trial Expired Paywall Card inside Chat */}
                    {user &&
                      !user.entitlement.isSubscribed &&
                      (user.entitlement.trialExpired ||
                        (!trialRunning && user.trialUsed)) && (
                        <div className="bg-gradient-to-br from-[#FFF9F5] via-[#FDF3EE] to-[#F7E5EC] border-2 border-[#D4AF37] rounded-3xl p-5 text-center shadow-md space-y-3 my-2">
                          <Lock className="w-7 h-7 text-[#7C2D86] mx-auto" />
                          <h3 className="text-base font-serif-vedic text-[#2A162D]">
                            15-Second Free Trial Samapt Ho Gaya Hai
                          </h3>
                          <p className="text-xs text-[#6E5273] leading-relaxed">
                            Gita AI ke saath apni baat-cheet aur vyaktigat
                            kundli margdarshan jari rakhne ke liye{" "}
                            <strong className="text-[#2A162D]">
                              ₹49/month
                            </strong>{" "}
                            plan activate karein.
                          </p>
                          <div className="flex flex-col sm:flex-row gap-2 justify-center">
                            <button
                              onClick={() => setActiveScreen("subscription")}
                              className="py-3 px-6 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white font-bold text-xs shadow-md cursor-pointer"
                            >
                              Subscribe Now — ₹49/month
                            </button>
                            <button
                              onClick={handleResetTrialForQA}
                              className="py-2.5 px-4 rounded-full border border-[#7C2D86]/30 text-[#7C2D86] font-semibold text-xs cursor-pointer"
                            >
                              QA: Reset 15s Trial
                            </button>
                          </div>
                        </div>
                      )}

                    <div ref={chatEndRef} />
                  </div>

                  {/* Chat Composer Bar */}
                  <form
                    onSubmit={(e) => handleSendMessage(e)}
                    className="p-3 bg-white border-t border-[#EFE1E6] flex items-center gap-2"
                  >
                    <input
                      type="text"
                      placeholder={
                        user &&
                        !user.entitlement.isSubscribed &&
                        user.entitlement.trialExpired
                          ? "Subscribe ₹49/month to continue chatting..."
                          : "Gita ji se Hindi, Hinglish ya English mein poochhein..."
                      }
                      value={chatInput}
                      onChange={(e) => setChatInput(e.target.value)}
                      className="flex-1 h-11 px-4 rounded-full bg-[#FDF3EE] border border-[#E5D4E8] text-xs focus:outline-none focus:border-[#7C2D86]"
                    />
                    <button
                      type="submit"
                      disabled={chatSending}
                      className="w-11 h-11 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white flex items-center justify-center shrink-0 shadow-sm hover:opacity-95 cursor-pointer disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </form>
                </div>
              )}

              {/* 3. KUNDLI & BIRTH DETAILS SCREEN */}
              {activeScreen === "kundli" && (
                <div className="p-4 space-y-5 pb-24">
                  {/* Birth Details Form */}
                  <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 shadow-xs space-y-4">
                    <div>
                      <span className="text-[10px] font-mono-vedic uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#7C2D86]/10 text-[#7C2D86] font-bold">
                        Vedic Janm Kundli & Graha Reflection
                      </span>
                      <h2 className="text-lg font-serif-vedic text-[#2A162D] mt-1">
                        Apna Janm Vivaran (Birth Details) Darj Karein
                      </h2>
                      <p className="text-xs text-[#6E5273] mt-0.5">
                        <strong>Birth Date</strong> anivarya (required) hai.{" "}
                        <strong>Birth Time</strong> aur{" "}
                        <strong>Birthplace</strong> optional hain (agar samay
                        pata na ho toh Chandra/Surya Rashi ke aadhar par
                        margdarshan milega).
                      </p>
                    </div>

                    {kundliError && (
                      <div className="p-3 rounded-xl bg-[#C93B2B]/10 border border-[#C93B2B]/30 text-[#C93B2B] text-xs">
                        {kundliError}
                      </div>
                    )}

                    <form
                      onSubmit={handleGenerateKundli}
                      className="space-y-3.5"
                    >
                      <div>
                        <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                          Aapka Naam (Full Name) *
                        </label>
                        <input
                          type="text"
                          required
                          value={kundliName}
                          onChange={(e) => setKundliName(e.target.value)}
                          placeholder="e.g., Aarav Sharma"
                          className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                        />
                      </div>

                      <div>
                        <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                          Janm Tithi (Birth Date — Required) *
                        </label>
                        <div className="relative">
                          <input
                            type="date"
                            required
                            value={kundliDate}
                            onChange={(e) => setKundliDate(e.target.value)}
                            className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs font-mono-vedic"
                          />
                        </div>
                      </div>

                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                            Janm Samay (Birth Time — Optional)
                          </label>
                          <input
                            type="time"
                            value={kundliTime}
                            onChange={(e) => setKundliTime(e.target.value)}
                            className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs font-mono-vedic"
                          />
                          <span className="text-[10px] text-[#6E5273] mt-0.5 block">
                            Leave blank if exact birth time is unknown.
                          </span>
                        </div>

                        <div>
                          <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                            Janm Sthan (Birthplace — Optional)
                          </label>
                          <input
                            type="text"
                            value={kundliPlace}
                            onChange={(e) => setKundliPlace(e.target.value)}
                            placeholder="e.g., Jaipur, Rajasthan"
                            className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                          />
                          <span className="text-[10px] text-[#6E5273] mt-0.5 block">
                            Optional city/state for local meridian reference.
                          </span>
                        </div>
                      </div>

                      <button
                        type="submit"
                        disabled={kundliGenerating}
                        className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white font-bold text-xs shadow-md hover:opacity-95 transition cursor-pointer"
                      >
                        {kundliGenerating
                          ? "Calculating Sidereal Rashi & Kundli..."
                          : "Generate Kundli & Personalized Reading ✨"}
                      </button>
                    </form>
                  </div>

                  {/* Generated Kundli Chart & AI Interpretation */}
                  {latestKundli && (
                    <div className="space-y-4">
                      {/* Transparent Calculation Mode Label */}
                      <div className="p-3.5 rounded-2xl bg-[#D4AF37]/15 border border-[#D4AF37]/50 text-xs text-[#2A162D]">
                        <div className="font-bold text-[#B8860B]">
                          Calculation Methodology Disclosure:
                        </div>
                        <p className="text-[11px] text-[#6E5273] mt-0.5">
                          {latestKundli.calculationMode ===
                          "solar_lunar_ephemeris"
                            ? "Sidereal Lahiri Mean Ephemeris Approximation & AI-Guided Jyotish Reflection (Birth Date + Optional Time provided)."
                            : "General AI-Generated Astrology-Style Guidance (Using Noon Chandra/Surya Rashi approximation)."}
                        </p>
                      </div>

                      <NorthIndianKundliChart
                        houses={latestKundli.houses}
                        lagnaSign={latestKundli.lagnaSign}
                        chandraRashi={latestKundli.chandraRashi}
                      />

                      {/* Key Astrological Pillars */}
                      <div className="grid grid-cols-2 gap-2.5">
                        <div className="bg-white p-3.5 rounded-2xl border border-[#EFE1E6]">
                          <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                            Chandra Rashi (Moon)
                          </div>
                          <div className="text-xs font-bold text-[#7C2D86] mt-0.5">
                            {latestKundli.chandraRashi}
                          </div>
                        </div>
                        <div className="bg-white p-3.5 rounded-2xl border border-[#EFE1E6]">
                          <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                            Janm Nakshatra
                          </div>
                          <div className="text-xs font-bold text-[#2A162D] mt-0.5">
                            {latestKundli.nakshatra}
                          </div>
                        </div>
                        <div className="bg-white p-3.5 rounded-2xl border border-[#EFE1E6]">
                          <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                            Surya Rashi (Sun)
                          </div>
                          <div className="text-xs font-bold text-[#2A162D] mt-0.5">
                            {latestKundli.suryaRashi}
                          </div>
                        </div>
                        <div className="bg-white p-3.5 rounded-2xl border border-[#EFE1E6]">
                          <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                            Lagna (Ascendant)
                          </div>
                          <div className="text-xs font-bold text-[#B8860B] mt-0.5">
                            {latestKundli.lagnaSign}
                          </div>
                        </div>
                      </div>

                      {/* Gita AI Interpretation Card */}
                      <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 space-y-3">
                        <div className="flex items-center gap-2.5">
                          <GitaAvatar size="sm" />
                          <div>
                            <h4 className="text-xs font-bold text-[#2A162D]">
                              Gita AI Ka Kundli Margdarshan
                            </h4>
                            <span className="text-[10px] text-[#6E5273]">
                              For {latestKundli.name} ({latestKundli.birthDate})
                            </span>
                          </div>
                        </div>
                        <p className="text-xs text-[#2A162D] leading-relaxed bg-[#FDF3EE] p-3.5 rounded-2xl">
                          {latestKundli.aiInterpretation}
                        </p>
                        <button
                          onClick={() => {
                            setSelectedTopic("Kundli");
                            setChatInput(
                              `Namaste Gita ji! Meri Kundli (${latestKundli.chandraRashi}, ${latestKundli.nakshatra} Nakshatra, Lagna ${latestKundli.lagnaSign}) ke anusaar mere career aur vivah ke baare mein vistar se batayein.`
                            );
                            setActiveScreen("chat");
                          }}
                          className="w-full py-3 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white font-semibold text-xs shadow-sm cursor-pointer"
                        >
                          Continue Conversation with Gita AI about this Kundli →
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* 4. DAILY HOROSCOPE & ZODIAC SIGN INFO SCREEN */}
              {activeScreen === "horoscope" && (
                <div className="p-4 space-y-5 pb-24">
                  <div>
                    <span className="text-[10px] font-mono-vedic uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#D4AF37]/20 text-[#B8860B] font-bold">
                      12 Vedic Rashis • Dainik Rashifal
                    </span>
                    <h2 className="text-xl font-serif-vedic text-[#2A162D] mt-1">
                      Daily Horoscope & Rashi Wisdom
                    </h2>
                  </div>

                  {/* 12 Rashi Horizontal / Grid Selector */}
                  <div className="grid grid-cols-3 gap-2">
                    {horoscopes.map((h) => {
                      const active = h.rashi === activeHoroscope?.rashi;
                      return (
                        <button
                          key={h.id}
                          onClick={() => setSelectedRashiFilter(h.rashi)}
                          className={`p-2.5 rounded-2xl border text-left transition cursor-pointer ${
                            active
                              ? "bg-[#7C2D86] text-white border-[#7C2D86] shadow-xs"
                              : "bg-white border-[#EFE1E6] text-[#2A162D] hover:bg-[#FDF3EE]"
                          }`}
                        >
                          <div className="text-base">{h.symbol}</div>
                          <div className="text-[11px] font-bold truncate mt-0.5">
                            {h.rashi.split(" ")[0]}
                          </div>
                          <div
                            className={`text-[10px] truncate ${
                              active ? "text-white/80" : "text-[#6E5273]"
                            }`}
                          >
                            {h.rashiHindi}
                          </div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Selected Rashi Detailed Card */}
                  {activeHoroscope && (
                    <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 shadow-xs space-y-4">
                      <div className="flex items-center justify-between border-b border-[#EFE1E6] pb-3">
                        <div>
                          <h3 className="text-lg font-serif-vedic text-[#2A162D]">
                            {activeHoroscope.symbol} {activeHoroscope.rashi}
                          </h3>
                          <p className="text-xs text-[#7C2D86] font-semibold">
                            {activeHoroscope.rashiHindi} • Tatva:{" "}
                            {activeHoroscope.element} • Swami:{" "}
                            {activeHoroscope.rulingPlanet}
                          </p>
                        </div>
                      </div>

                      <div className="p-4 rounded-2xl bg-[#FDF3EE] text-xs text-[#2A162D] leading-relaxed">
                        {user?.preferredLanguage === "hindi"
                          ? activeHoroscope.dailyForecastHindi
                          : user?.preferredLanguage === "english"
                          ? activeHoroscope.dailyForecastEnglish
                          : activeHoroscope.dailyForecastHinglish}
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div className="p-3.5 rounded-2xl bg-[#FFF9F5] border border-[#EFE1E6] flex items-center gap-2.5">
                          <span
                            className="w-7 h-7 rounded-full border border-black/10 shrink-0"
                            style={{
                              backgroundColor: activeHoroscope.luckyColorHex,
                            }}
                          />
                          <div>
                            <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                              Lucky Colour
                            </div>
                            <div className="text-xs font-bold text-[#2A162D]">
                              {activeHoroscope.luckyColor}
                            </div>
                          </div>
                        </div>

                        <div className="p-3.5 rounded-2xl bg-[#FFF9F5] border border-[#EFE1E6] flex items-center gap-2.5">
                          <div className="w-7 h-7 rounded-full bg-[#D4AF37]/25 text-[#B8860B] font-mono-vedic font-bold text-xs flex items-center justify-center shrink-0">
                            {activeHoroscope.luckyNumber}
                          </div>
                          <div>
                            <div className="text-[10px] uppercase text-[#6E5273] font-semibold">
                              Lucky Number
                            </div>
                            <div className="text-xs font-bold text-[#2A162D]">
                              Ank {activeHoroscope.luckyNumber}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="p-4 rounded-2xl bg-[#FFF9F5] border border-[#EFE1E6] space-y-2 text-xs">
                        <div>
                          <strong className="text-[#7C2D86]">
                            Daily Reflection:
                          </strong>{" "}
                          {activeHoroscope.dailyReflection}
                        </div>
                        <div>
                          <strong className="text-[#1E7E5A]">
                            Suggested Positive Habit:
                          </strong>{" "}
                          {activeHoroscope.positiveHabit}
                        </div>
                      </div>

                      <button
                        onClick={() => {
                          setSelectedTopic("Daily Horoscope");
                          setChatInput(
                            `Namaste Gita ji! Meri rashi ${activeHoroscope.rashi} ke anusaar aaj ke din ko aur shubh banane ke liye main kya karoon?`
                          );
                          setActiveScreen("chat");
                        }}
                        className="w-full py-3 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white font-semibold text-xs cursor-pointer"
                      >
                        Ask Gita AI About {activeHoroscope.rashi} →
                      </button>
                    </div>
                  )}
                </div>
              )}

              {/* 5. REMEDIES & POSITIVE RITUALS SCREEN */}
              {activeScreen === "remedies" && (
                <div className="p-4 space-y-5 pb-24">
                  <div className="bg-gradient-to-br from-[#FFF9F5] to-[#FDF3EE] border border-[#EFE1E6] rounded-3xl p-5 space-y-2">
                    <span className="text-[10px] font-mono-vedic uppercase tracking-wider px-2.5 py-0.5 rounded-full bg-[#1E7E5A]/15 text-[#1E7E5A] font-bold">
                      Non-Fear-Based Positive Remedies
                    </span>
                    <h2 className="text-lg font-serif-vedic text-[#2A162D]">
                      Dainik Sakaratmak Upay & Rituals
                    </h2>
                    <p className="text-xs text-[#6E5273] leading-relaxed">
                      Gita AI ke upay dhyan, mantra, kritagyata (gratitude) aur
                      acchi aadaton par aadharit hain — bina kisi dar ya mehenge
                      ratno ke dabav ke.
                    </p>
                  </div>

                  {/* Remedy Checklist */}
                  <div className="space-y-3">
                    {remediesList.map((rem) => (
                      <div
                        key={rem.id}
                        className={`p-4 rounded-2xl border transition ${
                          rem.isCompleted
                            ? "bg-[#1E7E5A]/5 border-[#1E7E5A]/30"
                            : "bg-white border-[#EFE1E6]"
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <button
                            onClick={async () => {
                              const res = await fetch("/api/remedies", {
                                method: "POST",
                                headers: {
                                  "Content-Type": "application/json",
                                  ...(token
                                    ? { Authorization: `Bearer ${token}` }
                                    : {}),
                                },
                                body: JSON.stringify({
                                  action: "toggle_complete",
                                  userId: user?.id,
                                  remedyId: rem.id,
                                }),
                              });
                              if (res.ok) {
                                const data = await res.json();
                                setRemediesList((prev) =>
                                  prev.map((r) =>
                                    r.id === rem.id ? data.remedy : r
                                  )
                                );
                              }
                            }}
                            className="flex items-start gap-3 text-left flex-1 cursor-pointer"
                          >
                            <div
                              className={`w-6 h-6 rounded-full flex items-center justify-center shrink-0 mt-0.5 ${
                                rem.isCompleted
                                  ? "bg-[#1E7E5A] text-white"
                                  : "border-2 border-[#7C2D86] text-transparent"
                              }`}
                            >
                              <CheckCircle2 className="w-4 h-4" />
                            </div>
                            <div>
                              <span className="text-[10px] font-semibold uppercase tracking-wider text-[#7C2D86]">
                                {rem.category} • Streak: {rem.streakCount} days
                              </span>
                              <h4
                                className={`text-xs font-bold mt-0.5 ${
                                  rem.isCompleted
                                    ? "line-through text-[#6E5273]"
                                    : "text-[#2A162D]"
                                }`}
                              >
                                {rem.title}
                              </h4>
                              <p className="text-xs text-[#6E5273] mt-1 leading-relaxed">
                                {rem.description}
                              </p>
                              {rem.mantraOrAction && (
                                <div className="mt-2 px-3 py-1.5 rounded-xl bg-[#FDF3EE] text-[11px] font-semibold text-[#B8860B]">
                                  🙏 {rem.mantraOrAction}
                                </div>
                              )}
                              {rem.completedAt && (
                                <div className="text-[10px] font-mono-vedic text-[#1E7E5A] mt-1.5">
                                  ✓ Completed on{" "}
                                  {new Date(rem.completedAt).toLocaleString()}
                                </div>
                              )}
                            </div>
                          </button>

                          <button
                            onClick={async () => {
                              await fetch("/api/remedies", {
                                method: "POST",
                                headers: {
                                  "Content-Type": "application/json",
                                  ...(token
                                    ? { Authorization: `Bearer ${token}` }
                                    : {}),
                                },
                                body: JSON.stringify({
                                  action: "delete_remedy",
                                  userId: user?.id,
                                  remedyId: rem.id,
                                }),
                              });
                              setRemediesList((prev) =>
                                prev.filter((r) => r.id !== rem.id)
                              );
                            }}
                            className="text-[#6E5273] hover:text-[#C93B2B] p-1 cursor-pointer"
                            title="Delete Remedy"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Save Custom Remedy / Personal Ritual Form */}
                  <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 space-y-3">
                    <h3 className="text-sm font-bold text-[#2A162D] flex items-center gap-1.5">
                      <Plus className="w-4 h-4 text-[#7C2D86]" />
                      Apna Naya Sankalp ya Upay Jodein (Save New Remedy)
                    </h3>
                    <input
                      type="text"
                      placeholder="Ritual Title (e.g., Gayatri Mantra 11 Times)"
                      value={newRemedyTitle}
                      onChange={(e) => setNewRemedyTitle(e.target.value)}
                      className="w-full h-10 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                    />
                    <input
                      type="text"
                      placeholder="Description / Daily Reflection goal"
                      value={newRemedyDesc}
                      onChange={(e) => setNewRemedyDesc(e.target.value)}
                      className="w-full h-10 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                    />
                    <input
                      type="text"
                      placeholder="Mantra or Action Note (Optional)"
                      value={newRemedyMantra}
                      onChange={(e) => setNewRemedyMantra(e.target.value)}
                      className="w-full h-10 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                    />
                    <button
                      type="button"
                      onClick={async () => {
                        if (!newRemedyTitle || !newRemedyDesc) return;
                        const res = await fetch("/api/remedies", {
                          method: "POST",
                          headers: {
                            "Content-Type": "application/json",
                            ...(token
                              ? { Authorization: `Bearer ${token}` }
                              : {}),
                          },
                          body: JSON.stringify({
                            action: "add_remedy",
                            userId: user?.id,
                            title: newRemedyTitle,
                            description: newRemedyDesc,
                            mantraOrAction: newRemedyMantra,
                            category: "Personal Sankalp",
                          }),
                        });
                        if (res.ok) {
                          const data = await res.json();
                          setRemediesList((prev) => [data.remedy, ...prev]);
                          setNewRemedyTitle("");
                          setNewRemedyDesc("");
                          setNewRemedyMantra("");
                        }
                      }}
                      className="w-full py-3 rounded-full bg-[#7C2D86] text-white font-semibold text-xs cursor-pointer"
                    >
                      Save Personal Ritual
                    </button>
                  </div>
                </div>
              )}

              {/* 6. SAVED READINGS & CHAT HISTORY SCREEN */}
              {activeScreen === "saved" && (
                <div className="p-4 space-y-5 pb-24">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-lg font-serif-vedic text-[#2A162D]">
                        Saved Readings & Chat History
                      </h2>
                      <p className="text-xs text-[#6E5273]">
                        Aapke dwara bookmark kiye gaye Gita AI ke vishleshan aur
                        pichli baat-cheet.
                      </p>
                    </div>
                    <button
                      onClick={async () => {
                        const res = await fetch("/api/chat", {
                          method: "POST",
                          headers: {
                            "Content-Type": "application/json",
                            ...(token
                              ? { Authorization: `Bearer ${token}` }
                              : {}),
                          },
                          body: JSON.stringify({
                            action: "clear_history",
                            userId: user?.id,
                          }),
                        });
                        if (res.ok) {
                          const data = await res.json();
                          setMessages(data.messages || []);
                        }
                      }}
                      className="px-3 py-1.5 rounded-full border border-[#C93B2B]/30 text-[#C93B2B] text-[11px] font-semibold cursor-pointer"
                    >
                      Clear History
                    </button>
                  </div>

                  {/* Bookmarked Readings */}
                  <div className="space-y-2.5">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#7C2D86]">
                      ★ Bookmarked Readings ({savedReadingsList.length})
                    </h3>
                    {savedReadingsList.length === 0 ? (
                      <div className="p-5 rounded-2xl bg-white border border-[#EFE1E6] text-xs text-[#6E5273] text-center">
                        Koi saved reading nahi hai. Chat mein bookmark icon
                        dabakar kisi bhi margdarshan ko yahan save karein.
                      </div>
                    ) : (
                      savedReadingsList.map((item) => (
                        <div
                          key={item.id}
                          className="bg-white p-4 rounded-2xl border-l-4 border-l-[#D4AF37] border border-[#EFE1E6] space-y-1.5 text-xs"
                        >
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-[#7C2D86]">
                              {item.topic}
                            </span>
                            <span className="text-[10px] font-mono-vedic text-[#6E5273]">
                              {new Date(item.createdAt).toLocaleString()}
                            </span>
                          </div>
                          <p className="text-[#2A162D] whitespace-pre-line leading-relaxed">
                            {item.content}
                          </p>
                        </div>
                      ))
                    )}
                  </div>

                  {/* Full Conversation History */}
                  <div className="space-y-2.5">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-[#2A162D]">
                      Complete Chat Transcript ({messages.length} messages)
                    </h3>
                    <div className="space-y-2">
                      {messages.map((m) => (
                        <div
                          key={m.id}
                          className="p-3.5 rounded-2xl bg-white border border-[#EFE1E6] text-xs"
                        >
                          <div className="flex items-center justify-between mb-1">
                            <span className="font-bold text-[#7C2D86] uppercase text-[10px]">
                              {m.role === "assistant" ? "Gita AI" : user?.name}{" "}
                              • {m.topic}
                            </span>
                            <span className="text-[10px] font-mono-vedic text-[#6E5273]">
                              {new Date(m.createdAt).toLocaleTimeString()}
                            </span>
                          </div>
                          <p className="text-[#2A162D] line-clamp-3">
                            {m.content}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* 7. PREMIUM SUBSCRIPTION & PAYMENT STATUS SCREEN */}
              {activeScreen === "subscription" && (
                <SubscriptionScreens
                  token={token}
                  userId={user?.id}
                  trialExpiredReason={user?.entitlement?.trialExpired}
                  onEntitlementUpdated={() => loadAllData(token)}
                  onNavigateLegal={(sec) => {
                    setLegalSection(sec);
                    setActiveScreen("legal");
                  }}
                  onStartChat={() => setActiveScreen("chat")}
                  onResetTrialForQA={handleResetTrialForQA}
                />
              )}

              {/* 8. USER PROFILE, REMINDERS & SETTINGS SCREEN */}
              {activeScreen === "profile" && user && (
                <div className="p-4 space-y-5 pb-24">
                  <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-[#7C2D86] to-[#E14B7B] text-white font-serif-vedic text-lg flex items-center justify-center">
                          {user.name.charAt(0)}
                        </div>
                        <div>
                          <h2 className="text-base font-bold text-[#2A162D]">
                            {user.name}
                          </h2>
                          <p className="text-xs text-[#6E5273] font-mono-vedic">
                            {user.email}
                          </p>
                          <span className="inline-block mt-0.5 px-2 py-0.5 rounded-full bg-[#7C2D86]/10 text-[#7C2D86] text-[10px] font-bold">
                            {user.rashi} • {user.nakshatra}
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={() => setActiveScreen("auth")}
                        className="px-3 py-1.5 rounded-full bg-[#FDF3EE] border border-[#7C2D86]/30 text-xs font-semibold text-[#7C2D86] cursor-pointer"
                      >
                        Switch Account
                      </button>
                    </div>

                    {profileSavedToast && (
                      <div className="p-3 rounded-xl bg-[#1E7E5A]/15 text-[#1E7E5A] text-xs font-semibold">
                        {profileSavedToast}
                      </div>
                    )}

                    {/* Edit Profile & Birth Details Form */}
                    <form
                      onSubmit={async (e) => {
                        e.preventDefault();
                        const res = await fetch("/api/auth", {
                          method: "POST",
                          headers: {
                            "Content-Type": "application/json",
                            ...(token
                              ? { Authorization: `Bearer ${token}` }
                              : {}),
                          },
                          body: JSON.stringify({
                            action: "update_profile",
                            userId: user.id,
                            name: user.name,
                            phone: user.phone,
                            preferredLanguage: user.preferredLanguage,
                            birthDate: user.birthDate,
                            birthTime: user.birthTime,
                            birthPlace: user.birthPlace,
                            notificationsEnabled: user.notificationsEnabled,
                            reminderTime: user.reminderTime,
                          }),
                        });
                        if (res.ok) {
                          const data = await res.json();
                          setProfileSavedToast(data.message);
                          await loadAllData(token);
                          setTimeout(() => setProfileSavedToast(null), 3500);
                        }
                      }}
                      className="space-y-3 pt-2 border-t border-[#EFE1E6]"
                    >
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <div>
                          <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                            Full Name
                          </label>
                          <input
                            type="text"
                            value={user.name}
                            onChange={(e) =>
                              setUser({ ...user, name: e.target.value })
                            }
                            className="w-full h-10 px-3 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                          />
                        </div>
                        <div>
                          <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                            Preferred Language
                          </label>
                          <select
                            value={user.preferredLanguage}
                            onChange={(e) =>
                              setUser({
                                ...user,
                                preferredLanguage: e.target.value as
                                  | "hinglish"
                                  | "hindi"
                                  | "english",
                              })
                            }
                            className="w-full h-10 px-3 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                          >
                            <option value="hinglish">Hinglish (Default)</option>
                            <option value="hindi">हिंदी (Hindi)</option>
                            <option value="english">English</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-3 gap-2">
                        <div>
                          <label className="block text-[11px] font-semibold text-[#2A162D] mb-1">
                            Birth Date
                          </label>
                          <input
                            type="date"
                            value={user.birthDate || ""}
                            onChange={(e) =>
                              setUser({ ...user, birthDate: e.target.value })
                            }
                            className="w-full h-10 px-2.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs font-mono-vedic"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-[#2A162D] mb-1">
                            Time (Opt)
                          </label>
                          <input
                            type="time"
                            value={user.birthTime || ""}
                            onChange={(e) =>
                              setUser({ ...user, birthTime: e.target.value })
                            }
                            className="w-full h-10 px-2.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs font-mono-vedic"
                          />
                        </div>
                        <div>
                          <label className="block text-[11px] font-semibold text-[#2A162D] mb-1">
                            Birthplace (Opt)
                          </label>
                          <input
                            type="text"
                            value={user.birthPlace || ""}
                            onChange={(e) =>
                              setUser({ ...user, birthPlace: e.target.value })
                            }
                            className="w-full h-10 px-2.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                          />
                        </div>
                      </div>

                      {/* Optional Daily Horoscope Reminder with Explicit Permission */}
                      <div className="p-3.5 rounded-2xl bg-[#FFF9F5] border border-[#EFE1E6] flex items-center justify-between gap-3">
                        <div className="flex items-center gap-2.5">
                          <Bell className="w-4 h-4 text-[#7C2D86]" />
                          <div>
                            <div className="text-xs font-bold text-[#2A162D]">
                              Daily Horoscope Reminder (Optional)
                            </div>
                            <div className="text-[11px] text-[#6E5273]">
                              Explicit notification consent for morning Rashi
                              guidance
                            </div>
                          </div>
                        </div>
                        <input
                          type="checkbox"
                          checked={user.notificationsEnabled}
                          onChange={async (e) => {
                            const nextChecked = e.target.checked;
                            if (
                              nextChecked &&
                              typeof window !== "undefined" &&
                              "Notification" in window
                            ) {
                              await Notification.requestPermission();
                            }
                            setUser({
                              ...user,
                              notificationsEnabled: nextChecked,
                            });
                          }}
                          className="w-4 h-4 accent-[#7C2D86] cursor-pointer"
                        />
                      </div>

                      <button
                        type="submit"
                        className="w-full py-3 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white font-semibold text-xs shadow-sm cursor-pointer"
                      >
                        Save Profile & Astrology Preferences
                      </button>
                    </form>
                  </div>

                  {/* Quick Links to All Required Screens */}
                  <div className="bg-white rounded-3xl border border-[#EFE1E6] divide-y divide-[#EFE1E6] overflow-hidden text-xs">
                    {[
                      {
                        label: "Subscription Management (₹49/month)",
                        action: () => setActiveScreen("subscription"),
                      },
                      {
                        label: "Saved Readings & Chat History",
                        action: () => setActiveScreen("saved"),
                      },
                      {
                        label: "Privacy Policy (DPDP & Play Store Compliant)",
                        action: () => {
                          setLegalSection("privacy");
                          setActiveScreen("legal");
                        },
                      },
                      {
                        label: "Terms and Conditions",
                        action: () => {
                          setLegalSection("terms");
                          setActiveScreen("legal");
                        },
                      },
                      {
                        label: "Help and Support",
                        action: () => {
                          setLegalSection("help");
                          setActiveScreen("legal");
                        },
                      },
                      {
                        label: "Account & Personal Data Deletion",
                        action: () => {
                          setLegalSection("delete_account");
                          setActiveScreen("legal");
                        },
                        danger: true,
                      },
                    ].map((item, idx) => (
                      <button
                        key={idx}
                        onClick={item.action}
                        className={`w-full p-4 text-left font-semibold flex items-center justify-between hover:bg-[#FDF3EE] transition cursor-pointer ${
                          item.danger ? "text-[#C93B2B]" : "text-[#2A162D]"
                        }`}
                      >
                        <span>{item.label}</span>
                        <ChevronRight className="w-4 h-4 opacity-60" />
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* 9. AUTHENTICATION SCREEN */}
              {activeScreen === "auth" && (
                <AuthScreenView
                  onAuthSuccess={async ({ token: newToken }) => {
                    localStorage.setItem("gita_ai_token", newToken);
                    setToken(newToken);
                    await loadAllData(newToken);
                    setActiveScreen("home");
                  }}
                  onBack={() => setActiveScreen("home")}
                />
              )}

              {/* 10. ONBOARDING SCREEN */}
              {activeScreen === "onboarding" && (
                <OnboardingView onFinish={() => setActiveScreen("home")} />
              )}

              {/* 11. LEGAL, SUPPORT & ACCOUNT DELETION SCREENS */}
              {activeScreen === "legal" && (
                <LegalAndSupportView
                  section={legalSection}
                  onSelectSection={setLegalSection}
                  onBack={() => setActiveScreen("profile")}
                  onDeleteAccount={async (reason) => {
                    const res = await fetch("/api/auth", {
                      method: "POST",
                      headers: {
                        "Content-Type": "application/json",
                        ...(token
                          ? { Authorization: `Bearer ${token}` }
                          : {}),
                      },
                      body: JSON.stringify({
                        action: "delete_account",
                        userId: user?.id,
                        reason,
                      }),
                    });
                    if (res.ok) {
                      await loadAllData(token);
                      setActiveScreen("home");
                    }
                  }}
                />
              )}
            </>
          )}
        </main>

        {/* BOTTOM ANDROID NAVIGATION BAR (5 Tabs) */}
        <nav className="sticky bottom-0 z-30 bg-[#FFF9F5]/95 backdrop-blur-md border-t border-[#EFE1E6] px-2 py-1.5 grid grid-cols-5 gap-1">
          {[
            { id: "home", label: "Home", icon: Home },
            { id: "chat", label: "Gita Chat", icon: MessageCircleHeart },
            { id: "kundli", label: "Kundli", icon: Compass },
            { id: "remedies", label: "Remedies", icon: Sparkles },
            { id: "profile", label: "Profile", icon: User },
          ].map((nav) => {
            const Icon = nav.icon;
            const active = activeScreen === nav.id;
            return (
              <button
                key={nav.id}
                onClick={() => setActiveScreen(nav.id as ScreenTab)}
                className={`py-1.5 rounded-2xl flex flex-col items-center justify-center gap-0.5 transition cursor-pointer ${
                  active
                    ? "text-[#7C2D86] font-bold bg-[#7C2D86]/10"
                    : "text-[#6E5273] font-medium hover:text-[#2A162D]"
                }`}
              >
                <Icon className="w-5 h-5" />
                <span className="text-[10px]">{nav.label}</span>
              </button>
            );
          })}
        </nav>
      </div>
    </div>
  );
}
