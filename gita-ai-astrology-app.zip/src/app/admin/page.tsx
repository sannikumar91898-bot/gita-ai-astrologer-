"use client";

import React, { useState, useEffect } from "react";
import { AdminDashboardView } from "@/components/AdminDashboardView";
import { useRouter } from "next/navigation";

export default function AdminPage() {
  const router = useRouter();
  const [token, setToken] = useState<string | null>(null);
  const [role, setRole] = useState<string>("user");
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const savedToken =
      typeof window !== "undefined"
        ? localStorage.getItem("gita_ai_token")
        : null;

    fetch("/api/auth", {
      headers: savedToken ? { Authorization: `Bearer ${savedToken}` } : {},
    })
      .then((r) => r.json())
      .then((data) => {
        if (data.token) {
          setToken(data.token);
          localStorage.setItem("gita_ai_token", data.token);
        }
        if (data.user?.role) {
          setRole(data.user.role);
        }
        setReady(true);
      })
      .catch(() => setReady(true));
  }, []);

  const handleSwitchToAdmin = async () => {
    const res = await fetch("/api/auth", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "switch_account",
        email: "admin@gita-ai.in",
      }),
    });
    const data = await res.json();
    if (data.token) {
      localStorage.setItem("gita_ai_token", data.token);
      setToken(data.token);
      setRole(data.user?.role || "admin");
    }
  };

  if (!ready) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] flex items-center justify-center text-sm text-[#6E5273]">
        Verifying RBAC Administrator Session...
      </div>
    );
  }

  return (
    <AdminDashboardView
      token={token}
      currentUserRole={role}
      onSwitchToAdminAccount={handleSwitchToAdmin}
      onBackToApp={() => router.push("/")}
    />
  );
}
