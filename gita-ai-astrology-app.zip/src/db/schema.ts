import {
  pgTable,
  serial,
  varchar,
  text,
  boolean,
  integer,
  timestamp,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  phone: varchar("phone", { length: 32 }),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  name: varchar("name", { length: 120 }).notNull(),
  role: varchar("role", { length: 32 }).notNull().default("user"), // 'user' | 'admin'
  preferredLanguage: varchar("preferred_language", { length: 32 })
    .notNull()
    .default("hinglish"), // 'hinglish' | 'hindi' | 'english'
  birthDate: varchar("birth_date", { length: 32 }), // YYYY-MM-DD
  birthTime: varchar("birth_time", { length: 32 }), // HH:mm (optional)
  birthPlace: varchar("birth_place", { length: 160 }), // City, State (optional)
  rashi: varchar("rashi", { length: 64 }).default("Mesh (Aries)"),
  nakshatra: varchar("nakshatra", { length: 64 }).default("Ashwini"),
  consentGiven: boolean("consent_given").notNull().default(true),
  notificationsEnabled: boolean("notifications_enabled").notNull().default(false),
  reminderTime: varchar("reminder_time", { length: 16 }).default("08:00"),
  trialStartedAt: timestamp("trial_started_at"),
  trialUsed: boolean("trial_used").notNull().default(false),
  subscriptionStatus: varchar("subscription_status", { length: 32 })
    .notNull()
    .default("none"), // 'none' | 'trial' | 'active' | 'pending' | 'failed' | 'cancelled' | 'expired' | 'refunded'
  subscriptionPlan: varchar("subscription_plan", { length: 64 }).default(
    "monthly_49"
  ),
  subscriptionExpiresAt: timestamp("subscription_expires_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  sessionId: varchar("session_id", { length: 64 }).notNull(),
  topic: varchar("topic", { length: 64 }).notNull().default("Personal Guidance"),
  role: varchar("role", { length: 24 }).notNull(), // 'user' | 'assistant'
  content: text("content").notNull(),
  isSavedReading: boolean("is_saved_reading").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const kundliReadings = pgTable("kundli_readings", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 120 }).notNull(),
  birthDate: varchar("birth_date", { length: 32 }).notNull(),
  birthTime: varchar("birth_time", { length: 32 }),
  birthPlace: varchar("birth_place", { length: 160 }),
  calculationMode: varchar("calculation_mode", { length: 64 })
    .notNull()
    .default("solar_lunar_ephemeris"), // 'solar_lunar_ephemeris' | 'ai_general_guidance'
  lagnaSign: varchar("lagna_sign", { length: 64 }).notNull(),
  chandraRashi: varchar("chandra_rashi", { length: 64 }).notNull(),
  suryaRashi: varchar("surya_rashi", { length: 64 }).notNull(),
  nakshatra: varchar("nakshatra", { length: 64 }).notNull(),
  planetaryPositions: text("planetary_positions").notNull(), // JSON string of 12 houses & grahas
  aiInterpretation: text("ai_interpretation").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const remedies = pgTable("remedies", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  title: varchar("title", { length: 180 }).notNull(),
  category: varchar("category", { length: 64 }).notNull().default("Mindfulness"),
  description: text("description").notNull(),
  mantraOrAction: text("mantra_or_action"),
  isCompleted: boolean("is_completed").notNull().default(false),
  completedAt: timestamp("completed_at"),
  streakCount: integer("streak_count").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const payments = pgTable("payments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .notNull()
    .references(() => users.id, { onDelete: "cascade" }),
  orderId: varchar("order_id", { length: 128 }).notNull().unique(),
  recipientUpiId: varchar("recipient_upi_id", { length: 128 })
    .notNull()
    .default("7250595155@ibl"),
  provider: varchar("provider", { length: 64 }).notNull(), // 'phonepe' | 'google_pay' | 'paytm' | 'bhim' | 'any_upi_qr' | 'other_person_phone'
  amountInr: integer("amount_inr").notNull().default(49),
  status: varchar("status", { length: 32 }).notNull().default("pending"), // 'pending' | 'verified' | 'failed' | 'refunded' | 'cancelled' | 'expired'
  submittedUtr: varchar("submitted_utr", { length: 64 }),
  providerTransactionId: varchar("provider_transaction_id", { length: 128 }),
  verificationMethod: varchar("verification_method", { length: 64 }),
  failureReason: text("failure_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  verifiedAt: timestamp("verified_at"),
});

export const auditLogs = pgTable("audit_logs", {
  id: serial("id").primaryKey(),
  actorUserId: integer("actor_user_id"),
  targetUserId: integer("target_user_id"),
  eventType: varchar("event_type", { length: 64 }).notNull(),
  details: text("details").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const dailyHoroscopes = pgTable("daily_horoscopes", {
  id: serial("id").primaryKey(),
  rashi: varchar("rashi", { length: 64 }).notNull().unique(),
  rashiHindi: varchar("rashi_hindi", { length: 64 }).notNull(),
  symbol: varchar("symbol", { length: 32 }).notNull(),
  element: varchar("element", { length: 32 }).notNull(),
  rulingPlanet: varchar("ruling_planet", { length: 64 }).notNull(),
  dailyForecastHinglish: text("daily_forecast_hinglish").notNull(),
  dailyForecastHindi: text("daily_forecast_hindi").notNull(),
  dailyForecastEnglish: text("daily_forecast_english").notNull(),
  luckyColor: varchar("lucky_color", { length: 64 }).notNull(),
  luckyColorHex: varchar("lucky_color_hex", { length: 16 }).notNull(),
  luckyNumber: varchar("lucky_number", { length: 16 }).notNull(),
  dailyReflection: text("daily_reflection").notNull(),
  positiveHabit: text("positive_habit").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const appConfig = pgTable("app_config", {
  key: varchar("key", { length: 64 }).primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});
