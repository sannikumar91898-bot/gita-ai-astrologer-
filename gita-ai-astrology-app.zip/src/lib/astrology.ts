export interface RashiInfo {
  rashi: string;
  rashiHindi: string;
  englishName: string;
  symbol: string;
  element: string;
  rulingPlanet: string;
  rulingPlanetHindi: string;
  luckyColor: string;
  luckyColorHex: string;
  luckyNumber: string;
  dailyForecastHinglish: string;
  dailyForecastHindi: string;
  dailyForecastEnglish: string;
  dailyReflection: string;
  positiveHabit: string;
}

export const TWELVE_RASHIS: RashiInfo[] = [
  {
    rashi: "Mesh (Aries)",
    rashiHindi: "मेष (Mesh)",
    englishName: "Aries",
    symbol: "♈",
    element: "Agni (Fire)",
    rulingPlanet: "Mangal (Mars)",
    rulingPlanetHindi: "मंगल",
    luckyColor: "Saffron Coral (केसरिया)",
    luckyColorHex: "#E85D04",
    luckyNumber: "9",
    dailyForecastHinglish:
      "Aaj aapki urja aur aatmavishwas nayi unchaiyon par rahega. Career mein kisi naye project ki shuruat ke liye din shubh hai, bas jaldbaazi mein faisla lene se bachein.",
    dailyForecastHindi:
      "आज आपकी ऊर्जा और आत्मविश्वास नई ऊंचाइयों पर रहेगा। करियर में किसी नए प्रोजेक्ट की शुरुआत के लिए दिन शुभ है, बस जल्दबाजी में निर्णय लेने से बचें।",
    dailyForecastEnglish:
      "Your vitality and self-confidence are vibrant today. It is an auspicious day to initiate a new career milestone, provided you pace yourself and avoid impulsive reactions.",
    dailyReflection:
      "Dharya aur sahas ka santulan hi asli safalta ki kunji hai. (Patience paired with courage unlocks lasting fulfillment.)",
    positiveHabit:
      "Subah 5 minute gehri saans (Pranayama) lein aur din ke 3 mukhya lakshya likhein.",
  },
  {
    rashi: "Vrishabha (Taurus)",
    rashiHindi: "वृषभ (Vrishabha)",
    englishName: "Taurus",
    symbol: "♉",
    element: "Prithvi (Earth)",
    rulingPlanet: "Shukra (Venus)",
    rulingPlanetHindi: "शुक्र",
    luckyColor: "Lotus Pink (कमल गुलाबी)",
    luckyColorHex: "#E14B7B",
    luckyNumber: "6",
    dailyForecastHinglish:
      "Aaj parivar aur arthik maamlon mein sthirta aayegi. Aapki meethi vaani se rishton mein mithas badhegi aur kisi purane mitra se acchi khabar mil sakti hai.",
    dailyForecastHindi:
      "आज परिवार और आर्थिक मामलों में स्थिरता आएगी। आपकी मधुर वाणी से रिश्तों में मिठास बढ़ेगी और किसी पुराने मित्र से शुभ समाचार मिल सकता है।",
    dailyForecastEnglish:
      "Stability graces your family and financial plans today. Warm communication deepens bonds, and a pleasant update from an old friend may brighten your evening.",
    dailyReflection:
      "Kritagyata (gratitude) man ko shanti aur samriddhi ki ore le jaati hai.",
    positiveHabit:
      "Aaj apne ghar ke kisi sadasya ki dil se tareef karein aur shukriya kahein.",
  },
  {
    rashi: "Mithuna (Gemini)",
    rashiHindi: "मिथुन (Mithuna)",
    englishName: "Gemini",
    symbol: "♊",
    element: "Vayu (Air)",
    rulingPlanet: "Budh (Mercury)",
    rulingPlanetHindi: "बुध",
    luckyColor: "Emerald Mint (पन्ना हरा)",
    luckyColorHex: "#1E7E5A",
    luckyNumber: "5",
    dailyForecastHinglish:
      "Aapki rachnatmak soch aur communication skills aaj sabko prabhavit karengi. Naye vichar aur networking se career mein accha avsar milne ke sanket hain.",
    dailyForecastHindi:
      "आपकी रचनात्मक सोच और संवाद कौशल आज सबको प्रभावित करेंगे। नए विचार और नेटवर्किंग से करियर में अच्छा अवसर मिलने के संकेत हैं।",
    dailyForecastEnglish:
      "Your creative intellect and clear communication shine today. Fresh ideas and thoughtful networking open promising doors in your professional path.",
    dailyReflection:
      "Jab man shant hota hai, tabhi sabse spasht vichar janm lete hain.",
    positiveHabit:
      "Raat ko sone se 30 minute pehle phone door rakhein aur kuch prerak padhein.",
  },
  {
    rashi: "Karka (Cancer)",
    rashiHindi: "कर्क (Karka)",
    englishName: "Cancer",
    symbol: "♋",
    element: "Jal (Water)",
    rulingPlanet: "Chandra (Moon)",
    rulingPlanetHindi: "चन्द्र",
    luckyColor: "Pearl Cream (मोती क्रीम)",
    luckyColorHex: "#D4AF37",
    luckyNumber: "2",
    dailyForecastHinglish:
      "Apne antardrishti (intuition) par bharosa rakhein. Ghar-parivar ke saath bitaya samay aapko mansik sukoon dega. Bhavnaon mein behkar bada kharcha na karein.",
    dailyForecastHindi:
      "अपनी अंतर्दृष्टि पर भरोसा रखें। घर-परिवार के साथ बिताया समय आपको मानसिक सुकून देगा। भावनाओं में बहकर बड़ा खर्च न करें।",
    dailyForecastEnglish:
      "Trust your gentle intuition today. Quality time with loved ones brings deep emotional peace. Be mindful of emotional spending and nurture your inner calm.",
    dailyReflection:
      "Apनी bhavnaon ko samajhna aur sweekarna aatmik shakti ki nishani hai.",
    positiveHabit:
      "Shaam ko thoda samay prakriti ya khuli hawa mein tehlein aur jal ka sevan badhayein.",
  },
  {
    rashi: "Simha (Leo)",
    rashiHindi: "सिंह (Simha)",
    englishName: "Leo",
    symbol: "♌",
    element: "Agni (Fire)",
    rulingPlanet: "Surya (Sun)",
    rulingPlanetHindi: "सूर्य",
    luckyColor: "Marigold Gold (स्वर्ण पीला)",
    luckyColorHex: "#D97706",
    luckyNumber: "1",
    dailyForecastHinglish:
      "Surya ki tarah aapka vyaktitva aaj chamkega. Leadership role ya team ke saath kaam mein aapko samman milega. Vinamrata banaye rakhne se sabka sahyog milega.",
    dailyForecastHindi:
      "सूर्य की तरह आपका व्यक्तित्व आज चमकेगा। नेतृत्व या टीम के साथ काम में आपको सम्मान मिलेगा। विनम्रता बनाए रखने से सबका सहयोग मिलेगा।",
    dailyForecastEnglish:
      "Your natural warmth and leadership radiate brightly today. Recognition at work comes naturally when you pair confidence with genuine humility.",
    dailyReflection:
      "Saccha netritva doosron ko prakash dene mein hai, sirf khud chamakne mein nahi.",
    positiveHabit:
      "Subah ugate surya ki roshni mein 5 minute baithein aur sakaratmak sankalp lein.",
  },
  {
    rashi: "Kanya (Virgo)",
    rashiHindi: "कन्या (Kanya)",
    englishName: "Virgo",
    symbol: "♍",
    element: "Prithvi (Earth)",
    rulingPlanet: "Budh (Mercury)",
    rulingPlanetHindi: "बुध",
    luckyColor: "Sage Olive (तुलसी हरा)",
    luckyColorHex: "#2E8B57",
    luckyNumber: "5",
    dailyForecastHinglish:
      "Aaj aapki planning aur discipline se ruke hue kaam poore honge. Sehat aur dincharya par dhyan dene ke liye behtareen din hai. Khud par zyada sakhti na karein.",
    dailyForecastHindi:
      "आज आपकी योजना और अनुशासन से रुके हुए काम पूरे होंगे। सेहत और दिनचर्या पर ध्यान देने के लिए बेहतरीन दिन है। खुद पर ज्यादा सख्ती न करें।",
    dailyForecastEnglish:
      "Methodical planning helps you complete pending tasks effortlessly today. It is an ideal day to refine your wellness routine while practicing self-compassion.",
    dailyReflection:
      "Har chota sudhar kal ki badi kamiyabi ki neev rakhta hai.",
    positiveHabit:
      "Apne kaam ki jagah (desk) ko vyavasthit karein aur ek chota task aaj hi poora karein.",
  },
  {
    rashi: "Tula (Libra)",
    rashiHindi: "तुला (Tula)",
    englishName: "Libra",
    symbol: "♎",
    element: "Vayu (Air)",
    rulingPlanet: "Shukra (Venus)",
    rulingPlanetHindi: "शुक्र",
    luckyColor: "Royal Rose (राजसी गुलाबी)",
    luckyColorHex: "#C026D3",
    luckyNumber: "6",
    dailyForecastHinglish:
      "Rishton aur kaam ke beech accha santulan banega. Jeevan-saathi ya kisi khaas vyakti ke saath samajhdari bhari baat-cheet se man halka aur khush hoga.",
    dailyForecastHindi:
      "रिश्तों और काम के बीच अच्छा संतुलन बनेगा। जीवनसाथी या किसी खास व्यक्ति के साथ समझदारी भरी बातचीत से मन हल्का और प्रसन्न होगा।",
    dailyForecastEnglish:
      "Harmony returns between your work and personal relationships. Heartfelt dialogue with a partner or close confidant brings clarity and mutual joy.",
    dailyReflection:
      "Santulan bahar dhoondhne se nahi, bheetar ki shanti se aata hai.",
    positiveHabit:
      "Aaj kisi bhi vivad mein pehle doosre paksh ki baat dhyan se sunne ka abhyas karein.",
  },
  {
    rashi: "Vrishchika (Scorpio)",
    rashiHindi: "वृश्चिक (Vrishchika)",
    englishName: "Scorpio",
    symbol: "♏",
    element: "Jal (Water)",
    rulingPlanet: "Mangal (Mars)",
    rulingPlanetHindi: "मंगल",
    luckyColor: "Deep Mulberry (गहरा जामुनी)",
    luckyColorHex: "#7C2D86",
    luckyNumber: "9",
    dailyForecastHinglish:
      "Aapki lagan aur gehri soch kisi mushkil sawal ka hal nikalegi. Purani baaton ko chhodkar aage badhne ka samay hai. Dhyan (meditation) se man ko nayi shakti milegi.",
    dailyForecastHindi:
      "आपकी लगन और गहरी सोच किसी मुश्किल सवाल का हल निकालेगी। पुरानी बातों को छोड़कर आगे बढ़ने का समय है। ध्यान से मन को नई शक्ति मिलेगी।",
    dailyForecastEnglish:
      "Your focused determination uncovers solutions to complex matters today. Let go of past grievances and allow quiet mindfulness to renew your inner strength.",
    dailyReflection:
      "Kshama karna kamzori nahi, balki apne man ko azaad karne ka sabse bada upay hai.",
    positiveHabit:
      "Ek kagaz par apni chinta likhkar use chhodne ka sankalp lein aur gehri saans lein.",
  },
  {
    rashi: "Dhanu (Sagittarius)",
    rashiHindi: "धनु (Dhanu)",
    englishName: "Sagittarius",
    symbol: "♐",
    element: "Agni (Fire)",
    rulingPlanet: "Guru (Jupiter)",
    rulingPlanetHindi: "बृहस्पति (गुरु)",
    luckyColor: "Temple Gold (पीताम्बर स्वर्ण)",
    luckyColorHex: "#B8860B",
    luckyNumber: "3",
    dailyForecastHinglish:
      "Guru ki kripa se gyan, padhai aur bhavishya ki yojanaon mein pragati hogi. Kisi anubhavi vyakti ki salah aapke liye bahut labhkari sabit ho sakti hai.",
    dailyForecastHindi:
      "गुरु की प्रेरणा से ज्ञान, पढ़ाई और भविष्य की योजनाओं में प्रगति होगी। किसी अनुभवी व्यक्ति की सलाह आपके लिए बहुत लाभकारी साबित हो सकती है।",
    dailyForecastEnglish:
      "Optimism and wisdom guide your long-term plans and learning today. Seeking perspective from a trusted mentor brings inspiring clarity.",
    dailyReflection:
      "Jahan seekhne ki chah hoti hai, wahan har anubhav ek guru ban jaata hai.",
    positiveHabit:
      "Aaj 10 minute kisi nayi skill ya aadhyatmik vichar ko padhne mein lagayein.",
  },
  {
    rashi: "Makara (Capricorn)",
    rashiHindi: "मकर (Makara)",
    englishName: "Capricorn",
    symbol: "♑",
    element: "Prithvi (Earth)",
    rulingPlanet: "Shani (Saturn)",
    rulingPlanetHindi: "शनि",
    luckyColor: "Indigo Plum (नीलम बैंगनी)",
    luckyColorHex: "#4C1D95",
    luckyNumber: "8",
    dailyForecastHinglish:
      "Aapki mehnat aur imandari rang layegi. Career aur arthik paksh mein dheere-dheere parantu pakki safalta ke yog hain. Aaram ke liye bhi thoda waqt zaroor nikalein.",
    dailyForecastHindi:
      "आपकी मेहनत और ईमानदारी रंग लाएगी। करियर और आर्थिक पक्ष में धीरे-धीरे परंतु पक्की सफलता के योग हैं। विश्राम के लिए भी थोड़ा समय जरूर निकालें।",
    dailyForecastEnglish:
      "Steady perseverance yields dependable progress in your career and financial goals. Remember to balance hard work with restorative rest.",
    dailyReflection:
      "Shani humein sikhate hain ki dhairya aur karma ka phal hamesha sthayi hota hai.",
    positiveHabit:
      "Aaj kisi zarooratmand ki choti si madad karein aur apne kaam mein niyamita rakhein.",
  },
  {
    rashi: "Kumbha (Aquarius)",
    rashiHindi: "कुंभ (Kumbha)",
    englishName: "Aquarius",
    symbol: "♒",
    element: "Vayu (Air)",
    rulingPlanet: "Shani (Saturn)",
    rulingPlanetHindi: "शनि",
    luckyColor: "Royal Amethyst (नील-जामुनी)",
    luckyColorHex: "#6D28D9",
    luckyNumber: "8",
    dailyForecastHinglish:
      "Naye drishtikon aur samajik judav se man prasann rahega. Technology ya naye ideas par kaam karne walon ke liye aaj ka din nayi prerna lekar aayega.",
    dailyForecastHindi:
      "नए दृष्टिकोण और सामाजिक जुड़ाव से मन प्रसन्न रहेगा। तकनीक या नए विचारों पर काम करने वालों के लिए आज का दिन नई प्रेरणा लेकर आएगा।",
    dailyForecastEnglish:
      "Innovative thinking and community connection uplift your spirits today. Fresh perspectives help you solve old challenges with grace.",
    dailyReflection:
      "Jab hum samूह ki bhalai sochte hain, to hamara apna marg bhi prashast hota hai.",
    positiveHabit:
      "Apne kisi mitra ya sahyogi ka utsah badhayein aur naye vicharon ka swagat karein.",
  },
  {
    rashi: "Meena (Pisces)",
    rashiHindi: "मीन (Meena)",
    englishName: "Pisces",
    symbol: "♓",
    element: "Jal (Water)",
    rulingPlanet: "Guru (Jupiter)",
    rulingPlanetHindi: "बृहस्पति (गुरु)",
    luckyColor: "Sacred Marigold (पीला केसर)",
    luckyColorHex: "#D97706",
    luckyNumber: "3",
    dailyForecastHinglish:
      "Aadhyatmik shanti, sangeet aur rachnatmak kaamo mein man lagega. Aapki samvedansheelta doosron ko sukoon degi, bas apni urja ko nakaratmak logon se bachayein.",
    dailyForecastHindi:
      "आध्यात्मिक शांति, संगीत और रचनात्मक कार्यों में मन लगेगा। आपकी संवेदनशीलता दूसरों को सुकून देगी, बस अपनी ऊर्जा को नकारात्मकता से बचाएं।",
    dailyForecastEnglish:
      "Spiritual serenity and creative inspiration flow gently today. Your empathy comforts others—just remember to protect your own peaceful boundaries.",
    dailyReflection:
      "Man ki shanti sabse bada ratna hai; ise sneh aur dhyan se sanjoyein.",
    positiveHabit:
      "Sone se pehle 5 minute shant baithkar din bhar ki 3 acchi baaton ko yaad karein.",
  },
];

export const TWENTY_SEVEN_NAKSHATRAS = [
  "Ashwini",
  "Bharani",
  "Krittika",
  "Rohini",
  "Mrigashira",
  "Ardra",
  "Punarvasu",
  "Pushya",
  "Ashlesha",
  "Magha",
  "Purva Phalguni",
  "Uttara Phalguni",
  "Hasta",
  "Chitra",
  "Swati",
  "Vishakha",
  "Anuradha",
  "Jyeshtha",
  "Moola",
  "Purva Ashadha",
  "Uttara Ashadha",
  "Shravana",
  "Dhanishta",
  "Shatabhisha",
  "Purva Bhadrapada",
  "Uttara Bhadrapada",
  "Revati",
];

export interface KundliHouseData {
  houseNumber: number;
  rashiNumber: number;
  rashiName: string;
  grahas: string[];
  significance: string;
}

export interface CalculatedKundli {
  calculationMode: "solar_lunar_ephemeris" | "ai_general_guidance";
  disclaimerLabel: string;
  lagnaSign: string;
  suryaRashi: string;
  chandraRashi: string;
  nakshatra: string;
  rulingPlanet: string;
  element: string;
  houses: KundliHouseData[];
  summaryHinglish: string;
  summaryHindi: string;
  summaryEnglish: string;
}

/**
 * Calculates approximate Vedic Sidereal Surya Rashi, Chandra Rashi, Nakshatra, and Lagna
 * using Julian Day number + Lahiri Ayanamsa (~24 deg) approximation from birth date & optional time.
 * Always transparently labels the output so it never pretends to be a guaranteed prediction.
 */
export function calculateVedicKundli(params: {
  name: string;
  birthDate: string; // YYYY-MM-DD
  birthTime?: string | null; // HH:mm
  birthPlace?: string | null;
}): CalculatedKundli {
  const { name, birthDate, birthTime, birthPlace } = params;
  const parsedDate = new Date(birthDate + "T" + (birthTime && birthTime.trim() ? birthTime : "12:00") + ":00");
  const isValidDate = !isNaN(parsedDate.getTime());

  const year = isValidDate ? parsedDate.getFullYear() : 1998;
  const month = isValidDate ? parsedDate.getMonth() + 1 : 5;
  const day = isValidDate ? parsedDate.getDate() : 15;
  const hour = isValidDate ? parsedDate.getHours() + parsedDate.getMinutes() / 60 : 12;

  // Approximate Julian Day
  const a = Math.floor((14 - month) / 12);
  const y = year + 4800 - a;
  const m = month + 12 * a - 3;
  const jdn =
    day +
    Math.floor((153 * m + 2) / 5) +
    365 * y +
    Math.floor(y / 4) -
    Math.floor(y / 100) +
    Math.floor(y / 400) -
    32045 +
    (hour - 12) / 24;

  const daysSinceJ2000 = jdn - 2451545.0;

  // Mean Tropical Solar Longitude
  const meanSunLon = (280.46646 + 0.98564736 * daysSinceJ2000) % 360;
  const normalizedSunTropical = meanSunLon < 0 ? meanSunLon + 360 : meanSunLon;

  // Mean Tropical Lunar Longitude
  const meanMoonLon = (218.3165 + 13.17639648 * daysSinceJ2000) % 360;
  const normalizedMoonTropical = meanMoonLon < 0 ? meanMoonLon + 360 : meanMoonLon;

  // Lahiri Ayanamsa approximation (~23.85 deg at J2000 + precession)
  const ayanamsa = 23.85 + (daysSinceJ2000 / 365.25) * 0.01397;

  const siderealSun = (normalizedSunTropical - ayanamsa + 360) % 360;
  const siderealMoon = (normalizedMoonTropical - ayanamsa + 360) % 360;

  const suryaIndex = Math.floor(siderealSun / 30) % 12;
  const chandraIndex = Math.floor(siderealMoon / 30) % 12;
  const nakshatraIndex = Math.floor((siderealMoon / 360) * 27) % 27;

  // If birth time is provided, estimate Lagna (Ascendant rises ~1 sign every 2 hours from sunrise ~6 AM)
  const hasTime = Boolean(birthTime && birthTime.trim().length > 0);
  const hoursAfterSunrise = (hour - 6 + 24) % 24;
  const lagnaOffset = hasTime ? Math.floor(hoursAfterSunrise / 2) : 0;
  const lagnaIndex = (suryaIndex + lagnaOffset) % 12;

  const suryaInfo = TWELVE_RASHIS[suryaIndex] || TWELVE_RASHIS[0];
  const chandraInfo = TWELVE_RASHIS[chandraIndex] || TWELVE_RASHIS[0];
  const lagnaInfo = TWELVE_RASHIS[lagnaIndex] || TWELVE_RASHIS[0];
  const nakshatra = TWENTY_SEVEN_NAKSHATRAS[nakshatraIndex] || "Ashwini";

  // Approximate remaining graha sign indices for illustrative Vedic chart reflection
  const marsIdx = Math.floor(((daysSinceJ2000 * 0.524 + 120) % 360 + 360) % 360 / 30) % 12;
  const mercuryIdx = (suryaIndex + (day % 2 === 0 ? 0 : 1)) % 12;
  const jupiterIdx = Math.floor(((daysSinceJ2000 * 0.083 + 45) % 360 + 360) % 360 / 30) % 12;
  const venusIdx = (suryaIndex + (month % 2 === 0 ? 11 : 1)) % 12;
  const saturnIdx = Math.floor(((daysSinceJ2000 * 0.033 + 210) % 360 + 360) % 360 / 30) % 12;
  const rahuIdx = Math.floor(((360 - ((daysSinceJ2000 * 0.053) % 360) + 360) % 360) / 30) % 12;
  const ketuIdx = (rahuIdx + 6) % 12;

  const houseSignificances = [
    "Tan Bhava (Self, Personality & Vitality)",
    "Dhana Bhava (Values, Speech & Family Resources)",
    "Sahaja Bhava (Courage, Communication & Efforts)",
    "Sukha Bhava (Home, Inner Peace & Mother)",
    "Putra Bhava (Creativity, Intellect & Joy)",
    "Ripu Bhava (Daily Discipline, Wellness & Service)",
    "Yuvati Bhava (Partnerships, Marriage & Harmony)",
    "Randhra Bhava (Transformation & Inner Depth)",
    "Dharma Bhava (Wisdom, Higher Learning & Grace)",
    "Karma Bhava (Career, Purpose & Public Contribution)",
    "Labha Bhava (Aspirations, Community & Gains)",
    "Vyaya Bhava (Spiritual Reflection & Rest)",
  ];

  const houses: KundliHouseData[] = Array.from({ length: 12 }, (_, idx) => {
    const houseNumber = idx + 1;
    const signIndex = (lagnaIndex + idx) % 12;
    const grahas: string[] = [];
    if (idx === 0) grahas.push("Lagna (Asc)");
    if (signIndex === suryaIndex) grahas.push("Su (Surya)");
    if (signIndex === chandraIndex) grahas.push("Ch (Chandra)");
    if (signIndex === marsIdx) grahas.push("Ma (Mangal)");
    if (signIndex === mercuryIdx) grahas.push("Bu (Budh)");
    if (signIndex === jupiterIdx) grahas.push("Gu (Guru)");
    if (signIndex === venusIdx) grahas.push("Sk (Shukra)");
    if (signIndex === saturnIdx) grahas.push("Sa (Shani)");
    if (signIndex === rahuIdx) grahas.push("Ra (Rahu)");
    if (signIndex === ketuIdx) grahas.push("Ke (Ketu)");

    return {
      houseNumber,
      rashiNumber: signIndex + 1,
      rashiName: TWELVE_RASHIS[signIndex].rashi,
      grahas,
      significance: houseSignificances[idx],
    };
  });

  const calculationMode = hasTime ? "solar_lunar_ephemeris" : "ai_general_guidance";
  const disclaimerLabel = hasTime
    ? "Mean Sidereal Ephemeris Approximation & AI-Guided Jyotish Reflection (For personal reflection & entertainment — not an astronomical certainty)"
    : "General AI-Generated Astrology-Style Guidance (Birth time/place optional — uses Noon Chandra/Surya approximation)";

  const placeText = birthPlace && birthPlace.trim() ? birthPlace.trim() : "India (Standard Meridian)";

  const summaryHinglish = `Namaste ${name} ji! Aapki janm tithi (${birthDate}${hasTime ? `, samay ${birthTime}` : ""}) aur sthan (${placeText}) ke aadhar par aapki Chandra Rashi **${chandraInfo.rashi}** aur Janm Nakshatra **${nakshatra}** banta hai. Aapke swami grah **${chandraInfo.rulingPlanet}** hain jo aapko ${chandraInfo.element} tatva ki vishesh urja dete hain. ${
    hasTime
      ? `Aapka Lagna **${lagnaInfo.rashi}** hai, jo aapke vyaktitva mein aatmavishwas aur santulan darshata hai.`
      : `Janm samay na hone par humne Chandra aur Surya Rashi (${suryaInfo.rashi}) ke aadhar par yeh margdarshan taiyar kiya hai.`
  } Yeh vishleshan aत्म-chintan (self-reflection) aur sakaratmak disha ke liye hai.`;

  const summaryHindi = `नमस्ते ${name} जी! आपकी जन्म तिथि (${birthDate}) के आधार पर आपकी चंद्र राशि **${chandraInfo.rashiHindi}** और जन्म नक्षत्र **${nakshatra}** है। आपके स्वामी ग्रह **${chandraInfo.rulingPlanetHindi}** हैं। यह ज्योतिषीय मार्गदर्शन आत्म-चिंतन और सकारात्मक प्रेरणा के लिए तैयार किया गया है।`;

  const summaryEnglish = `Namaste ${name}! Based on your birth date (${birthDate}${hasTime ? ` at ${birthTime}` : ""}) and place (${placeText}), your Sidereal Moon Sign (Chandra Rashi) is **${chandraInfo.rashi}** and your birth star (Nakshatra) is **${nakshatra}**, guided by **${chandraInfo.rulingPlanet}**. This reading is crafted for personal reflection and mindful encouragement.`;

  return {
    calculationMode,
    disclaimerLabel,
    lagnaSign: lagnaInfo.rashi,
    suryaRashi: suryaInfo.rashi,
    chandraRashi: chandraInfo.rashi,
    nakshatra,
    rulingPlanet: chandraInfo.rulingPlanet,
    element: chandraInfo.element,
    houses,
    summaryHinglish,
    summaryHindi,
    summaryEnglish,
  };
}

export const DEFAULT_REMEDIES = [
  {
    title: "Pratah Surya Arghya & Sankalp",
    category: "Daily Ritual",
    description:
      "Subah ugate surya ko tambe ke patra se jal arpit karein ya 2 minute dhoop mein khade hokar din ke liye sakaratmak sankalp lein. Isse aatmavishwas aur man ki spashtata badhti hai.",
    mantraOrAction: "ॐ सूर्याय नमः (Om Suryaya Namah) — 11 baar shant man se",
  },
  {
    title: "Sandhya Deep & Gratitude Dhyan",
    category: "Mindfulness",
    description:
      "Shaam ko ghar mein ek shuddh ghee ya til ke tel ka diya jalayein aur 5 minute baithkar din bhar ki 3 acchi baaton ke liye ishwar ka aabhar vyakt karein.",
    mantraOrAction: "5 Minute Shant Shwas-Dhyan (Deep Breathing Reflection)",
  },
  {
    title: "Budh-Guru Vaani Sanrakshan",
    category: "Positive Habit",
    description:
      "Rishton aur career mein madhurta ke liye aaj kisi bhi vyakti se baat karte samay krodh ya jaldbaazi se bachein aur pehle poori baat dhyan se sunein.",
    mantraOrAction: "Samyak Vaani: Bolne se pehle 3 second ka shant viram",
  },
  {
    title: "Chandra Manah-Shanti Jal Upay",
    category: "Wellness & Calm",
    description:
      "Mansik tanav kam karne ke liye chandi ya kaanch ke gilas mein paani piyein aur raat ko sone se 30 minute pehle mobile screen se doori banayein.",
    mantraOrAction: "ॐ सोम सोमाय नमः (Om Som Somaya Namah) — Man ki shanti hetu",
  },
];
