import crypto from "crypto";

export const CONFIGURED_RECIPIENT_UPI_ID =
  process.env.MERCHANT_UPI_VPA?.trim() || "7250595155@ibl";

export const SUBSCRIPTION_PRICE_INR = 49;
export const SUBSCRIPTION_PRICE_PAISE = 4900;
export const PAYMENT_WINDOW_SECONDS = 5 * 60; // 300 seconds (5 minutes)

export const MERCHANT_DETAILS = {
  merchantName: "Gita AI",
  merchantLegalName: "Gita AI – Your Favorite Astrologer",
  merchantVpa: CONFIGURED_RECIPIENT_UPI_ID,
  recipientUpiId: CONFIGURED_RECIPIENT_UPI_ID,
  planId: "monthly_49",
  planName: "Gita AI Monthly Premium Subscription (30 Days)",
  amountInr: SUBSCRIPTION_PRICE_INR,
  currency: "INR",
};

export interface UpiUriValidationResult {
  valid: boolean;
  errors: string[];
  parameters: {
    pa: string;
    pn: string;
    am: string;
    cu: string;
    tr: string;
    tn: string;
  };
}

export interface UpiPaymentLinks {
  standardUpiUri: string;
  qrCodeUpiUri: string;
  phonePeUri: string;
  googlePayUri: string;
  paytmUri: string;
  bhimUri: string;
  validation: UpiUriValidationResult;
}

/**
 * Generates a strictly alphanumeric (NPCI UPI Spec v1.6 compliant) unique order reference.
 * Avoids underscores (_) or special characters which cause PhonePe, Paytm, and BHIM deep-link
 * validators to reject the transaction reference.
 */
export function generateUniqueOrderReference(userId: number): string {
  const timestamp = Date.now().toString(36).toUpperCase();
  const randomPart = crypto.randomBytes(4).toString("hex").toUpperCase();
  const rawOrder = `GITAORD${userId}${timestamp}${randomPart}`;
  return rawOrder.replace(/[^A-Z0-9]/g, "").slice(0, 32);
}

/**
 * Normalizes any order ID into a strictly alphanumeric NPCI `tr` reference.
 */
export function sanitizeUpiTransactionRef(orderId: string): string {
  return orderId.replace(/[^A-Za-z0-9]/g, "").slice(0, 35);
}

/**
 * Validates UPI payment request fields against NPCI UPI Linking Specification v1.6:
 * - pa: Valid VPA format (<handle>@<psp>) matching configured 7250595155@ibl
 * - pn: Payee name (1-50 chars, alphanumeric & spaces)
 * - am: Exact decimal amount ("49.00")
 * - cu: ISO currency code ("INR")
 * - tr: Alphanumeric transaction reference (6-35 chars, no underscores/symbols)
 * - tn: Alphanumeric transaction note (1-50 chars)
 */
export function validateUpiPaymentParameters(params: {
  pa: string;
  pn: string;
  am: string;
  cu: string;
  tr: string;
  tn: string;
}): UpiUriValidationResult {
  const errors: string[] = [];
  const vpaRegex = /^[a-zA-Z0-9.\-_]{2,256}@[a-zA-Z]{2,64}$/;
  const amountRegex = /^\d+\.\d{2}$/;
  const alphanumericRefRegex = /^[A-Za-z0-9]{6,35}$/;
  const safeTextRegex = /^[A-Za-z0-9 ]{1,50}$/;

  if (!vpaRegex.test(params.pa)) {
    errors.push(`Invalid payee VPA format (pa): '${params.pa}'.`);
  }
  if (params.pa.toLowerCase() !== CONFIGURED_RECIPIENT_UPI_ID.toLowerCase()) {
    errors.push(
      `Recipient VPA mismatch: expected '${CONFIGURED_RECIPIENT_UPI_ID}', got '${params.pa}'.`
    );
  }
  if (!safeTextRegex.test(params.pn)) {
    errors.push(`Invalid payee name (pn): '${params.pn}'.`);
  }
  if (
    !amountRegex.test(params.am) ||
    Number(params.am) !== SUBSCRIPTION_PRICE_INR
  ) {
    errors.push(
      `Invalid amount (am): expected '${SUBSCRIPTION_PRICE_INR}.00', got '${params.am}'.`
    );
  }
  if (params.cu !== "INR") {
    errors.push(`Invalid currency (cu): expected 'INR', got '${params.cu}'.`);
  }
  if (!alphanumericRefRegex.test(params.tr)) {
    errors.push(
      `Invalid transaction reference (tr): '${params.tr}' must be 6-35 alphanumeric characters without underscores or special symbols.`
    );
  }
  if (!safeTextRegex.test(params.tn)) {
    errors.push(
      `Invalid transaction note (tn): '${params.tn}' must be alphanumeric and spaces only (max 50 chars).`
    );
  }

  return {
    valid: errors.length === 0,
    errors,
    parameters: params,
  };
}

/**
 * Builds NPCI-compliant UPI payment URIs for 7250595155@ibl, ₹49.00, and the unique orderId.
 *
 * CRITICAL FIX FOR UPI ID / DEEP-LINK DECLINES:
 * 1. Both the QR code and all UPI buttons now use the exact same canonical `upi://pay` URI
 *    instead of proprietary schemes (`phonepe://pay`, `tez://upi/pay`, `paytmmp://pay`) which
 *    require a signed merchant (`sign=`) token and trigger "Your payment is declined for security reasons".
 * 2. Preserves the literal `@` in `pa=7250595155@ibl` (per NPCI spec) instead of `%40`.
 * 3. Uses a strictly alphanumeric `tr` and `tn` (no underscores `_`), preventing URI parser rejections.
 */
export function buildUpiPaymentLinks(orderId: string): UpiPaymentLinks {
  const pa = CONFIGURED_RECIPIENT_UPI_ID.trim();
  const pn = MERCHANT_DETAILS.merchantName.trim();
  const tr = sanitizeUpiTransactionRef(orderId);
  const tn = `Gita AI Rs49 ${tr}`.slice(0, 50);
  const am = `${SUBSCRIPTION_PRICE_INR}.00`;
  const cu = "INR";

  const validation = validateUpiPaymentParameters({
    pa,
    pn,
    am,
    cu,
    tr,
    tn,
  });

  // Keep literal '@' in `pa` as required by NPCI UPI Linking Spec v1.6; percent-encode spaces as %20 in `pn` and `tn`
  const [vpaUser, vpaHandle] = pa.split("@");
  const encodedPa = `${encodeURIComponent(vpaUser)}@${encodeURIComponent(
    vpaHandle || ""
  )}`;
  const encodedPn = encodeURIComponent(pn);
  const encodedTr = encodeURIComponent(tr);
  const encodedTn = encodeURIComponent(tn);

  const canonicalUpiUri = `upi://pay?pa=${encodedPa}&pn=${encodedPn}&am=${am}&cu=${cu}&tr=${encodedTr}&tn=${encodedTn}`;

  return {
    standardUpiUri: canonicalUpiUri,
    qrCodeUpiUri: canonicalUpiUri,
    phonePeUri: canonicalUpiUri,
    googlePayUri: canonicalUpiUri,
    paytmUri: canonicalUpiUri,
    bhimUri: canonicalUpiUri,
    validation,
  };
}

export interface GatewayConfigurationStatus {
  recipientUpiId: string;
  amountInr: number;
  anyLiveVerificationConfigured: boolean;
  providers: {
    phonepe_pg: boolean;
    razorpay_pg: boolean;
    bank_upi_aggregator: boolean;
  };
  missingCredentialsExplanation: string;
  requiredSetupSteps: string[];
}

export function getUpiVerificationConfiguration(): GatewayConfigurationStatus {
  const phonePeConfigured = Boolean(
    process.env.PHONEPE_MERCHANT_ID?.trim() &&
      process.env.PHONEPE_SALT_KEY?.trim()
  );

  const razorpayConfigured = Boolean(
    process.env.RAZORPAY_KEY_ID?.trim() &&
      process.env.RAZORPAY_KEY_SECRET?.trim()
  );

  const bankAggregatorConfigured = Boolean(
    process.env.UPI_PROVIDER_VERIFY_URL?.trim() &&
      process.env.UPI_PROVIDER_API_KEY?.trim()
  );

  const anyLiveVerificationConfigured =
    phonePeConfigured || razorpayConfigured || bankAggregatorConfigured;

  return {
    recipientUpiId: CONFIGURED_RECIPIENT_UPI_ID,
    amountInr: SUBSCRIPTION_PRICE_INR,
    anyLiveVerificationConfigured,
    providers: {
      phonepe_pg: phonePeConfigured,
      razorpay_pg: razorpayConfigured,
      bank_upi_aggregator: bankAggregatorConfigured,
    },
    missingCredentialsExplanation: `Your recipient UPI ID (${CONFIGURED_RECIPIENT_UPI_ID}) is configured for receiving ₹49 payments via PhonePe, Google Pay, Paytm, BHIM, or QR scan. However, automatic server-side payment verification is currently UNAVAILABLE because a standalone UPI ID (${CONFIGURED_RECIPIENT_UPI_ID}) does not expose a public NPCI/bank API to query incoming transfers or validate UTRs without authorized merchant gateway credentials. In accordance with security policy, Gita AI will NEVER unlock Premium based on a UPI redirect, screenshot, manually entered UTR, or simulated success.`,
    requiredSetupSteps: [
      `Option 1 (PhonePe Business / @ibl Native PG): Register ${CONFIGURED_RECIPIENT_UPI_ID} under a PhonePe Business Merchant account and set PHONEPE_MERCHANT_ID, PHONEPE_SALT_KEY, and PHONEPE_SALT_INDEX in .env, with webhook URL pointing to /api/webhooks/upi.`,
      `Option 2 (Authorized Bank / NPCI TPAP Aggregator — Setu, Cashfree, Decentro, or Yes Bank API): Link the bank account for ${CONFIGURED_RECIPIENT_UPI_ID} and set UPI_PROVIDER_VERIFY_URL, UPI_PROVIDER_API_KEY, UPI_PROVIDER_API_SECRET, and UPI_PROVIDER_WEBHOOK_SECRET in .env for server-side UTR & Order reconciliation.`,
      `Option 3 (Razorpay Merchant UPI & Route): Configure RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET, and RAZORPAY_WEBHOOK_SECRET in .env to verify captured ₹49 UPI payments and 12-digit RRN/UTR references via Razorpay's Payments API.`,
    ],
  };
}

export interface IndependentVerificationResult {
  verified: boolean;
  status: "verified" | "pending" | "failed" | "verification_unavailable";
  providerUsed: string;
  verifiedTransactionId?: string | null;
  verifiedAmountInr?: number;
  verifiedRecipientVpa?: string;
  verifiedOrderId?: string;
  reason: string;
}

/**
 * Independently verifies a ₹49 UPI payment with the configured payment provider or bank API.
 * Checks:
 *  1. Transaction status === SUCCESS / COMPLETED / CAPTURED
 *  2. Amount === ₹49 (4900 paise)
 *  3. Recipient VPA === 7250595155@ibl (or linked merchant account)
 *  4. Order association === orderId (and UTR match if submittedUtr is provided)
 *
 * NEVER fakes or simulates verification if credentials are missing.
 */
export async function verifyUpiPaymentWithProvider(params: {
  orderId: string;
  expectedAmountInr: number;
  expectedRecipientVpa: string;
  submittedUtr?: string | null;
}): Promise<IndependentVerificationResult> {
  const {
    orderId,
    expectedAmountInr,
    expectedRecipientVpa,
    submittedUtr,
  } = params;

  const config = getUpiVerificationConfiguration();

  if (!config.anyLiveVerificationConfigured) {
    return {
      verified: false,
      status: "verification_unavailable",
      providerUsed: "none_configured",
      reason: config.missingCredentialsExplanation,
    };
  }

  // 1. PhonePe PG Server-to-Server Status & UTR Lookup
  if (config.providers.phonepe_pg) {
    const merchantId = process.env.PHONEPE_MERCHANT_ID!.trim();
    const saltKey = process.env.PHONEPE_SALT_KEY!.trim();
    const saltIndex = process.env.PHONEPE_SALT_INDEX?.trim() || "1";
    const apiBase =
      process.env.PHONEPE_API_BASE_URL?.trim() ||
      "https://api.phonepe.com/apis/hermes";

    const path = `/pg/v1/status/${merchantId}/${orderId}`;
    const sha256Dig = crypto
      .createHash("sha256")
      .update(path + saltKey)
      .digest("hex");
    const xVerify = `${sha256Dig}###${saltIndex}`;

    try {
      const response = await fetch(`${apiBase}${path}`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
          "X-VERIFY": xVerify,
          "X-MERCHANT-ID": merchantId,
        },
      });

      const data = await response.json();
      const state = data?.data?.state;
      const amountPaise = Number(data?.data?.amount || 0);
      const returnedOrderId = data?.data?.merchantTransactionId;
      const utr =
        data?.data?.paymentInstrument?.utr || data?.data?.transactionId;

      if (
        response.ok &&
        data?.code === "PAYMENT_SUCCESS" &&
        state === "COMPLETED"
      ) {
        if (returnedOrderId !== orderId) {
          return {
            verified: false,
            status: "failed",
            providerUsed: "phonepe_pg",
            reason: `Order ID mismatch from PhonePe API (expected ${orderId}, got ${returnedOrderId}).`,
          };
        }

        if (amountPaise !== expectedAmountInr * 100) {
          return {
            verified: false,
            status: "failed",
            providerUsed: "phonepe_pg",
            reason: `Payment amount mismatch (expected ₹${expectedAmountInr}, received ₹${
              amountPaise / 100
            }).`,
          };
        }

        if (
          submittedUtr &&
          (!utr || submittedUtr.trim() !== String(utr).trim())
        ) {
          return {
            verified: false,
            status: "failed",
            providerUsed: "phonepe_pg",
            reason: `Submitted UTR (${submittedUtr}) could not be confirmed against PhonePe's recorded UTR (${
              utr || "none"
            }) for order ${orderId}.`,
          };
        }

        return {
          verified: true,
          status: "verified",
          providerUsed: "phonepe_pg",
          verifiedTransactionId: String(utr || orderId),
          verifiedAmountInr: expectedAmountInr,
          verifiedRecipientVpa: expectedRecipientVpa,
          verifiedOrderId: orderId,
          reason: `Verified via PhonePe PG API (UTR: ${utr}).`,
        };
      }

      if (state === "FAILED" || data?.code === "PAYMENT_ERROR") {
        return {
          verified: false,
          status: "failed",
          providerUsed: "phonepe_pg",
          reason:
            data?.message ||
            "PhonePe PG reported that the payment failed or was declined.",
        };
      }

      return {
        verified: false,
        status: "pending",
        providerUsed: "phonepe_pg",
        reason:
          "PhonePe PG status check: Payment is still pending confirmation.",
      };
    } catch (err) {
      return {
        verified: false,
        status: "pending",
        providerUsed: "phonepe_pg",
        reason: `PhonePe verification API unreachable: ${
          err instanceof Error ? err.message : "Network error"
        }`,
      };
    }
  }

  // 2. Authorized Bank / NPCI Aggregator API Verification (UTR + Order + Recipient VPA + Amount)
  if (config.providers.bank_upi_aggregator) {
    const verifyUrl = process.env.UPI_PROVIDER_VERIFY_URL!.trim();
    const apiKey = process.env.UPI_PROVIDER_API_KEY!.trim();
    const apiSecret = process.env.UPI_PROVIDER_API_SECRET?.trim() || "";

    try {
      const response = await fetch(verifyUrl, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "X-API-KEY": apiKey,
          ...(apiSecret ? { "X-API-SECRET": apiSecret } : {}),
        },
        body: JSON.stringify({
          orderId,
          utr: submittedUtr || undefined,
          expectedRecipientVpa,
          expectedAmountInr,
        }),
      });

      const data = await response.json();
      const txStatus = String(data?.status || "").toUpperCase();
      const txAmount = Number(data?.amountInr ?? data?.amount ?? 0);
      const txRecipient = String(
        data?.recipientVpa || data?.payeeVpa || ""
      ).toLowerCase();
      const txOrderId = String(data?.orderId || data?.tr || "");
      const txUtr = String(data?.utr || data?.rrn || "");

      if (
        response.ok &&
        (txStatus === "SUCCESS" ||
          txStatus === "COMPLETED" ||
          txStatus === "CAPTURED")
      ) {
        if (txRecipient !== expectedRecipientVpa.toLowerCase()) {
          return {
            verified: false,
            status: "failed",
            providerUsed: "bank_upi_aggregator",
            reason: `Recipient UPI ID mismatch: payment was sent to '${txRecipient}' instead of '${expectedRecipientVpa}'.`,
          };
        }

        if (txAmount !== expectedAmountInr) {
          return {
            verified: false,
            status: "failed",
            providerUsed: "bank_upi_aggregator",
            reason: `Amount mismatch: expected ₹${expectedAmountInr}, but provider reported ₹${txAmount}.`,
          };
        }

        if (txOrderId !== orderId) {
          return {
            verified: false,
            status: "failed",
            providerUsed: "bank_upi_aggregator",
            reason: `Order association mismatch: transaction belongs to order '${txOrderId}', not '${orderId}'.`,
          };
        }

        if (
          submittedUtr &&
          (!txUtr || submittedUtr.trim() !== txUtr.trim())
        ) {
          return {
            verified: false,
            status: "failed",
            providerUsed: "bank_upi_aggregator",
            reason: `UTR mismatch: submitted UTR '${submittedUtr}' could not be confirmed against bank UTR '${
              txUtr || "none"
            }'.`,
          };
        }

        return {
          verified: true,
          status: "verified",
          providerUsed: "bank_upi_aggregator",
          verifiedTransactionId: txUtr || orderId,
          verifiedAmountInr: txAmount,
          verifiedRecipientVpa: txRecipient,
          verifiedOrderId: txOrderId,
          reason: `Payment independently verified by Bank/UPI Provider API for ${expectedRecipientVpa} (UTR: ${txUtr}).`,
        };
      }

      if (txStatus === "FAILED" || txStatus === "DECLINED") {
        return {
          verified: false,
          status: "failed",
          providerUsed: "bank_upi_aggregator",
          reason:
            data?.message ||
            "Bank/UPI provider reported that the transaction failed.",
        };
      }

      return {
        verified: false,
        status: "pending",
        providerUsed: "bank_upi_aggregator",
        reason:
          data?.message ||
          "Bank/UPI provider has not yet confirmed a ₹49 credit for this order.",
      };
    } catch (err) {
      return {
        verified: false,
        status: "pending",
        providerUsed: "bank_upi_aggregator",
        reason: `Bank/UPI verification endpoint error: ${
          err instanceof Error ? err.message : "Network error"
        }`,
      };
    }
  }

  // 3. Razorpay Payments API Verification
  if (config.providers.razorpay_pg) {
    const keyId = process.env.RAZORPAY_KEY_ID!.trim();
    const keySecret = process.env.RAZORPAY_KEY_SECRET!.trim();
    const basicAuth = Buffer.from(`${keyId}:${keySecret}`).toString("base64");

    try {
      const response = await fetch(
        `https://api.razorpay.com/v1/payments?count=20`,
        {
          method: "GET",
          headers: {
            Authorization: `Basic ${basicAuth}`,
          },
        }
      );

      if (!response.ok) {
        return {
          verified: false,
          status: "pending",
          providerUsed: "razorpay_pg",
          reason:
            "Razorpay API returned an authentication or lookup error. Check RAZORPAY_KEY_ID / RAZORPAY_KEY_SECRET.",
        };
      }

      const data = await response.json();
      const items: Array<Record<string, unknown>> = Array.isArray(data?.items)
        ? data.items
        : [];

      const matchingPayment = items.find((item) => {
        const notes = (item.notes as Record<string, string> | undefined) || {};
        const desc = String(item.description || "");
        const acquirerData =
          (item.acquirer_data as Record<string, string> | undefined) || {};
        const rrn = String(acquirerData.rrn || "");

        const matchesOrder =
          notes.orderId === orderId || desc.includes(orderId);
        const matchesUtr = submittedUtr ? rrn === submittedUtr.trim() : true;
        return matchesOrder && matchesUtr;
      });

      if (!matchingPayment) {
        return {
          verified: false,
          status: "pending",
          providerUsed: "razorpay_pg",
          reason: `No captured ₹${expectedAmountInr} payment found in Razorpay for Order ${orderId}${
            submittedUtr ? ` / UTR ${submittedUtr}` : ""
          }.`,
        };
      }

      const pStatus = String(matchingPayment.status || "");
      const pAmount = Number(matchingPayment.amount || 0);
      const acquirerData =
        (matchingPayment.acquirer_data as Record<string, string> | undefined) ||
        {};
      const rrn = String(acquirerData.rrn || matchingPayment.id || "");

      if (pStatus === "captured" && pAmount === expectedAmountInr * 100) {
        return {
          verified: true,
          status: "verified",
          providerUsed: "razorpay_pg",
          verifiedTransactionId: rrn,
          verifiedAmountInr: expectedAmountInr,
          verifiedRecipientVpa: expectedRecipientVpa,
          verifiedOrderId: orderId,
          reason: `Verified via Razorpay Payments API (UTR/RRN: ${rrn}).`,
        };
      }

      if (pStatus === "failed") {
        return {
          verified: false,
          status: "failed",
          providerUsed: "razorpay_pg",
          reason: "Razorpay reported that the payment failed.",
        };
      }

      return {
        verified: false,
        status: "pending",
        providerUsed: "razorpay_pg",
        reason: `Payment found in Razorpay with status '${pStatus}', awaiting capture.`,
      };
    } catch (err) {
      return {
        verified: false,
        status: "pending",
        providerUsed: "razorpay_pg",
        reason: `Razorpay API request error: ${
          err instanceof Error ? err.message : "Network error"
        }`,
      };
    }
  }

  return {
    verified: false,
    status: "verification_unavailable",
    providerUsed: "none",
    reason: config.missingCredentialsExplanation,
  };
}
