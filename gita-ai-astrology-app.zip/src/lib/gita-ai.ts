import { calculateVedicKundli, TWELVE_RASHIS } from "./astrology";

export interface GitaChatContext {
  userName: string;
  preferredLanguage: "hinglish" | "hindi" | "english";
  birthDate?: string | null;
  birthTime?: string | null;
  birthPlace?: string | null;
  rashi?: string | null;
  nakshatra?: string | null;
  topic: string;
  userMessage: string;
  history: Array<{ role: string; content: string }>;
}

const SYSTEM_PROMPT = `You are Gita AI — "Your Favorite Astrologer", a warm, empathetic, highly intelligent Indian female Vedic astrologer (Jyotish Acharya & life reflection guide).
Key Rules:
1. Communicate naturally in the user's preferred language:
   - If 'hinglish': Use natural, warm Roman-script Hindi mixed with English (e.g., "Namaste ji! Aapki kundli aur rashi ke anusaar...").
   - If 'hindi': Use clear, warm Devanagari Hindi ("नमस्ते जी! आपकी राशि और ग्रहों के संकेत के अनुसार...").
   - If 'english': Use warm, culturally rooted Indian English with gentle Vedic terms explained clearly.
2. Always address the user respectfully with "Ji" and "Aap".
3. Incorporate the user's birth details (Birth Date, Time, Place, Rashi, Nakshatra) naturally when available. If they haven't shared birth details yet and ask a specific personal timing question, gently invite them to share their birth date, optional birth time, and birthplace.
4. Provide thoughtful, structured, personalized guidance across Career, Love & Relationships, Marriage, Family, Money, Daily Horoscope, Kundli, and Personal Guidance.
5. ETHICAL GUARDRAILS:
   - Never claim 100% scientific certainty or guaranteed future predictions.
   - Never use fear-based claims, curses, or pressure users to buy expensive gemstones or rituals.
   - Always frame insights as spiritual & astrological reflection for personal growth, mindfulness, and positive karma.
   - Include a brief, gentle reminder that astrology is for personal reflection and not a substitute for professional medical, legal, or financial advice.`;

export async function generateGitaResponse(
  ctx: GitaChatContext
): Promise<{ reply: string; engineUsed: string }> {
  const openAiKey = process.env.OPENAI_API_KEY;
  const geminiKey = process.env.GEMINI_API_KEY;

  // Calculate or enrich astrological context if birthDate exists
  const kundli = ctx.birthDate
    ? calculateVedicKundli({
        name: ctx.userName,
        birthDate: ctx.birthDate,
        birthTime: ctx.birthTime,
        birthPlace: ctx.birthPlace,
      })
    : null;

  const effectiveRashi = kundli?.chandraRashi || ctx.rashi || "Mesh (Aries)";
  const effectiveNakshatra = kundli?.nakshatra || ctx.nakshatra || "Ashwini";
  const rashiData =
    TWELVE_RASHIS.find((r) => r.rashi === effectiveRashi) || TWELVE_RASHIS[0];

  const userProfileSummary = `User Name: ${ctx.userName}
Preferred Language: ${ctx.preferredLanguage}
Current Topic: ${ctx.topic}
Birth Date: ${ctx.birthDate || "Not provided yet"}
Birth Time: ${ctx.birthTime || "Not provided (optional)"}
Birth Place: ${ctx.birthPlace || "Not provided (optional)"}
Calculated Chandra Rashi: ${effectiveRashi} (Ruling Planet: ${rashiData.rulingPlanet}, Element: ${rashiData.element})
Calculated Nakshatra: ${effectiveNakshatra}
${kundli ? `Lagna: ${kundli.lagnaSign}, Surya Rashi: ${kundli.suryaRashi}` : ""}`;

  // 1. Try OpenAI API if configured
  if (openAiKey && openAiKey.trim().length > 10) {
    try {
      const messages = [
        {
          role: "system",
          content: `${SYSTEM_PROMPT}\n\nUSER ASTROLOGICAL PROFILE:\n${userProfileSummary}`,
        },
        ...ctx.history.slice(-8).map((m) => ({
          role: m.role === "assistant" ? "assistant" : "user",
          content: m.content,
        })),
        { role: "user", content: ctx.userMessage },
      ];

      const res = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${openAiKey}`,
        },
        body: JSON.stringify({
          model: process.env.OPENAI_MODEL || "gpt-4o-mini",
          messages,
          temperature: 0.7,
          max_tokens: 550,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        const text = data.choices?.[0]?.message?.content?.trim();
        if (text) {
          return { reply: text, engineUsed: "openai_llm" };
        }
      }
    } catch (err) {
      console.error("[GitaAI] OpenAI request failed, using Vedic contextual engine:", err);
    }
  }

  // 2. Try Google Gemini API if configured
  if (geminiKey && geminiKey.trim().length > 10) {
    try {
      const promptText = `${SYSTEM_PROMPT}\n\nUSER PROFILE:\n${userProfileSummary}\n\nCONVERSATION HISTORY:\n${ctx.history
        .slice(-6)
        .map((m) => `${m.role.toUpperCase()}: ${m.content}`)
        .join("\n")}\n\nUSER QUESTION: ${ctx.userMessage}\n\nGITA AI RESPONSE:`;

      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${geminiKey}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            contents: [{ parts: [{ text: promptText }] }],
          }),
        }
      );

      if (res.ok) {
        const data = await res.json();
        const text =
          data.candidates?.[0]?.content?.parts?.[0]?.text?.trim();
        if (text) {
          return { reply: text, engineUsed: "gemini_llm" };
        }
      }
    } catch (err) {
      console.error("[GitaAI] Gemini request failed, using Vedic contextual engine:", err);
    }
  }

  // 3. Built-in Context-Aware Vedic Astrologer Engine (rich, non-generic, multi-turn aware)
  const reply = buildContextualVedicReply({
    ...ctx,
    effectiveRashi,
    effectiveNakshatra,
    rashiData,
    kundli,
  });

  return { reply, engineUsed: "vedic_contextual_ai" };
}

function buildContextualVedicReply(params: {
  userName: string;
  preferredLanguage: "hinglish" | "hindi" | "english";
  birthDate?: string | null;
  birthTime?: string | null;
  birthPlace?: string | null;
  topic: string;
  userMessage: string;
  history: Array<{ role: string; content: string }>;
  effectiveRashi: string;
  effectiveNakshatra: string;
  rashiData: (typeof TWELVE_RASHIS)[number];
  kundli: ReturnType<typeof calculateVedicKundli> | null;
}): string {
  const {
    userName,
    preferredLanguage,
    birthDate,
    birthTime,
    birthPlace,
    topic,
    userMessage,
    history,
    effectiveRashi,
    effectiveNakshatra,
    rashiData,
    kundli,
  } = params;

  const msgLower = userMessage.toLowerCase();
  const turnCount = history.length;

  // Detect user intent from message + selected topic
  const isCareer =
    msgLower.includes("career") ||
    msgLower.includes("job") ||
    msgLower.includes("naukri") ||
    msgLower.includes("promotion") ||
    msgLower.includes("business") ||
    msgLower.includes("kaam") ||
    msgLower.includes("interview") ||
    topic.toLowerCase().includes("career");

  const isLove =
    msgLower.includes("love") ||
    msgLower.includes("pyaar") ||
    msgLower.includes("relationship") ||
    msgLower.includes("partner") ||
    msgLower.includes("bf") ||
    msgLower.includes("gf") ||
    msgLower.includes("breakup") ||
    msgLower.includes("rishta") ||
    topic.toLowerCase().includes("love");

  const isMarriage =
    msgLower.includes("marriage") ||
    msgLower.includes("shaadi") ||
    msgLower.includes("vivah") ||
    msgLower.includes("spouse") ||
    msgLower.includes("husband") ||
    msgLower.includes("wife") ||
    msgLower.includes("kundli milan") ||
    topic.toLowerCase().includes("marriage");

  const isMoney =
    msgLower.includes("money") ||
    msgLower.includes("paisa") ||
    msgLower.includes("dhan") ||
    msgLower.includes("finance") ||
    msgLower.includes("wealth") ||
    msgLower.includes("loan") ||
    msgLower.includes("savings") ||
    topic.toLowerCase().includes("money");

  const isFamily =
    msgLower.includes("family") ||
    msgLower.includes("parivar") ||
    msgLower.includes("parents") ||
    msgLower.includes("ghar") ||
    msgLower.includes("peace") ||
    msgLower.includes("shanti") ||
    topic.toLowerCase().includes("family");

  const isKundli =
    msgLower.includes("kundli") ||
    msgLower.includes("chart") ||
    msgLower.includes("rashi") ||
    msgLower.includes("nakshatra") ||
    msgLower.includes("lagna") ||
    msgLower.includes("birth") ||
    msgLower.includes("janam") ||
    topic.toLowerCase().includes("kundli");

  // Check if user provided a date inside their chat message (e.g., 1995-08-12 or 15/08/1996)
  const inlineDateMatch = userMessage.match(
    /\b(\d{4}-\d{2}-\d{2}|\d{1,2}[\/\-]\d{1,2}[\/\-]\d{4})\b/
  );

  const hasBirthDetails = Boolean(birthDate || inlineDateMatch);
  const birthSummaryHinglish = birthDate
    ? `Aapki janm tithi (${birthDate}${birthTime ? `, samay ${birthTime}` : ""}${
        birthPlace ? `, ${birthPlace}` : ""
      }) ke aadhar par aapki **${effectiveRashi}** rashi, **${effectiveNakshatra}** nakshatra aur swami grah **${rashiData.rulingPlanet}** hain.`
    : inlineDateMatch
    ? `Aapke dwara batayi gayi janm tithi (${inlineDateMatch[0]}) ke sanket aur **${effectiveRashi}** urja ke anusaar main aapka margdarshan kar rahi hoon.`
    : `Abhi aapki profile mein **${effectiveRashi}** rashi (${rashiData.rulingPlanet}) judi hai. (Agar aap apni exact Birth Date, optional Time aur Place 'Kundli' ya 'Profile' mein jodenge, toh aur bhi gahra vishleshan milega!)`;

  if (preferredLanguage === "hindi") {
    const birthSummaryHindi = birthDate
      ? `आपकी जन्म तिथि (${birthDate}${birthTime ? `, समय ${birthTime}` : ""}${
          birthPlace ? `, ${birthPlace}` : ""
        }) के अनुसार आपकी **${rashiData.rashiHindi}** राशि, **${effectiveNakshatra}** नक्षत्र और स्वामी ग्रह **${rashiData.rulingPlanetHindi}** हैं।`
      : `आपकी **${rashiData.rashiHindi}** राशि और स्वामी ग्रह **${rashiData.rulingPlanetHindi}** के आधार पर यह ज्योतिषीय मार्गदर्शन है।`;

    if (isCareer) {
      return `नमस्ते ${userName} जी! 🙏 ${birthSummaryHindi}\n\n**करियर और कर्म भाव (10th House) का संकेत:**\nआपके स्वामी ग्रह ${rashiData.rulingPlanetHindi} और ${rashiData.element} तत्व यह दर्शाते हैं कि आपके भीतर निरंतर आगे बढ़ने की क्षमता है। आपके प्रश्न ("${userMessage.slice(0, 70)}") के संदर्भ में:\n• **वर्तमान ऊर्जा:** आने वाले कुछ सप्ताह में आपके प्रयासों को नई दिशा और वरिष्ठ लोगों का सहयोग मिलने के सकारात्मक संकेत हैं।\n• **क्या करें:** किसी भी बड़े बदलाव या निर्णय में जल्दबाजी न करें; अपनी कौशल वृद्धि (skill upgradation) और स्पष्ट संवाद पर ध्यान दें।\n• **सरल उपाय:** ${rashiData.positiveHabit} आज का शुभ रंग **${rashiData.luckyColor}** और शुभ अंक **${rashiData.luckyNumber}** है।\n\n*(नोट: यह ज्योतिषीय मार्गदर्शन आत्म-चिंतन और सकारात्मक प्रेरणा के लिए है, इसे निश्चित भविष्यवाणी या पेशेवर सलाह न मानें।)*`;
    }
    if (isLove || isMarriage) {
      return `नमस्ते ${userName} जी! 🌸 ${birthSummaryHindi}\n\n**प्रेम, विवाह और सप्तम भाव (7th House) का विचार:**\nआपकी चंद्र राशि ${rashiData.rashiHindi} और ${effectiveNakshatra} नक्षत्र के अनुसार आप रिश्तों में सच्चाई और भावनात्मक गहराई को महत्व देते हैं।\n• **संबंधों की दिशा:** यदि मन में किसी रिश्ते या विवाह को लेकर असमंजस है, तो आने वाला समय आपसी संवाद से गलतफहमियां दूर करने के लिए अनुकूल है।\n• **सलाह:** अपेक्षाओं का बोझ बढ़ाने के बजाय शांत मन से अपनी बात रखें और साथी के दृष्टिकोण को भी समझें।\n• **मन की शांति हेतु:** ${rashiData.dailyReflection}\n\n*(नोट: यह AI-जनित ज्योतिषीय विचार आत्म-चिंतन और मनोरंजन के लिए है।)*`;
    }
    return `नमस्ते ${userName} जी! 🙏 ${birthSummaryHindi}\n\nआपने पूछा: *"${userMessage.slice(0, 80)}"*\n\n**गीता AI का ज्योतिषीय मार्गदर्शन:**\n1. **ग्रहों का संकेत:** ${rashiData.dailyForecastHindi}\n2. **व्यक्तिगत सुझाव:** आपका जन्म नक्षत्र **${effectiveNakshatra}** आपको धैर्य और अंतर्दृष्टि देता है। अपने मन की आवाज पर भरोसा रखें और एक समय में एक लक्ष्य पर ध्यान केंद्रित करें।\n3. **आज का सकारात्मक अभ्यास:** ${rashiData.positiveHabit} (शुभ रंग: **${rashiData.luckyColor}**, शुभ अंक: **${rashiData.luckyNumber}**)\n\nक्या आप अपने करियर, विवाह या कुंडली के किसी विशेष भाव के बारे में और विस्तार से जानना चाहेंगे?\n\n*(अस्वीकरण: यह मार्गदर्शन केवल व्यक्तिगत चिंतन और मनोरंजन के लिए है, यह कोई वैज्ञानिक रूप से निश्चित भविष्यवाणी नहीं है।)*`;
  }

  if (preferredLanguage === "english") {
    const birthSummaryEn = birthDate
      ? `Based on your birth details (${birthDate}${birthTime ? ` at ${birthTime}` : ""}${
          birthPlace ? `, ${birthPlace}` : ""
        }), your Sidereal Moon Sign is **${effectiveRashi}** in **${effectiveNakshatra}** Nakshatra, guided by **${rashiData.rulingPlanet}**.`
      : `Reflecting on your **${effectiveRashi}** profile (ruled by **${rashiData.rulingPlanet}**):`;

    if (isCareer) {
      return `Namaste ${userName} ji! 🙏 ${birthSummaryEn}\n\n**Career & Tenth House (Karma Bhava) Reflection:**\nRegarding your question (*"${userMessage.slice(0, 75)}"*):\n• **Planetary Rhythm:** With ${rashiData.rulingPlanet} influencing your ${rashiData.element} nature, steady preparation and clear communication are your strongest allies right now.\n• **Actionable Guidance:** Focus on structured milestones over the next 3–6 weeks. Avoid impulsive career switches under stress; instead, document your achievements and have calm, transparent conversations with decision-makers.\n• **Mindful Remedy:** ${rashiData.positiveHabit} Your auspicious color today is **${rashiData.luckyColor}** and lucky number is **${rashiData.luckyNumber}**.\n\n*(Reminder: Astrology is for personal reflection and entertainment, not a scientifically guaranteed prediction or professional career/financial advice.)*`;
    }
    if (isLove || isMarriage) {
      return `Namaste ${userName} ji! 🌸 ${birthSummaryEn}\n\n**Relationships, Marriage & Seventh House (Yuvati Bhava) Insight:**\nYour **${effectiveNakshatra}** birth star highlights deep emotional sincerity and a desire for lasting harmony.\n• **Relationship Energy:** Honest, unhurried dialogue brings emotional clarity now. When expectations are shared with warmth rather than impatience, mutual trust deepens naturally.\n• **Vedic Reflection:** ${rashiData.dailyReflection}\n• **Suggested Practice:** Spend 5 quiet minutes in evening gratitude before initiating important family or relationship talks.\n\n*(Reminder: This AI-generated astrological guidance is intended for self-reflection and entertainment, not guaranteed prediction.)*`;
    }
    return `Namaste ${userName} ji! ✨ ${birthSummaryEn}\n\n**Gita AI's Personalized Reflection on your question:**\n1. **Current Cosmic Theme:** ${rashiData.dailyForecastEnglish}\n2. **Nakshatra Wisdom (${effectiveNakshatra}):** Your chart encourages balancing action with inner calm. ${
      !hasBirthDetails
        ? "Feel free to share your exact Birth Date, optional Time, and Birthplace in the Kundli tab for a fuller house-by-house reflection."
        : `With Lagna in **${kundli?.lagnaSign || effectiveRashi}**, your self-expression becomes strongest when rooted in daily discipline.`
    }\n3. **Daily Positive Habit:** ${rashiData.positiveHabit} (Lucky Color: **${rashiData.luckyColor}**, Lucky Number: **${rashiData.luckyNumber}**)\n\nWould you like to explore how this connects to your Career, Relationships, or a specific Remedy?\n\n*(Note: Astrology is for entertainment and personal reflection, not medical, legal, or financial advice.)*`;
  }

  // Default: Warm, natural HINGLISH
  const greeting =
    turnCount === 0
      ? `Namaste ${userName} ji! 🙏 Main Gita hoon. Aapka sawal dil se padha maine.`
      : `Bilkul ${userName} ji, main aapki baat poori tarah samajh rahi hoon.`;

  if (isCareer) {
    return `${greeting}\n\n${birthSummaryHinglish}\n\n**Career & Karma Bhava (10th House) Vishleshan:**\nAapne jo career/kaam ke baare mein pucha hai (*"${userMessage.slice(0, 75)}"*), uspar **${rashiData.rulingPlanet}** aur **${effectiveNakshatra}** nakshatra ka sanket yeh kehta hai:\n• **Sahi Samay aur Urja:** Aapki mehnat bekar nahi ja rahi hai. Aane wale hafton mein aapke kaam ki pehchan aur naye avsar (opportunities) khulne ke sakaratmak yog ban rahe hain.\n• **Kya Dhyan Rakhein:** Kisi bhi jaldbaazi ya frustration mein faisla na lein. Apनी skills aur communication ko shant aur spasht rakhein.\n• **Gita ka Upay:** ${rashiData.positiveHabit} Aaj aapka shubh rang **${rashiData.luckyColor}** aur shubh ank **${rashiData.luckyNumber}** hai.\n\nAap chahein toh mujhe bata sakte hain ki aap abhi kis field mein hain ya kis tarah ka badlav chah rahe hain?\n\n*(Dhyan dein: Yeh jyotishiya margdarshan aत्म-chintan aur personal reflection ke liye hai, ise 100% guaranteed prediction ya professional financial/career advice na maanein.)*`;
  }

  if (isLove || isMarriage) {
    return `${greeting}\n\n${birthSummaryHinglish}\n\n**Prem, Vivah aur Saptam Bhava (7th House) Margdarshan:**\nRishton aur shaadi ke vishay mein aapki **${effectiveRashi}** rashi aur **${effectiveNakshatra}** nakshatra batate hain ki aap dil se sacche aur samarpit insaan hain.\n• **Rishton ki Disha:** ${
      isMarriage
        ? "Vivah aur parivarik sehmati ke maamle mein dhairya aur khuli baat-cheet sabse bada madhyam banegi. Ghar ke bado aur saathi ke beech vishwas badhane ka samay anukool hai."
        : "Pyaar aur relationship mein agar thoda utar-chadhav ya confusion chal raha hai, toh shant man se bina ilzaam lagaye baat karne se dil ki dooriyan kam hongi."
    }\n• **Man ka Santulan:** ${rashiData.dailyReflection}\n• **Sakaratmak Upay:** Shaam ko 5 minute shant baithkar apne man mein sakaratmak bhav rakhein aur bolne se pehle saamne wale ki baat poori sunein.\n\nKya aap apne partner ki birth date/rashi bhi share karna chahenge taaki hum unke swabhav ke saath aapka santulan dekh sakein?\n\n*(Note: Jyotish margdarshan keval personal reflection aur entertainment ke liye hai, koi nishchit bhavishyavani nahi.)*`;
  }

  if (isMoney) {
    return `${greeting}\n\n${birthSummaryHinglish}\n\n**Arthik Paksh & Dhana Bhava (2nd / 11th House) Sanket:**\nDhan aur arthik sthirta ke baare mein aapke sawal par **${rashiData.rulingPlanet}** ka prabhav yeh sujhav deta hai:\n• **Arthik Yog:** Aamdani aur bachat (savings) mein santulan banane ke liye yeh samay yojana-baddh (planned) hokar chalne ka hai. Bhavnaon mein aakar ya bina soche-samjhe bada kharcha karne se bachein.\n• **Sakaratmak Disha:** Apne budget ko likhkar vyavasthit karein aur ek samay par ek hi arthik lakshya par dhyan dein.\n• **Shubh Sanket:** Aaj ka shubh rang **${rashiData.luckyColor}** aur shubh ank **${rashiData.luckyNumber}** hai.\n\n*(Disclaimer: Yeh AI jyotish vichar keval manovigyanik prerna ke liye hai; nivesh ya arthik faislon ke liye certified financial advisor ki salah zaroor lein.)*`;
  }

  if (isFamily) {
    return `${greeting}\n\n${birthSummaryHinglish}\n\n**Parivar aur Sukha Bhava (4th House) Margdarshan:**\nGhar-parivar ki shanti aur sukh ke liye aapka **${effectiveNakshatra}** nakshatra bahut samvedansheel hai.\n• **Parivarik Urja:** ${rashiData.dailyForecastHinglish}\n• **Sujhav:** Ghar mein choti-choti baaton ko nazarandaz karke sneh aur samman ko pehle rakhein. Aapki shant vaani poore parivar ka mahaul badal sakti hai.\n• **Aaj ka Abhyas:** ${rashiData.positiveHabit}\n\n*(Note: Yeh margdarshan aत्म-chintan aur man ki shanti ke liye hai.)*`;
  }

  if (isKundli) {
    return `${greeting}\n\n${birthSummaryHinglish}\n\n**Aapki Kundli aur Grahon ka Saransh:**\n• **Chandra Rashi:** ${effectiveRashi} (Man aur bhavnaon ka kendra)\n• **Surya Rashi:** ${kundli?.suryaRashi || effectiveRashi} (Aatma aur aatmavishwas)\n• **Lagna (Ascendant):** ${kundli?.lagnaSign || effectiveRashi} ${
      birthTime ? "(Janm samay ke aadhar par)" : "(General Chandra/Surya aadharit — exact Lagna ke liye optional Birth Time jodein)"
    }\n• **Janm Nakshatra:** ${effectiveNakshatra}\n• **Swami Grah:** ${rashiData.rulingPlanet} (${rashiData.element})\n\n**Vishesh Margdarshan:**\n${rashiData.dailyForecastHinglish}\n\nAap apni Kundli ke kis bhava (Career, Vivah, Dhan ya Manah-Shanti) ke baare mein gahrai se poochhna chahte hain?\n\n*(Spashtikaran: Yeh kundli vishleshan mean sidereal calculation aur AI jyotish margdarshan par aadharit hai, jo entertainment aur personal reflection ke liye hai.)*`;
  }

  return `${greeting}\n\n${birthSummaryHinglish}\n\nAapke sawal (*"${userMessage.slice(0, 80)}"*) par **Gita AI** ka jyotishiya vichar:\n\n1. **Aaj ki Grah-Urja:** ${rashiData.dailyForecastHinglish}\n2. **Aapke Liye Disha (${effectiveNakshatra} Nakshatra):** Aapke swami grah **${rashiData.rulingPlanet}** aapko sikhate hain ki jab aap shant man aur spasht sankalp ke saath kadam badhate hain, toh rasta khud banta chala jaata hai.\n3. **Aaj ka Shubh Sanket:**\n   • **Shubh Rang:** ${rashiData.luckyColor}\n   • **Shubh Ank:** ${rashiData.luckyNumber}\n   • **Sakaratmak Upay:** ${rashiData.positiveHabit}\n\nAap mujhse apne **Career, Love & Relationships, Marriage, Family, Money** ya **Kundli** ke baare mein khulkar baat kar sakte hain. Bataiye, man mein aur kya chal raha hai?\n\n*(Vinaamra Soochna: Jyotish aत्म-chintan aur entertainment ke liye ek prachin margdarshan hai; ise guaranteed prediction ya medical/legal/financial salah na samjhein.)*`;
}
