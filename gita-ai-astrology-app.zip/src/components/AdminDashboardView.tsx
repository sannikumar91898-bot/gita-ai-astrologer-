"use client";

import React, { useState, useEffect, useCallback } from "react";
import {
  ShieldCheck,
  Users,
  IndianRupee,
  FileText,
  Sparkles,
  Settings,
  RefreshCw,
  Lock,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowLeft,
  Save,
} from "lucide-react";

interface AdminDashboardProps {
  token: string | null;
  currentUserRole?: string;
  onSwitchToAdminAccount?: () => Promise<void>;
  onBackToApp?: () => void;
}

export function AdminDashboardView({
  token,
  currentUserRole,
  onSwitchToAdminAccount,
  onBackToApp,
}: AdminDashboardProps) {
  const [loading, setLoading] = useState(true);
  const [accessDenied, setAccessDenied] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<
    "overview" | "users" | "payments" | "content" | "config" | "audit"
  >("overview");

  const [stats, setStats] = useState<{
    totalUsers: number;
    activeSubscribers: number;
    trialUsers: number;
    expiredOrCancelledUsers: number;
    totalPaymentsCount: number;
    verifiedPaymentsCount: number;
    pendingPaymentsCount: number;
    failedPaymentsCount: number;
    refundedPaymentsCount: number;
    totalVerifiedRevenueInr: number;
    totalChatInteractionsCount: number;
    totalKundliChartsCount: number;
  } | null>(null);

  const [usersList, setUsersList] = useState<
    Array<{
      id: number;
      name: string;
      maskedEmail: string;
      role: string;
      preferredLanguage: string;
      rashi: string;
      trialUsed: boolean;
      subscriptionStatus: string;
      subscriptionPlan: string;
      subscriptionExpiresAt: string | null;
      createdAt: string;
    }>
  >([]);

  const [paymentsList, setPaymentsList] = useState<
    Array<{
      id: number;
      userId: number;
      orderId: string;
      provider: string;
      amountInr: number;
      status: string;
      providerTransactionId: string | null;
      verificationMethod: string | null;
      failureReason: string | null;
      createdAt: string;
      verifiedAt: string | null;
    }>
  >([]);

  const [auditLogs, setAuditLogs] = useState<
    Array<{
      id: number;
      actorUserId: number | null;
      targetUserId: number | null;
      eventType: string;
      details: string;
      createdAt: string;
    }>
  >([]);

  const [horoscopes, setHoroscopes] = useState<
    Array<{
      id: number;
      rashi: string;
      rashiHindi: string;
      symbol: string;
      dailyForecastHinglish: string;
      dailyForecastHindi: string;
      dailyForecastEnglish: string;
      luckyColor: string;
      luckyNumber: string;
      positiveHabit: string;
    }>
  >([]);

  const [configs, setConfigs] = useState<Array<{ key: string; value: string }>>(
    []
  );
  const [selectedRashiId, setSelectedRashiId] = useState<number>(1);
  const [statusBanner, setStatusBanner] = useState<string | null>(null);

  const fetchAdminData = useCallback(async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetch("/api/admin", {
        headers: token ? { Authorization: `Bearer ${token}` } : {},
      });
      if (res.status === 403) {
        setAccessDenied(true);
        setLoading(false);
        return;
      }
      if (!res.ok) {
        throw new Error("Failed to load admin data");
      }
      const data = await res.json();
      setAccessDenied(false);
      setStats(data.stats);
      setUsersList(data.users || []);
      setPaymentsList(data.payments || []);
      setAuditLogs(data.auditLogs || []);
      setHoroscopes(data.horoscopes || []);
      setConfigs(data.configs || []);
      if (data.horoscopes?.length > 0 && !selectedRashiId) {
        setSelectedRashiId(data.horoscopes[0].id);
      }
    } catch (err) {
      setErrorMsg(
        err instanceof Error ? err.message : "Error loading admin portal"
      );
    } finally {
      setLoading(false);
    }
  }, [token, selectedRashiId]);

  useEffect(() => {
    fetchAdminData();
  }, [fetchAdminData]);

  const handleUpdateUserSub = async (targetUserId: number, status: string) => {
    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          action: "admin_update_subscription",
          targetUserId,
          status,
          reason: `Admin manual status change to ${status}`,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatusBanner(data.message);
        fetchAdminData();
      }
    } catch {
      setErrorMsg("Failed to update user subscription status");
    }
  };

  const handleSaveHoroscope = async (
    h: (typeof horoscopes)[number]
  ) => {
    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          action: "update_horoscope",
          ...h,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatusBanner(data.message);
        fetchAdminData();
      }
    } catch {
      setErrorMsg("Failed to update horoscope");
    }
  };

  const handleSaveConfig = async (key: string, value: string) => {
    try {
      const res = await fetch("/api/admin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
        },
        body: JSON.stringify({
          action: "update_config",
          key,
          value,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatusBanner(data.message);
        fetchAdminData();
      }
    } catch {
      setErrorMsg("Failed to update config");
    }
  };

  if (accessDenied || (currentUserRole && currentUserRole !== "admin")) {
    return (
      <div className="min-h-screen bg-[#FFF9F5] flex items-center justify-center p-6">
        <div className="max-w-md w-full bg-white border-2 border-[#C93B2B]/30 rounded-3xl p-8 text-center shadow-lg">
          <div className="w-16 h-16 rounded-full bg-[#C93B2B]/10 text-[#C93B2B] flex items-center justify-center mx-auto mb-4">
            <Lock className="w-8 h-8" />
          </div>
          <span className="text-xs font-mono-vedic uppercase tracking-wider px-3 py-1 rounded-full bg-[#C93B2B]/10 text-[#C93B2B] font-semibold">
            HTTP 403 • RBAC Security Gate
          </span>
          <h2 className="text-2xl font-serif-vedic text-[#2A162D] mt-3">
            Administrator Access Required
          </h2>
          <p className="text-sm text-[#6E5273] mt-2 leading-relaxed">
            Ordinary user accounts are strictly prohibited from accessing the
            Gita AI Admin Dashboard, payment verification records, or system
            configurations.
          </p>
          <div className="mt-6 flex flex-col gap-3">
            {onSwitchToAdminAccount && (
              <button
                onClick={onSwitchToAdminAccount}
                className="w-full py-3.5 px-5 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white font-semibold text-sm shadow-md hover:opacity-95 transition cursor-pointer"
              >
                Switch to Authorized Admin Account (admin@gita-ai.in)
              </button>
            )}
            {onBackToApp && (
              <button
                onClick={onBackToApp}
                className="w-full py-3 px-5 rounded-full border border-[#7C2D86]/30 text-[#7C2D86] font-semibold text-sm hover:bg-[#FDF3EE] transition cursor-pointer"
              >
                Return to Gita AI User App
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  const selectedHoroscope =
    horoscopes.find((h) => h.id === selectedRashiId) || horoscopes[0];

  return (
    <div className="min-h-screen bg-[#FFF9F5] text-[#2A162D]">
      {/* Top Admin Header */}
      <header className="sticky top-0 z-30 bg-[#FFF9F5]/95 backdrop-blur-md border-b border-[#EFE1E6] px-6 py-4">
        <div className="max-w-6xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {onBackToApp && (
              <button
                onClick={onBackToApp}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-full bg-[#FDF3EE] border border-[#EFE1E6] text-xs font-semibold text-[#7C2D86] hover:bg-[#7C2D86] hover:text-white transition cursor-pointer"
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Mobile App
              </button>
            )}
            <div>
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-[#7C2D86]" />
                <h1 className="text-xl font-serif-vedic text-[#2A162D]">
                  Gita AI — Secure Admin Dashboard
                </h1>
                <span className="text-[11px] font-mono-vedic uppercase px-2.5 py-0.5 rounded-full bg-[#1E7E5A]/15 text-[#1E7E5A] font-semibold">
                  RBAC: ADMIN VERIFIED
                </span>
              </div>
              <p className="text-xs text-[#6E5273]">
                Zero-secret exposure • Auditable subscription & payment ledger •
                Daily Panchang & Rashi CMS
              </p>
            </div>
          </div>

          <button
            onClick={fetchAdminData}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-full border border-[#7C2D86]/30 text-xs font-semibold text-[#7C2D86] hover:bg-[#FDF3EE] transition cursor-pointer"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? "animate-spin" : ""}`} />
            Refresh Telemetry
          </button>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-6 py-6">
        {statusBanner && (
          <div className="mb-5 p-3.5 rounded-2xl bg-[#1E7E5A]/10 border border-[#1E7E5A]/30 text-[#1E7E5A] text-sm flex items-center justify-between">
            <span className="font-medium">{statusBanner}</span>
            <button
              onClick={() => setStatusBanner(null)}
              className="text-xs underline ml-4 cursor-pointer"
            >
              Dismiss
            </button>
          </div>
        )}

        {errorMsg && (
          <div className="mb-5 p-3.5 rounded-2xl bg-[#C93B2B]/10 border border-[#C93B2B]/30 text-[#C93B2B] text-sm">
            {errorMsg}
          </div>
        )}

        {/* Navigation Tabs */}
        <div className="flex flex-wrap gap-2 mb-6 border-b border-[#EFE1E6] pb-3">
          {[
            { id: "overview", label: "Overview & Metrics", icon: Users },
            { id: "users", label: "User & Trial Directory", icon: Users },
            {
              id: "payments",
              label: "Payment Verification Ledger",
              icon: IndianRupee,
            },
            {
              id: "content",
              label: "Daily Horoscope CMS",
              icon: Sparkles,
            },
            { id: "config", label: "App Configuration", icon: Settings },
            { id: "audit", label: "Security Audit Trail", icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() =>
                  setActiveTab(tab.id as typeof activeTab)
                }
                className={`inline-flex items-center gap-2 px-4 py-2.5 rounded-full text-xs font-semibold transition cursor-pointer ${
                  active
                    ? "bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white shadow-sm"
                    : "bg-[#FDF3EE] text-[#6E5273] hover:text-[#2A162D]"
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* OVERVIEW TAB */}
        {activeTab === "overview" && stats && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="bg-white p-5 rounded-2xl border border-[#EFE1E6] shadow-xs">
                <span className="text-xs text-[#6E5273] font-medium">
                  Total Registered Users
                </span>
                <div className="text-3xl font-bold text-[#2A162D] mt-1 font-mono-vedic">
                  {stats.totalUsers}
                </div>
                <span className="text-[11px] text-[#1E7E5A] mt-1 inline-block">
                  {stats.trialUsers} eligible / in-trial
                </span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#EFE1E6] shadow-xs">
                <span className="text-xs text-[#6E5273] font-medium">
                  Active ₹49/mo Subscribers
                </span>
                <div className="text-3xl font-bold text-[#7C2D86] mt-1 font-mono-vedic">
                  {stats.activeSubscribers}
                </div>
                <span className="text-[11px] text-[#6E5273] mt-1 inline-block">
                  {stats.expiredOrCancelledUsers} expired/cancelled
                </span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#EFE1E6] shadow-xs">
                <span className="text-xs text-[#6E5273] font-medium">
                  Verified Subscription Revenue
                </span>
                <div className="text-3xl font-bold text-[#1E7E5A] mt-1 font-mono-vedic">
                  ₹{stats.totalVerifiedRevenueInr}
                </div>
                <span className="text-[11px] text-[#6E5273] mt-1 inline-block">
                  {stats.verifiedPaymentsCount} verified server webhooks
                </span>
              </div>

              <div className="bg-white p-5 rounded-2xl border border-[#EFE1E6] shadow-xs">
                <span className="text-xs text-[#6E5273] font-medium">
                  Astrology Usage Volume
                </span>
                <div className="text-3xl font-bold text-[#2A162D] mt-1 font-mono-vedic">
                  {stats.totalChatInteractionsCount}
                </div>
                <span className="text-[11px] text-[#7C2D86] mt-1 inline-block">
                  Messages • {stats.totalKundliChartsCount} Kundli Charts
                </span>
              </div>
            </div>

            {/* Payment Verification Breakdown */}
            <div className="bg-white p-6 rounded-2xl border border-[#EFE1E6]">
              <h3 className="text-base font-bold text-[#2A162D] mb-4">
                Payment Verification Status Summary (Server-Side Truth)
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                <div className="p-4 rounded-xl bg-[#1E7E5A]/10 border border-[#1E7E5A]/20">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1E7E5A]">
                    <CheckCircle2 className="w-4 h-4" /> Verified
                  </div>
                  <div className="text-2xl font-bold font-mono-vedic mt-1">
                    {stats.verifiedPaymentsCount}
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-[#D97706]/10 border border-[#D97706]/20">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#D97706]">
                    <Clock className="w-4 h-4" /> Pending
                  </div>
                  <div className="text-2xl font-bold font-mono-vedic mt-1">
                    {stats.pendingPaymentsCount}
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-[#C93B2B]/10 border border-[#C93B2B]/20">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#C93B2B]">
                    <AlertTriangle className="w-4 h-4" /> Failed
                  </div>
                  <div className="text-2xl font-bold font-mono-vedic mt-1">
                    {stats.failedPaymentsCount}
                  </div>
                </div>
                <div className="p-4 rounded-xl bg-[#6E5273]/10 border border-[#6E5273]/20">
                  <div className="flex items-center gap-1.5 text-xs font-semibold text-[#6E5273]">
                    Refunded
                  </div>
                  <div className="text-2xl font-bold font-mono-vedic mt-1">
                    {stats.refundedPaymentsCount}
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* USERS TAB */}
        {activeTab === "users" && (
          <div className="bg-white rounded-2xl border border-[#EFE1E6] overflow-hidden">
            <div className="p-5 border-b border-[#EFE1E6] flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-[#2A162D]">
                  Sanitized User & Entitlement Directory
                </h3>
                <p className="text-xs text-[#6E5273]">
                  Passwords, payment PINs, and private chat logs are strictly
                  redacted. All status overrides are logged.
                </p>
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#FDF3EE] text-[#6E5273] uppercase">
                    <th className="py-3 px-4">ID / Name</th>
                    <th className="py-3 px-4">Masked Email</th>
                    <th className="py-3 px-4">Lang / Rashi</th>
                    <th className="py-3 px-4">15s Trial Used</th>
                    <th className="py-3 px-4">Subscription Status</th>
                    <th className="py-3 px-4">Admin Audit Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EFE1E6]">
                  {usersList.map((u) => (
                    <tr key={u.id} className="hover:bg-[#FFF9F5]">
                      <td className="py-3.5 px-4 font-semibold text-[#2A162D]">
                        #{u.id} {u.name}
                        {u.role === "admin" && (
                          <span className="ml-1.5 px-2 py-0.5 rounded-full bg-[#7C2D86]/15 text-[#7C2D86] text-[10px]">
                            Admin
                          </span>
                        )}
                      </td>
                      <td className="py-3.5 px-4 font-mono-vedic text-[#6E5273]">
                        {u.maskedEmail}
                      </td>
                      <td className="py-3.5 px-4">
                        <span className="capitalize font-medium">
                          {u.preferredLanguage}
                        </span>{" "}
                        • {u.rashi}
                      </td>
                      <td className="py-3.5 px-4 font-mono-vedic">
                        {u.trialUsed ? "Yes (Consumed)" : "No (Eligible 15s)"}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2.5 py-1 rounded-full font-semibold uppercase text-[10px] ${
                            u.subscriptionStatus === "active"
                              ? "bg-[#1E7E5A]/15 text-[#1E7E5A]"
                              : u.subscriptionStatus === "trial"
                              ? "bg-[#D97706]/15 text-[#D97706]"
                              : "bg-[#C93B2B]/15 text-[#C93B2B]"
                          }`}
                        >
                          {u.subscriptionStatus}
                        </span>
                      </td>
                      <td className="py-3.5 px-4">
                        <div className="flex flex-wrap gap-1.5">
                          <button
                            onClick={() => handleUpdateUserSub(u.id, "active")}
                            className="px-2.5 py-1 rounded-lg bg-[#1E7E5A]/10 text-[#1E7E5A] hover:bg-[#1E7E5A] hover:text-white transition font-semibold cursor-pointer"
                          >
                            Activate ₹49
                          </button>
                          <button
                            onClick={() => handleUpdateUserSub(u.id, "expired")}
                            className="px-2.5 py-1 rounded-lg bg-[#C93B2B]/10 text-[#C93B2B] hover:bg-[#C93B2B] hover:text-white transition font-semibold cursor-pointer"
                          >
                            Expire
                          </button>
                          <button
                            onClick={() => handleUpdateUserSub(u.id, "none")}
                            className="px-2.5 py-1 rounded-lg bg-[#7C2D86]/10 text-[#7C2D86] hover:bg-[#7C2D86] hover:text-white transition font-semibold cursor-pointer"
                          >
                            Reset 15s Trial
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PAYMENTS TAB */}
        {activeTab === "payments" && (
          <div className="bg-white rounded-2xl border border-[#EFE1E6] overflow-hidden">
            <div className="p-5 border-b border-[#EFE1E6]">
              <h3 className="text-base font-bold text-[#2A162D]">
                Payment Verification & Webhook Records
              </h3>
              <p className="text-xs text-[#6E5273]">
                Every ₹49 subscription order and its server-side HMAC / gateway
                verification status.
              </p>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-[#FDF3EE] text-[#6E5273] uppercase">
                    <th className="py-3 px-4">Order ID</th>
                    <th className="py-3 px-4">User ID</th>
                    <th className="py-3 px-4">Provider</th>
                    <th className="py-3 px-4">Amount</th>
                    <th className="py-3 px-4">Status</th>
                    <th className="py-3 px-4">Verification Method / Reason</th>
                    <th className="py-3 px-4">Timestamp</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EFE1E6]">
                  {paymentsList.map((p) => (
                    <tr key={p.id} className="hover:bg-[#FFF9F5]">
                      <td className="py-3.5 px-4 font-mono-vedic font-semibold text-[#2A162D]">
                        {p.orderId}
                      </td>
                      <td className="py-3.5 px-4 font-mono-vedic">
                        #{p.userId}
                      </td>
                      <td className="py-3.5 px-4 uppercase font-medium">
                        {p.provider.replace(/_/g, " ")}
                      </td>
                      <td className="py-3.5 px-4 font-mono-vedic font-bold">
                        ₹{p.amountInr}
                      </td>
                      <td className="py-3.5 px-4">
                        <span
                          className={`px-2.5 py-1 rounded-full font-semibold uppercase text-[10px] ${
                            p.status === "verified"
                              ? "bg-[#1E7E5A]/15 text-[#1E7E5A]"
                              : p.status === "pending"
                              ? "bg-[#D97706]/15 text-[#D97706]"
                              : "bg-[#C93B2B]/15 text-[#C93B2B]"
                          }`}
                        >
                          {p.status}
                        </span>
                      </td>
                      <td className="py-3.5 px-4 text-[#6E5273]">
                        <div>{p.verificationMethod}</div>
                        {p.failureReason && (
                          <div className="text-[11px] text-[#C93B2B]">
                            {p.failureReason}
                          </div>
                        )}
                      </td>
                      <td className="py-3.5 px-4 font-mono-vedic text-[#6E5273]">
                        {new Date(p.createdAt).toLocaleString()}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* DAILY HOROSCOPE CMS TAB */}
        {activeTab === "content" && selectedHoroscope && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="bg-white p-4 rounded-2xl border border-[#EFE1E6] space-y-1.5">
              <h3 className="text-sm font-bold text-[#2A162D] px-2 mb-2">
                Select Vedic Rashi (12 Signs)
              </h3>
              {horoscopes.map((h) => (
                <button
                  key={h.id}
                  onClick={() => setSelectedRashiId(h.id)}
                  className={`w-full text-left px-3.5 py-2.5 rounded-xl text-xs font-semibold flex items-center justify-between transition cursor-pointer ${
                    h.id === selectedHoroscope.id
                      ? "bg-[#7C2D86] text-white"
                      : "hover:bg-[#FDF3EE] text-[#2A162D]"
                  }`}
                >
                  <span>
                    {h.symbol} {h.rashi}
                  </span>
                  <span className="opacity-80">{h.rashiHindi}</span>
                </button>
              ))}
            </div>

            <div className="lg:col-span-2 bg-white p-6 rounded-2xl border border-[#EFE1E6] space-y-4">
              <div className="flex items-center justify-between border-b border-[#EFE1E6] pb-3">
                <div>
                  <h3 className="text-base font-bold text-[#2A162D]">
                    Edit Daily Horoscope: {selectedHoroscope.symbol}{" "}
                    {selectedHoroscope.rashi}
                  </h3>
                  <p className="text-xs text-[#6E5273]">
                    Changes immediately reflect on the Home Screen and Daily
                    Horoscope Screen.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                    Lucky Colour
                  </label>
                  <input
                    type="text"
                    value={selectedHoroscope.luckyColor}
                    onChange={(e) =>
                      setHoroscopes((prev) =>
                        prev.map((item) =>
                          item.id === selectedHoroscope.id
                            ? { ...item, luckyColor: e.target.value }
                            : item
                        )
                      )
                    }
                    className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                    Lucky Number
                  </label>
                  <input
                    type="text"
                    value={selectedHoroscope.luckyNumber}
                    onChange={(e) =>
                      setHoroscopes((prev) =>
                        prev.map((item) =>
                          item.id === selectedHoroscope.id
                            ? { ...item, luckyNumber: e.target.value }
                            : item
                        )
                      )
                    }
                    className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs font-mono-vedic"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                  Hinglish Daily Forecast
                </label>
                <textarea
                  rows={2}
                  value={selectedHoroscope.dailyForecastHinglish}
                  onChange={(e) =>
                    setHoroscopes((prev) =>
                      prev.map((item) =>
                        item.id === selectedHoroscope.id
                          ? { ...item, dailyForecastHinglish: e.target.value }
                          : item
                      )
                    )
                  }
                  className="w-full p-3 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                  Hindi (हिंदी) Daily Forecast
                </label>
                <textarea
                  rows={2}
                  value={selectedHoroscope.dailyForecastHindi}
                  onChange={(e) =>
                    setHoroscopes((prev) =>
                      prev.map((item) =>
                        item.id === selectedHoroscope.id
                          ? { ...item, dailyForecastHindi: e.target.value }
                          : item
                      )
                    )
                  }
                  className="w-full p-3 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                  English Daily Forecast
                </label>
                <textarea
                  rows={2}
                  value={selectedHoroscope.dailyForecastEnglish}
                  onChange={(e) =>
                    setHoroscopes((prev) =>
                      prev.map((item) =>
                        item.id === selectedHoroscope.id
                          ? { ...item, dailyForecastEnglish: e.target.value }
                          : item
                      )
                    )
                  }
                  className="w-full p-3 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                  Suggested Positive Habit
                </label>
                <input
                  type="text"
                  value={selectedHoroscope.positiveHabit}
                  onChange={(e) =>
                    setHoroscopes((prev) =>
                      prev.map((item) =>
                        item.id === selectedHoroscope.id
                          ? { ...item, positiveHabit: e.target.value }
                          : item
                      )
                    )
                  }
                  className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                />
              </div>

              <button
                onClick={() => handleSaveHoroscope(selectedHoroscope)}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white text-xs font-semibold shadow-sm cursor-pointer"
              >
                <Save className="w-4 h-4" />
                Save Rashi Content Update
              </button>
            </div>
          </div>
        )}

        {/* CONFIG TAB */}
        {activeTab === "config" && (
          <div className="bg-white p-6 rounded-2xl border border-[#EFE1E6] space-y-5">
            <div>
              <h3 className="text-base font-bold text-[#2A162D]">
                Global App Configuration
              </h3>
              <p className="text-xs text-[#6E5273]">
                Manage Gita AI welcome greeting, daily astrologer note, and
                ethical disclaimer text.
              </p>
            </div>
            <div className="space-y-4">
              {configs.map((cfg) => (
                <div
                  key={cfg.key}
                  className="p-4 rounded-xl bg-[#FDF3EE] border border-[#EFE1E6] flex flex-col sm:flex-row sm:items-center gap-3"
                >
                  <div className="sm:w-56 shrink-0">
                    <span className="text-xs font-mono-vedic font-bold text-[#7C2D86]">
                      {cfg.key}
                    </span>
                  </div>
                  <input
                    type="text"
                    value={cfg.value}
                    onChange={(e) =>
                      setConfigs((prev) =>
                        prev.map((item) =>
                          item.key === cfg.key
                            ? { ...item, value: e.target.value }
                            : item
                        )
                      )
                    }
                    className="flex-1 h-10 px-3 rounded-lg bg-white border border-[#E5D4E8] text-xs"
                  />
                  <button
                    onClick={() => handleSaveConfig(cfg.key, cfg.value)}
                    className="px-4 py-2 rounded-full bg-[#7C2D86] text-white text-xs font-semibold hover:opacity-95 cursor-pointer shrink-0"
                  >
                    Save
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* AUDIT TRAIL TAB */}
        {activeTab === "audit" && (
          <div className="bg-white rounded-2xl border border-[#EFE1E6] overflow-hidden">
            <div className="p-5 border-b border-[#EFE1E6]">
              <h3 className="text-base font-bold text-[#2A162D]">
                Immutable Subscription & Payment Audit Logs
              </h3>
              <p className="text-xs text-[#6E5273]">
                Chronological record of trial starts, expirations, payment
                verifications, cancellations, refunds, and admin actions.
              </p>
            </div>
            <div className="divide-y divide-[#EFE1E6]">
              {auditLogs.map((log) => (
                <div
                  key={log.id}
                  className="p-4 hover:bg-[#FFF9F5] flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs"
                >
                  <div>
                    <span className="font-mono-vedic font-bold text-[#7C2D86] bg-[#7C2D86]/10 px-2.5 py-0.5 rounded-full">
                      {log.eventType}
                    </span>
                    <span className="ml-2 text-[#6E5273]">
                      Actor #{log.actorUserId ?? "System"} → Target #
                      {log.targetUserId ?? "Global"}
                    </span>
                    <div className="mt-1.5 font-mono-vedic text-[11px] text-[#2A162D] break-all">
                      {log.details}
                    </div>
                  </div>
                  <div className="text-[11px] font-mono-vedic text-[#6E5273] shrink-0">
                    {new Date(log.createdAt).toLocaleString()}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
