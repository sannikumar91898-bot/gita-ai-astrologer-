"use client";

import React, { useState } from "react";
import { GitaAvatar } from "./VedicGraphics";
import {
  Sparkles,
  ShieldCheck,
  CheckCircle2,
  ArrowLeft,
  HelpCircle,
  FileText,
  Trash2,
  Lock,
  UserPlus,
  LogIn,
  ChevronRight,
  AlertTriangle,
} from "lucide-react";

export function SplashScreenOverlay({
  onContinue,
}: {
  onContinue: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 bg-gradient-to-b from-[#FFF9F5] via-[#FDF3EE] to-[#F7E5EC] flex flex-col items-center justify-between p-8 text-center">
      <div className="mt-4">
        <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-[#B8860B] text-xs font-semibold tracking-wider uppercase">
          ॥ श्री गणेशाय नमः • Vedic AI Sanctuary ॥
        </span>
      </div>

      <div className="flex flex-col items-center max-w-xs">
        <GitaAvatar size="xl" showOnline={true} />
        <h1 className="text-3xl font-serif-vedic text-[#2A162D] mt-6 tracking-tight">
          Gita AI
        </h1>
        <p className="text-sm font-semibold text-[#7C2D86] mt-1">
          Your Favorite Astrologer
        </p>
        <p className="text-xs text-[#6E5273] mt-3 leading-relaxed">
          “Namaste! Main Gita hoon. Aapke Career, Love, Marriage aur Kundli ke
          har sawal ke liye aapki apni samajhdar AI jyotish margdarshak.”
        </p>
      </div>

      <div className="w-full max-w-xs space-y-3">
        <button
          onClick={onContinue}
          className="w-full py-3.5 px-6 rounded-full bg-gradient-to-r from-[#7C2D86] via-[#C93B76] to-[#E14B7B] text-white font-semibold text-sm shadow-lg hover:opacity-95 transition flex items-center justify-center gap-2 cursor-pointer"
        >
          <span>Prarambh Karein (Enter Gita AI)</span>
          <ChevronRight className="w-4 h-4" />
        </button>
        <p className="text-[11px] text-[#6E5273]">
          Hindi • Hinglish • English | 15s Free Trial • ₹49/month
        </p>
      </div>
    </div>
  );
}

export function OnboardingView({
  onFinish,
}: {
  onFinish: () => void;
}) {
  const [step, setStep] = useState(0);

  const slides = [
    {
      badge: "1 / 3 • Natural Hindi & Hinglish AI",
      title: "Apni Bhasha Mein Dil Khol Kar Baat Karein",
      subtitle:
        "Gita AI aapke Career, Love, Marriage, Family aur Money ke sawalon ko ek sacche mitra aur anubhavi jyotish ki tarah samajhti hai — Hindi, Hinglish aur English mein.",
      points: [
        "Samvedansheel aur sammanjanak ('Aap' aur 'Ji') samvad",
        "Koi darane wale daave ya mehenge upay ka dabav nahi",
        "Pichli baaton aur aapki janm-kundli ka dhyan rakhne wali AI",
      ],
    },
    {
      badge: "2 / 3 • Kundli & Daily Panchang",
      title: "Janm Vivaran Se Personalized Margdarshan",
      subtitle:
        "Apni Janm Tithi (aur optional Janm Samay va Sthan) jodkar apni Chandra Rashi, Nakshatra, 12 Bhava Kundli, Shubh Rang aur Shubh Ank jaanein.",
      points: [
        "North Indian Diamond Kundli chart aur saral vishleshan",
        "Rozana Rashi bhavishya, sakaratmak aadat aur dhyan upay",
        "Spasht aur imandar calculation disclosure",
      ],
    },
    {
      badge: "3 / 3 • 15s Free Trial & ₹49/Month",
      title: "15-Second Free Trial Aur Imandar ₹49/Mo Plan",
      subtitle:
        "Har naye eligible user ko pehle chat par 15-second ka muft anubhav milta hai. Uske baad sirf ₹49/month mein asimit AI jyotish margdarshan.",
      points: [
        "15-second live countdown timer — bina aapki marzi ke koi charge nahi",
        "Surakshit server-side UPI, PhonePe aur Play Billing verification",
        "Kabhi bhi aasani se cancel karein",
      ],
    },
  ];

  const current = slides[step];

  return (
    <div className="p-5 space-y-6">
      <div className="bg-gradient-to-br from-[#FFF9F5] via-[#FDF3EE] to-[#F7E5EC] border border-[#EFE1E6] rounded-3xl p-6 text-center shadow-sm">
        <GitaAvatar size="lg" />
        <div className="mt-4">
          <span className="text-[11px] font-mono-vedic uppercase tracking-wider px-3 py-1 rounded-full bg-[#7C2D86]/10 text-[#7C2D86] font-semibold">
            {current.badge}
          </span>
          <h2 className="text-xl font-serif-vedic text-[#2A162D] mt-3">
            {current.title}
          </h2>
          <p className="text-xs text-[#6E5273] mt-2 leading-relaxed">
            {current.subtitle}
          </p>
        </div>

        <div className="mt-5 space-y-2.5 text-left bg-white/80 p-4 rounded-2xl border border-[#EFE1E6]">
          {current.points.map((pt, i) => (
            <div key={i} className="flex items-start gap-2.5 text-xs text-[#2A162D]">
              <CheckCircle2 className="w-4 h-4 text-[#1E7E5A] shrink-0 mt-0.5" />
              <span>{pt}</span>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-center gap-2 mt-5">
          {slides.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setStep(idx)}
              className={`h-2 rounded-full transition-all cursor-pointer ${
                idx === step ? "w-7 bg-[#7C2D86]" : "w-2 bg-[#D8C2DC]"
              }`}
            />
          ))}
        </div>

        <div className="mt-6 flex gap-3">
          {step < slides.length - 1 ? (
            <>
              <button
                onClick={onFinish}
                className="flex-1 py-3 rounded-full border border-[#7C2D86]/30 text-xs font-semibold text-[#7C2D86] cursor-pointer"
              >
                Skip
              </button>
              <button
                onClick={() => setStep(step + 1)}
                className="flex-2 py-3 px-6 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white text-xs font-semibold shadow-md cursor-pointer"
              >
                Aage Badhein (Next)
              </button>
            </>
          ) : (
            <button
              onClick={onFinish}
              className="w-full py-3.5 px-6 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white text-sm font-semibold shadow-md cursor-pointer"
            >
              Gita AI Shuru Karein ✨
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export function AuthScreenView({
  onAuthSuccess,
  onBack,
}: {
  onAuthSuccess: (data: { token: string; user: unknown }) => void;
  onBack: () => void;
}) {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [preferredLanguage, setPreferredLanguage] = useState<
    "hinglish" | "hindi" | "english"
  >("hinglish");
  const [birthDate, setBirthDate] = useState("");
  const [birthTime, setBirthTime] = useState("");
  const [birthPlace, setBirthPlace] = useState("");
  const [consentGiven, setConsentGiven] = useState(true);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: mode,
          name,
          email,
          phone,
          password,
          preferredLanguage,
          birthDate: birthDate || null,
          birthTime: birthTime || null,
          birthPlace: birthPlace || null,
          consentGiven,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Authentication failed");
      } else {
        onAuthSuccess({ token: data.token, user: data.user });
      }
    } catch {
      setError("Network error. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleQuickDemoSwitch = async (demoEmail: string) => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "switch_account",
          email: demoEmail,
        }),
      });
      const data = await res.json();
      if (res.ok) {
        onAuthSuccess({ token: data.token, user: data.user });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-4 space-y-5">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#7C2D86] cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" /> Home par wapas jayein
        </button>
        <span className="text-[11px] font-mono-vedic text-[#6E5273]">
          Secure Auth & Consent
        </span>
      </div>

      {/* 1-Tap Evaluator Account Switcher */}
      <div className="bg-[#FDF3EE] border border-[#D4AF37]/40 rounded-2xl p-3.5 space-y-2">
        <div className="text-[11px] font-bold uppercase tracking-wider text-[#B8860B]">
          Quick Test Accounts (1-Tap Switch)
        </div>
        <div className="grid grid-cols-1 gap-2">
          <button
            type="button"
            onClick={() => handleQuickDemoSwitch("aarav@gita-ai.in")}
            className="w-full text-left px-3 py-2 rounded-xl bg-white border border-[#EFE1E6] hover:border-[#7C2D86] text-xs flex items-center justify-between cursor-pointer"
          >
            <div>
              <strong className="text-[#2A162D]">Aarav Sharma</strong>{" "}
              <span className="text-[#6E5273]">(aarav@gita-ai.in)</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-[#D97706]/15 text-[#D97706] font-semibold text-[10px]">
              15s Trial User
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickDemoSwitch("priya@gita-ai.in")}
            className="w-full text-left px-3 py-2 rounded-xl bg-white border border-[#EFE1E6] hover:border-[#7C2D86] text-xs flex items-center justify-between cursor-pointer"
          >
            <div>
              <strong className="text-[#2A162D]">Priya Verma</strong>{" "}
              <span className="text-[#6E5273]">(priya@gita-ai.in)</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-[#1E7E5A]/15 text-[#1E7E5A] font-semibold text-[10px]">
              ₹49/mo Active
            </span>
          </button>

          <button
            type="button"
            onClick={() => handleQuickDemoSwitch("admin@gita-ai.in")}
            className="w-full text-left px-3 py-2 rounded-xl bg-white border border-[#EFE1E6] hover:border-[#7C2D86] text-xs flex items-center justify-between cursor-pointer"
          >
            <div>
              <strong className="text-[#2A162D]">Acharya Admin</strong>{" "}
              <span className="text-[#6E5273]">(admin@gita-ai.in)</span>
            </div>
            <span className="px-2 py-0.5 rounded-full bg-[#7C2D86]/15 text-[#7C2D86] font-semibold text-[10px]">
              RBAC Admin
            </span>
          </button>
        </div>
      </div>

      {/* Mode Switcher */}
      <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 shadow-xs space-y-4">
        <div className="flex rounded-full bg-[#FDF3EE] p-1">
          <button
            type="button"
            onClick={() => setMode("login")}
            className={`flex-1 py-2.5 rounded-full text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
              mode === "login"
                ? "bg-[#7C2D86] text-white shadow-xs"
                : "text-[#6E5273]"
            }`}
          >
            <LogIn className="w-3.5 h-3.5" /> Login
          </button>
          <button
            type="button"
            onClick={() => setMode("register")}
            className={`flex-1 py-2.5 rounded-full text-xs font-semibold flex items-center justify-center gap-1.5 transition cursor-pointer ${
              mode === "register"
                ? "bg-[#7C2D86] text-white shadow-xs"
                : "text-[#6E5273]"
            }`}
          >
            <UserPlus className="w-3.5 h-3.5" /> New Sign Up (15s Trial)
          </button>
        </div>

        {error && (
          <div className="p-3 rounded-xl bg-[#C93B2B]/10 border border-[#C93B2B]/30 text-[#C93B2B] text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-3.5">
          {mode === "register" && (
            <div>
              <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                Aapka Shubh Naam (Full Name) *
              </label>
              <input
                type="text"
                required
                placeholder="e.g., Ananya Gupta"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-[#2A162D] mb-1">
              Email Address *
            </label>
            <input
              type="email"
              required
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
            />
          </div>

          {mode === "register" && (
            <div>
              <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                Mobile Number (Optional)
              </label>
              <input
                type="tel"
                placeholder="+91 98765 43210"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
              />
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold text-[#2A162D] mb-1">
              Password * (Min 6 characters)
            </label>
            <input
              type="password"
              required
              placeholder="••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
            />
          </div>

          {mode === "register" && (
            <>
              <div>
                <label className="block text-xs font-semibold text-[#2A162D] mb-1">
                  Pasandida Bhasha (Preferred Language)
                </label>
                <select
                  value={preferredLanguage}
                  onChange={(e) =>
                    setPreferredLanguage(
                      e.target.value as "hinglish" | "hindi" | "english"
                    )
                  }
                  className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8] text-xs"
                >
                  <option value="hinglish">Hinglish (Default - Natural)</option>
                  <option value="hindi">हिंदी (Devanagari Hindi)</option>
                  <option value="english">English</option>
                </select>
              </div>

              <div className="p-3.5 rounded-2xl bg-[#FFF9F5] border border-[#EFE1E6] space-y-3">
                <div className="text-xs font-bold text-[#7C2D86]">
                  Janm Vivaran (For Personalized Kundli & Rashi)
                </div>
                <div>
                  <label className="block text-[11px] font-semibold text-[#2A162D] mb-1">
                    Birth Date (Optional at Sign-Up)
                  </label>
                  <input
                    type="date"
                    value={birthDate}
                    onChange={(e) => setBirthDate(e.target.value)}
                    className="w-full h-10 px-3 rounded-xl bg-white border border-[#E5D4E8] text-xs font-mono-vedic"
                  />
                </div>
                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] font-semibold text-[#2A162D] mb-1">
                      Birth Time (Optional)
                    </label>
                    <input
                      type="time"
                      value={birthTime}
                      onChange={(e) => setBirthTime(e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-white border border-[#E5D4E8] text-xs font-mono-vedic"
                    />
                  </div>
                  <div>
                    <label className="block text-[11px] font-semibold text-[#2A162D] mb-1">
                      Birthplace (Optional)
                    </label>
                    <input
                      type="text"
                      placeholder="City, State"
                      value={birthPlace}
                      onChange={(e) => setBirthPlace(e.target.value)}
                      className="w-full h-10 px-3 rounded-xl bg-white border border-[#E5D4E8] text-xs"
                    />
                  </div>
                </div>
              </div>

              <label className="flex items-start gap-2.5 text-xs text-[#6E5273] cursor-pointer">
                <input
                  type="checkbox"
                  checked={consentGiven}
                  onChange={(e) => setConsentGiven(e.target.checked)}
                  className="mt-1 accent-[#7C2D86]"
                />
                <span>
                  I consent to Gita AI storing my name, preferred language, and
                  optional birth details to provide personalized astrology-style
                  readings. I understand I can delete my account and data at any
                  time.
                </span>
              </label>
            </>
          )}

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3.5 rounded-full bg-gradient-to-r from-[#7C2D86] to-[#E14B7B] text-white font-semibold text-xs shadow-md hover:opacity-95 transition cursor-pointer"
          >
            {loading
              ? "Kripya pratiksha karein..."
              : mode === "login"
              ? "Login to Gita AI"
              : "Create Account & Claim 15s Free Trial"}
          </button>
        </form>
      </div>
    </div>
  );
}

export function LegalAndSupportView({
  section,
  onSelectSection,
  onBack,
  onDeleteAccount,
}: {
  section: "privacy" | "terms" | "help" | "delete_account";
  onSelectSection: (s: "privacy" | "terms" | "help" | "delete_account") => void;
  onBack: () => void;
  onDeleteAccount: (reason: string) => Promise<void>;
}) {
  const [deleteReason, setDeleteReason] = useState("");
  const [confirmCheck, setConfirmCheck] = useState(false);
  const [deleting, setDeleting] = useState(false);

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <button
          onClick={onBack}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#7C2D86] cursor-pointer"
        >
          <ArrowLeft className="w-4 h-4" /> Profile par wapas jayein
        </button>
      </div>

      {/* Sub-navigation pills */}
      <div className="flex flex-wrap gap-1.5">
        {[
          { id: "privacy", label: "Privacy Policy", icon: ShieldCheck },
          { id: "terms", label: "Terms & Conditions", icon: FileText },
          { id: "help", label: "Help & Support", icon: HelpCircle },
          { id: "delete_account", label: "Account Deletion", icon: Trash2 },
        ].map((item) => {
          const Icon = item.icon;
          const active = section === item.id;
          return (
            <button
              key={item.id}
              onClick={() =>
                onSelectSection(item.id as typeof section)
              }
              className={`inline-flex items-center gap-1.5 px-3 py-2 rounded-full text-xs font-semibold transition cursor-pointer ${
                active
                  ? "bg-[#7C2D86] text-white"
                  : "bg-[#FDF3EE] text-[#6E5273]"
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              {item.label}
            </button>
          );
        })}
      </div>

      {section === "privacy" && (
        <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 space-y-3 text-xs text-[#2A162D] leading-relaxed">
          <h2 className="text-lg font-serif-vedic text-[#2A162D]">
            Privacy Policy — Gita AI
          </h2>
          <p className="text-[#6E5273]">
            Effective Year: 2026 • DPDP Act (India) & Google Play User Data
            Policy Compliant
          </p>
          <div className="space-y-2">
            <h4 className="font-bold text-[#7C2D86]">
              1. Minimal Personal Data With Explicit Consent
            </h4>
            <p>
              Gita AI collects only the information necessary to personalize
              your astrology experience: your Name, Email/Phone for login,
              Preferred Language (Hindi/Hinglish/English), Birth Date, and
              optional Birth Time and Birthplace. We never request unnecessary
              permissions (contacts, call logs, or background location).
            </p>
            <h4 className="font-bold text-[#7C2D86]">
              2. Payment Security & Zero Secret Storage
            </h4>
            <p>
              We NEVER ask for, process, or store your UPI PIN, Debit/Credit
              Card PIN, CVV, or netbanking passwords. All ₹49/month subscription
              payments are verified exclusively via server-side gateway webhooks
              and official billing APIs.
            </p>
            <h4 className="font-bold text-[#7C2D86]">
              3. Right to Erasure & Account Deletion
            </h4>
            <p>
              You have complete control over your data. You can edit your birth
              details, clear your chat history, or permanently delete your
              account and all personal readings immediately from the Account
              Deletion tab.
            </p>
          </div>
        </div>
      )}

      {section === "terms" && (
        <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 space-y-3 text-xs text-[#2A162D] leading-relaxed">
          <h2 className="text-lg font-serif-vedic text-[#2A162D]">
            Terms and Conditions — Gita AI
          </h2>
          <div className="space-y-2">
            <h4 className="font-bold text-[#7C2D86]">
              1. Entertainment & Personal Reflection Disclaimer
            </h4>
            <p>
              All AI-generated readings, Kundli interpretations, daily
              horoscopes, and remedies provided by Gita AI are strictly for{" "}
              <strong>entertainment, mindfulness, and personal reflection</strong>
              . They are not scientifically certain predictions and must never
              be used as a substitute for qualified medical, legal, psychological,
              or financial advice.
            </p>
            <h4 className="font-bold text-[#7C2D86]">
              2. 15-Second Free Trial & Eligibility
            </h4>
            <p>
              Each eligible new user account receives one 15-second free chat
              trial starting upon their first initiated chat. Trial eligibility
              is recorded on our secure backend server so reinstalling the
              application does not reset the trial.
            </p>
            <h4 className="font-bold text-[#7C2D86]">
              3. ₹49/Month Subscription & Cancellation
            </h4>
            <p>
              Continuing premium chat after the 15-second trial requires an
              active ₹49/month subscription. You will never be charged without
              your explicit consent. Subscriptions renew monthly at ₹49 unless
              cancelled prior to the end of the current billing period via
              Subscription Management or Google Play / UPI Autopay settings.
            </p>
          </div>
        </div>
      )}

      {section === "help" && (
        <div className="bg-white rounded-3xl border border-[#EFE1E6] p-5 space-y-4 text-xs text-[#2A162D]">
          <h2 className="text-lg font-serif-vedic text-[#2A162D]">
            Help & Support Center
          </h2>
          <div className="space-y-3">
            <div className="p-3.5 rounded-2xl bg-[#FDF3EE]">
              <h4 className="font-bold text-[#7C2D86]">
                Q: Mera 15-second free trial kab shuru hota hai?
              </h4>
              <p className="text-[#6E5273] mt-1">
                Jab aap pehli baar Gita AI ko chat message bhejte hain ya trial
                start karte hain, tab server par 15-second ka live timer shuru
                hota hai.
              </p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#FDF3EE]">
              <h4 className="font-bold text-[#7C2D86]">
                Q: Agar mera ₹49 UPI / PhonePe payment Pending ya Failed dikhaye?
              </h4>
              <p className="text-[#6E5273] mt-1">
                Gita AI keval server-side verified confirmation par hi premium
                unlock karta hai. Agar payment pending hai, toh bank webhook
                aate hi plan active ho jayega, ya failed payment 3–5 working
                days mein aapke bank account mein auto-refund ho jata hai.
              </p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#FDF3EE]">
              <h4 className="font-bold text-[#7C2D86]">
                Q: Kya Janm Samay (Birth Time) zaroori hai?
              </h4>
              <p className="text-[#6E5273] mt-1">
                Janm Tithi (Birth Date) se hum aapki Chandra/Surya Rashi aur
                Nakshatra nikalte hain. Birth Time aur Birthplace optional hain
                — unhe dene par Lagna Kundli bhava aur behtar bante hain.
              </p>
            </div>
            <div className="p-3.5 rounded-2xl bg-[#FFF9F5] border border-[#EFE1E6]">
              <div className="font-bold text-[#2A162D]">
                Sampark Karein (Support Email):
              </div>
              <div className="font-mono-vedic text-[#7C2D86] mt-0.5">
                support@gita-ai.in • Response within 24 hours
              </div>
            </div>
          </div>
        </div>
      )}

      {section === "delete_account" && (
        <div className="bg-white rounded-3xl border-2 border-[#C93B2B]/30 p-5 space-y-4 text-xs">
          <div className="flex items-center gap-2 text-[#C93B2B]">
            <AlertTriangle className="w-5 h-5" />
            <h2 className="text-lg font-serif-vedic">
              Permanent Account & Data Deletion
            </h2>
          </div>
          <p className="text-[#6E5273] leading-relaxed">
            Deleting your account will permanently erase your saved birth
            details (date, time, birthplace), generated Kundli charts, saved
            readings, remedy streaks, and chat history from our PostgreSQL
            database.
          </p>
          <div>
            <label className="block font-semibold text-[#2A162D] mb-1">
              Reason for deletion (Optional)
            </label>
            <input
              type="text"
              placeholder="e.g., Privacy preference / No longer using app"
              value={deleteReason}
              onChange={(e) => setDeleteReason(e.target.value)}
              className="w-full h-11 px-3.5 rounded-xl bg-[#FDF3EE] border border-[#E5D4E8]"
            />
          </div>
          <label className="flex items-start gap-2.5 text-[#2A162D] cursor-pointer">
            <input
              type="checkbox"
              checked={confirmCheck}
              onChange={(e) => setConfirmCheck(e.target.checked)}
              className="mt-0.5 accent-[#C93B2B]"
            />
            <span>
              I understand that this action permanently deletes my personal
              astrology data and chat history.
            </span>
          </label>
          <button
            disabled={!confirmCheck || deleting}
            onClick={async () => {
              setDeleting(true);
              await onDeleteAccount(deleteReason);
              setDeleting(false);
            }}
            className="w-full py-3.5 rounded-full bg-[#C93B2B] text-white font-semibold disabled:opacity-40 cursor-pointer"
          >
            {deleting
              ? "Deleting Account & Personal Data..."
              : "Permanently Delete My Account & Data"}
          </button>
        </div>
      )}
    </div>
  );
}
